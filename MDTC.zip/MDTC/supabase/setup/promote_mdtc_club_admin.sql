begin;

do $$
declare
  target_workspace_id uuid;
  target_user_id uuid;
  workspace_count integer;
  user_display_name text;
begin
  select count(*)
  into workspace_count
  from public.club_workspaces
  where lower(trim(name)) = lower('Manukau Digital Tech Collective');

  if workspace_count <> 1 then
    raise exception 'Expected exactly one club named Manukau Digital Tech Collective; found %.', workspace_count;
  end if;

  select id
  into target_workspace_id
  from public.club_workspaces
  where lower(trim(name)) = lower('Manukau Digital Tech Collective');

  select id, left(coalesce(nullif(trim(raw_user_meta_data ->> 'display_name'), ''), split_part(email, '@', 1)), 80)
  into target_user_id, user_display_name
  from auth.users
  where lower(email) = lower('mdtc@kiaoragaming.xyz');

  if target_user_id is null then
    raise exception 'No Supabase Auth account exists for mdtc@kiaoragaming.xyz. Create or invite the user first.';
  end if;

  if exists (
    select 1
    from public.club_members
    where user_id = target_user_id
      and workspace_id <> target_workspace_id
  ) then
    raise exception 'This account already belongs to another club. Resolve its existing membership before promoting it.';
  end if;

  insert into public.club_members (workspace_id, user_id, display_name, role)
  values (target_workspace_id, target_user_id, user_display_name, 'owner')
  on conflict (workspace_id, user_id)
  do update set display_name = excluded.display_name, role = 'owner';
end;
$$;

commit;
