create or replace function public.default_club_roles()
returns jsonb
language sql
immutable
set search_path = ''
as $$
  select jsonb_build_array(
    jsonb_build_object(
      'id', '10000000-0000-4000-8000-000000000001',
      'name', 'President',
      'permissions', jsonb_build_object('events', true, 'announcements', true, 'members', true, 'settings', true, 'financials', true, 'manageRoles', true, 'attendance', true, 'tasks', true, 'volunteerHours', true)
    ),
    jsonb_build_object(
      'id', '10000000-0000-4000-8000-000000000002',
      'name', 'Vice-President',
      'permissions', jsonb_build_object('events', true, 'announcements', true, 'members', false, 'settings', false, 'financials', false, 'manageRoles', false, 'attendance', false, 'tasks', true, 'volunteerHours', false)
    ),
    jsonb_build_object(
      'id', '10000000-0000-4000-8000-000000000003',
      'name', 'Secretary',
      'permissions', jsonb_build_object('events', false, 'announcements', true, 'members', false, 'settings', false, 'financials', false, 'manageRoles', false, 'attendance', false, 'tasks', true, 'volunteerHours', false)
    ),
    jsonb_build_object(
      'id', '10000000-0000-4000-8000-000000000004',
      'name', 'Treasurer',
      'permissions', jsonb_build_object('events', false, 'announcements', false, 'members', false, 'settings', false, 'financials', true, 'manageRoles', false, 'attendance', false, 'tasks', false, 'volunteerHours', false)
    ),
    jsonb_build_object(
      'id', '10000000-0000-4000-8000-000000000005',
      'name', 'Events Coordinator',
      'permissions', jsonb_build_object('events', true, 'announcements', false, 'members', false, 'settings', false, 'financials', false, 'manageRoles', false, 'attendance', true, 'tasks', false, 'volunteerHours', false)
    ),
    jsonb_build_object(
      'id', '10000000-0000-4000-8000-000000000006',
      'name', 'Technical Officer',
      'permissions', jsonb_build_object('events', false, 'announcements', false, 'members', true, 'settings', false, 'financials', false, 'manageRoles', false, 'attendance', false, 'tasks', false, 'volunteerHours', false)
    )
  );
$$;

update public.club_workspaces as workspace
set data = jsonb_set(
  workspace.data,
  '{roles}',
  (
    select jsonb_agg(
      jsonb_set(
        entry.role,
        '{permissions}',
        coalesce(entry.role -> 'permissions', '{}'::jsonb) || jsonb_build_object(
          'attendance',
          coalesce((entry.role -> 'permissions' ->> 'attendance')::boolean, lower(entry.role ->> 'name') in ('president', 'events coordinator')),
          'tasks',
          coalesce((entry.role -> 'permissions' ->> 'tasks')::boolean, lower(entry.role ->> 'name') in ('president', 'vice-president', 'secretary')),
          'volunteerHours',
          coalesce((entry.role -> 'permissions' ->> 'volunteerHours')::boolean, lower(entry.role ->> 'name') = 'president')
        ),
        true
      )
      order by entry.ordinality
    )
    from jsonb_array_elements(workspace.data -> 'roles') with ordinality as entry(role, ordinality)
  ),
  true
)
where jsonb_typeof(workspace.data -> 'roles') = 'array';

create or replace function public.save_club_roles(p_workspace_id uuid, p_roles jsonb)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  current_data jsonb;
  role_definition jsonb;
  permission_name text;
  permission_value jsonb;
begin
  if auth.uid() is null or not public.has_club_permission(p_workspace_id, 'manageRoles') then
    raise exception 'You do not have permission to manage club roles.';
  end if;

  if jsonb_typeof(p_roles) is distinct from 'array' then
    raise exception 'Club role definitions must be an array.';
  end if;
  if jsonb_array_length(p_roles) > 50 then
    raise exception 'A club can have at most 50 roles.';
  end if;

  for role_definition in select value from jsonb_array_elements(p_roles)
  loop
    if jsonb_typeof(role_definition) is distinct from 'object'
      or coalesce(role_definition ->> 'id', '') !~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
      or char_length(trim(coalesce(role_definition ->> 'name', ''))) not between 1 and 50
      or jsonb_typeof(role_definition -> 'permissions') is distinct from 'object'
      or not (role_definition -> 'permissions' ?& array['events', 'announcements', 'members', 'settings', 'financials', 'manageRoles', 'attendance', 'tasks', 'volunteerHours']) then
      raise exception 'Club role definitions are invalid. Provide a name and all permissions.';
    end if;
    for permission_name, permission_value in
      select key, value from jsonb_each(role_definition -> 'permissions')
    loop
      if permission_name not in ('events', 'announcements', 'members', 'settings', 'financials', 'manageRoles', 'attendance', 'tasks', 'volunteerHours')
        or jsonb_typeof(permission_value) is distinct from 'boolean' then
        raise exception 'Club role definitions contain an invalid permission.';
      end if;
    end loop;
  end loop;

  if (select count(*) from jsonb_array_elements(p_roles)) <>
    (select count(distinct lower(trim(entries.entry ->> 'name'))) from jsonb_array_elements(p_roles) as entries(entry))
    or (select count(*) from jsonb_array_elements(p_roles)) <>
    (select count(distinct entries.entry ->> 'id') from jsonb_array_elements(p_roles) as entries(entry)) then
    raise exception 'Club role names and IDs must be unique.';
  end if;

  select data into current_data
  from public.club_workspaces
  where id = p_workspace_id
  for update;

  if current_data is null then
    raise exception 'The club workspace does not exist.';
  end if;

  if exists (
    select 1
    from public.club_members
    where workspace_id = p_workspace_id
      and position_role_id is not null
      and position_role_id::text not in (
        select entries.entry ->> 'id'
        from jsonb_array_elements(p_roles) as entries(entry)
      )
  ) then
    raise exception 'A role is assigned to a member. Reassign those members before deleting it.';
  end if;

  update public.club_workspaces
  set data = jsonb_set(current_data, '{roles}', p_roles, true)
  where id = p_workspace_id;
end;
$$;

create table public.club_event_attendance (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.club_workspaces(id) on delete cascade,
  event_id text not null check (char_length(event_id) between 1 and 80),
  user_id uuid references auth.users(id) on delete set null,
  display_name text not null check (char_length(trim(display_name)) between 1 and 80),
  status text not null default 'present' check (status in ('present', 'absent', 'excused')),
  marked_by uuid references auth.users(id) on delete set null,
  marked_at timestamptz not null default now(),
  unique (workspace_id, event_id, user_id)
);

create index club_event_attendance_workspace_event_idx
  on public.club_event_attendance(workspace_id, event_id, status);

create table public.club_tasks (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.club_workspaces(id) on delete cascade,
  title text not null check (char_length(trim(title)) between 1 and 120),
  description text not null default '' check (char_length(description) <= 1000),
  due_on date,
  status text not null default 'open' check (status in ('open', 'in_progress', 'done')),
  created_by uuid references auth.users(id) on delete set null,
  created_by_name text not null check (char_length(trim(created_by_name)) between 1 and 80),
  assigned_to uuid references auth.users(id) on delete set null,
  assignee_name text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (assignee_name is null or char_length(trim(assignee_name)) between 1 and 80)
);

create index club_tasks_workspace_status_due_idx
  on public.club_tasks(workspace_id, status, due_on nulls last, created_at desc);

create table public.club_volunteer_hours (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.club_workspaces(id) on delete cascade,
  submitted_by uuid references auth.users(id) on delete set null,
  volunteer_name text not null check (char_length(trim(volunteer_name)) between 1 and 80),
  service_date date not null,
  minutes_spent integer not null check (minutes_spent between 1 and 1440),
  description text not null check (char_length(trim(description)) between 1 and 500),
  status text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
  reviewed_by uuid references auth.users(id) on delete set null,
  reviewed_at timestamptz,
  created_at timestamptz not null default now(),
  check ((status = 'pending' and reviewed_at is null)
    or (status in ('approved', 'rejected') and reviewed_at is not null))
);

create index club_volunteer_hours_workspace_date_idx
  on public.club_volunteer_hours(workspace_id, service_date desc, status);

alter table public.club_event_attendance enable row level security;
alter table public.club_tasks enable row level security;
alter table public.club_volunteer_hours enable row level security;

create policy "Active members can view event attendance"
  on public.club_event_attendance for select to authenticated
  using (public.is_club_member(workspace_id));

create policy "Members can check in and attendance managers can record attendance"
  on public.club_event_attendance for insert to authenticated
  with check (
    public.is_club_member(workspace_id)
    and (user_id = auth.uid() or public.has_club_permission(workspace_id, 'attendance'))
  );

create policy "Attendance managers can update attendance"
  on public.club_event_attendance for update to authenticated
  using (public.has_club_permission(workspace_id, 'attendance'))
  with check (public.has_club_permission(workspace_id, 'attendance'));

create policy "Attendance managers can remove attendance"
  on public.club_event_attendance for delete to authenticated
  using (public.has_club_permission(workspace_id, 'attendance'));

create policy "Active members can view club tasks"
  on public.club_tasks for select to authenticated
  using (public.is_club_member(workspace_id));

create policy "Active members can create club tasks"
  on public.club_tasks for insert to authenticated
  with check (public.is_club_member(workspace_id) and created_by = auth.uid());

create policy "Task managers members and assignees can update tasks"
  on public.club_tasks for update to authenticated
  using (
    public.has_club_permission(workspace_id, 'tasks')
    or created_by = auth.uid()
    or assigned_to = auth.uid()
  )
  with check (
    public.is_club_member(workspace_id)
    and (
      public.has_club_permission(workspace_id, 'tasks')
      or created_by = auth.uid()
      or assigned_to = auth.uid()
    )
  );

create policy "Task managers can delete club tasks"
  on public.club_tasks for delete to authenticated
  using (public.has_club_permission(workspace_id, 'tasks'));

create policy "Active members can view volunteer hours"
  on public.club_volunteer_hours for select to authenticated
  using (public.is_club_member(workspace_id));

create policy "Members can submit their own volunteer hours"
  on public.club_volunteer_hours for insert to authenticated
  with check (public.is_club_member(workspace_id) and submitted_by = auth.uid());

create policy "Volunteer hour managers can review requests"
  on public.club_volunteer_hours for update to authenticated
  using (public.has_club_permission(workspace_id, 'volunteerHours'))
  with check (public.has_club_permission(workspace_id, 'volunteerHours'));

create policy "Members can remove their pending volunteer requests"
  on public.club_volunteer_hours for delete to authenticated
  using (submitted_by = auth.uid() and status = 'pending' and public.is_club_member(workspace_id));

create policy "Volunteer hour managers can remove requests"
  on public.club_volunteer_hours for delete to authenticated
  using (public.has_club_permission(workspace_id, 'volunteerHours'));

grant select, insert, update, delete on public.club_event_attendance to authenticated;
grant select, insert, update, delete on public.club_tasks to authenticated;
grant select, insert, update, delete on public.club_volunteer_hours to authenticated;

create or replace function public.set_club_attendance_actor()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  member_name text;
  event_record jsonb;
  is_manager boolean;
begin
  is_manager := public.has_club_permission(new.workspace_id, 'attendance');

  if tg_op = 'UPDATE'
    and auth.uid() is null
    and old.user_id is not null
    and new.user_id is null
    and not exists (select 1 from auth.users as account where account.id = old.user_id) then
    return new;
  end if;

  if tg_op = 'UPDATE'
    and auth.uid() is null
    and old.marked_by is not null
    and new.marked_by is null
    and not exists (select 1 from auth.users as account where account.id = old.marked_by) then
    return new;
  end if;

  select membership.display_name into member_name
  from public.club_members as membership
  where membership.workspace_id = new.workspace_id
    and membership.user_id = new.user_id
    and membership.membership_status = 'active';

  if member_name is null then
    raise exception 'Attendance can only be recorded for active club members.';
  end if;

  select event.value into event_record
  from public.club_workspaces as workspace
  cross join lateral jsonb_array_elements(coalesce(workspace.data -> 'events', '[]'::jsonb)) as event(value)
  where workspace.id = new.workspace_id
    and event.value ->> 'id' = new.event_id;

  if event_record is null then
    raise exception 'Choose an event from this club calendar.';
  end if;

  if tg_op = 'INSERT' then
    if auth.uid() is null or not public.is_club_member(new.workspace_id) then
      raise exception 'Only active club members can check in.';
    end if;
    if not is_manager and (new.user_id <> auth.uid() or new.status <> 'present') then
      raise exception 'Members can only check themselves in as present.';
    end if;
    if not is_manager and coalesce(event_record ->> 'date', '') !~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$' then
      raise exception 'The event date is invalid.';
    end if;
    if not is_manager and (event_record ->> 'date')::date > current_date then
      raise exception 'Attendance opens on the event date.';
    end if;
    new.display_name := member_name;
    new.marked_by := auth.uid();
    new.marked_at := now();
  else
    if not is_manager then
      raise exception 'You do not have permission to edit attendance records.';
    end if;
    new.display_name := member_name;
    new.marked_by := auth.uid();
    new.marked_at := now();
  end if;

  return new;
end;
$$;

create trigger set_club_attendance_actor
  before insert or update on public.club_event_attendance
  for each row execute function public.set_club_attendance_actor();

create or replace function public.set_club_task_actor()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  actor_name text;
  assigned_name text;
  is_manager boolean;
begin
  is_manager := public.has_club_permission(new.workspace_id, 'tasks');

  if tg_op = 'INSERT' then
    if auth.uid() is null then
      raise exception 'You must be signed in to create a task.';
    end if;
    select membership.display_name into actor_name
    from public.club_members as membership
    where membership.workspace_id = new.workspace_id
      and membership.user_id = auth.uid()
      and membership.membership_status = 'active';
    if actor_name is null then
      raise exception 'Only active club members can create tasks.';
    end if;

    new.created_by := auth.uid();
    new.created_by_name := actor_name;
    if not is_manager then
      new.status := 'open';
    end if;
  else
    if auth.uid() is null and (
      (old.created_by is not null and new.created_by is null
        and not exists (select 1 from auth.users as account where account.id = old.created_by))
      or (old.assigned_to is not null and new.assigned_to is null
        and not exists (select 1 from auth.users as account where account.id = old.assigned_to))
    ) then
      if old.assigned_to is not null and new.assigned_to is null
        and not exists (select 1 from auth.users as account where account.id = old.assigned_to) then
        new.assignee_name := old.assignee_name;
      end if;
      return new;
    end if;

    if new.id is distinct from old.id
      or new.workspace_id is distinct from old.workspace_id
      or new.created_by is distinct from old.created_by
      or new.created_by_name is distinct from old.created_by_name
      or new.created_at is distinct from old.created_at then
      raise exception 'Task ownership cannot be changed.';
    end if;

    if not is_manager then
      if old.created_by = auth.uid() then
        null;
      elsif old.assigned_to = auth.uid()
        and (new.title is distinct from old.title
          or new.description is distinct from old.description
          or new.due_on is distinct from old.due_on
          or new.assigned_to is distinct from old.assigned_to
          or new.assignee_name is distinct from old.assignee_name) then
        raise exception 'Assignees can only update task status.';
      elsif old.created_by is distinct from auth.uid() then
        raise exception 'You can only update tasks you created or were assigned.';
      end if;
    end if;
    new.updated_at := now();
  end if;

  if new.assigned_to is null then
    new.assignee_name := null;
  else
    select membership.display_name into assigned_name
    from public.club_members as membership
    where membership.workspace_id = new.workspace_id
      and membership.user_id = new.assigned_to
      and membership.membership_status = 'active';

    if assigned_name is null then
      if tg_op = 'UPDATE' and old.assigned_to = new.assigned_to
        and not exists (select 1 from auth.users as account where account.id = old.assigned_to) then
        new.assignee_name := old.assignee_name;
      else
        raise exception 'Assign tasks only to active members of this club.';
      end if;
    else
      new.assignee_name := assigned_name;
    end if;
  end if;

  return new;
end;
$$;

create trigger set_club_task_actor
  before insert or update on public.club_tasks
  for each row execute function public.set_club_task_actor();

create or replace function public.set_club_volunteer_hour_actor()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  member_name text;
  is_manager boolean;
begin
  is_manager := public.has_club_permission(new.workspace_id, 'volunteerHours');

  if tg_op = 'INSERT' then
    if auth.uid() is null then
      raise exception 'You must be signed in to submit volunteer hours.';
    end if;
    select membership.display_name into member_name
    from public.club_members as membership
    where membership.workspace_id = new.workspace_id
      and membership.user_id = auth.uid()
      and membership.membership_status = 'active';
    if member_name is null then
      raise exception 'Only active club members can submit volunteer hours.';
    end if;
    new.submitted_by := auth.uid();
    new.volunteer_name := member_name;
    if new.service_date > current_date then
      raise exception 'Volunteer hours can only be logged after the service date.';
    end if;
    if not is_manager then
      new.status := 'pending';
      new.reviewed_by := null;
      new.reviewed_at := null;
    elsif new.status in ('approved', 'rejected') then
      new.reviewed_by := auth.uid();
      new.reviewed_at := now();
    else
      new.reviewed_by := null;
      new.reviewed_at := null;
    end if;
  else
    if auth.uid() is null
      and old.submitted_by is not null
      and new.submitted_by is null
      and not exists (select 1 from auth.users as account where account.id = old.submitted_by) then
      return new;
    end if;

    if new.id is distinct from old.id
      or new.workspace_id is distinct from old.workspace_id
      or new.submitted_by is distinct from old.submitted_by
      or new.volunteer_name is distinct from old.volunteer_name
      or new.service_date is distinct from old.service_date
      or new.minutes_spent is distinct from old.minutes_spent
      or new.description is distinct from old.description
      or new.created_at is distinct from old.created_at then
      raise exception 'Submitted volunteer hours cannot be changed during review.';
    end if;
    if not is_manager then
      raise exception 'You do not have permission to review volunteer hours.';
    end if;
    if old.status <> 'pending' then
      raise exception 'Only pending volunteer-hour requests can be reviewed.';
    end if;
    if new.status not in ('approved', 'rejected') then
      raise exception 'Choose whether to approve or reject these volunteer hours.';
    end if;
    new.reviewed_by := auth.uid();
    new.reviewed_at := now();
  end if;

  return new;
end;
$$;

create trigger set_club_volunteer_hour_actor
  before insert or update on public.club_volunteer_hours
  for each row execute function public.set_club_volunteer_hour_actor();

revoke all on function public.set_club_attendance_actor() from public;
revoke all on function public.set_club_task_actor() from public;
revoke all on function public.set_club_volunteer_hour_actor() from public;

do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'club_event_attendance'
  ) then
    alter publication supabase_realtime add table public.club_event_attendance;
  end if;
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'club_tasks'
  ) then
    alter publication supabase_realtime add table public.club_tasks;
  end if;
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'club_volunteer_hours'
  ) then
    alter publication supabase_realtime add table public.club_volunteer_hours;
  end if;
end;
$$;
