create table public.club_member_dues (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.club_workspaces(id) on delete cascade,
  member_user_id uuid references auth.users(id) on delete set null,
  member_name text not null check (char_length(trim(member_name)) between 1 and 80),
  period date not null check (period = pg_catalog.date_trunc('month', period::timestamp)::date),
  amount_cents bigint not null check (amount_cents between 1 and 100000000000),
  status text not null default 'due' check (status in ('due', 'payment_reported', 'paid')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (workspace_id, member_user_id, period)
);

create index club_member_dues_workspace_period_idx
  on public.club_member_dues(workspace_id, period, member_name);

create table public.club_finance_transactions (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.club_workspaces(id) on delete cascade,
  submitted_by uuid references auth.users(id) on delete set null,
  submitter_name text not null check (char_length(trim(submitter_name)) between 1 and 80),
  type text not null check (type in ('income', 'expense')),
  category text not null check (category in ('membership-dues', 'fundraising', 'event-costs', 'equipment', 'food-and-drink', 'transport', 'other')),
  description text not null check (char_length(trim(description)) between 1 and 160),
  amount_cents bigint not null check (amount_cents between 1 and 100000000000),
  transaction_date date not null,
  status text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
  receipt_path text,
  source_dues_id uuid unique references public.club_member_dues(id) on delete set null,
  reviewed_by uuid references auth.users(id) on delete set null,
  reviewed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (receipt_path is null or (char_length(receipt_path) <= 160 and receipt_path !~ '(^/|[.][.])')),
  check ((status = 'pending' and reviewed_by is null and reviewed_at is null)
    or (status in ('approved', 'rejected') and reviewed_at is not null))
);

create index club_finance_transactions_workspace_date_idx
  on public.club_finance_transactions(workspace_id, transaction_date desc, created_at desc);

create table public.club_finance_budgets (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.club_workspaces(id) on delete cascade,
  category text not null check (category in ('membership-dues', 'fundraising', 'event-costs', 'equipment', 'food-and-drink', 'transport', 'other')),
  period date not null check (period = pg_catalog.date_trunc('month', period::timestamp)::date),
  amount_cents bigint not null check (amount_cents between 1 and 100000000000),
  created_at timestamptz not null default now(),
  unique (workspace_id, category, period)
);

alter table public.club_member_dues enable row level security;
alter table public.club_finance_transactions enable row level security;
alter table public.club_finance_budgets enable row level security;

create policy "Active members can view club dues"
  on public.club_member_dues for select to authenticated
  using (public.is_club_member(workspace_id));

create policy "Finance managers can manage club dues"
  on public.club_member_dues for all to authenticated
  using (public.has_club_permission(workspace_id, 'financials'))
  with check (public.has_club_permission(workspace_id, 'financials'));

create policy "Members can report their own dues payments"
  on public.club_member_dues for update to authenticated
  using (member_user_id = auth.uid() and status = 'due' and public.is_club_member(workspace_id))
  with check (member_user_id = auth.uid() and status = 'payment_reported' and public.is_club_member(workspace_id));

create policy "Active members can view club finance transactions"
  on public.club_finance_transactions for select to authenticated
  using (public.is_club_member(workspace_id));

create policy "Members can submit finance requests"
  on public.club_finance_transactions for insert to authenticated
  with check (
    public.is_club_member(workspace_id)
    and submitted_by = auth.uid()
    and (status = 'pending' or public.has_club_permission(workspace_id, 'financials'))
  );

create policy "Finance managers can update transactions"
  on public.club_finance_transactions for update to authenticated
  using (public.has_club_permission(workspace_id, 'financials'))
  with check (public.has_club_permission(workspace_id, 'financials'));

create policy "Request authors can edit pending requests"
  on public.club_finance_transactions for update to authenticated
  using (submitted_by = auth.uid() and status = 'pending' and public.is_club_member(workspace_id))
  with check (submitted_by = auth.uid() and status = 'pending' and public.is_club_member(workspace_id));

create policy "Finance managers can delete transactions"
  on public.club_finance_transactions for delete to authenticated
  using (public.has_club_permission(workspace_id, 'financials'));

create policy "Active members can view club budgets"
  on public.club_finance_budgets for select to authenticated
  using (public.is_club_member(workspace_id));

create policy "Finance managers can manage club budgets"
  on public.club_finance_budgets for all to authenticated
  using (public.has_club_permission(workspace_id, 'financials'))
  with check (public.has_club_permission(workspace_id, 'financials'));

grant select, insert, update, delete on public.club_member_dues to authenticated;
grant select, insert, update, delete on public.club_finance_transactions to authenticated;
grant select, insert, update, delete on public.club_finance_budgets to authenticated;

create or replace function public.set_club_finance_transaction_actor()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  member_name text;
begin
  if tg_op = 'INSERT' then
    if auth.uid() is null then
      raise exception 'You must be signed in to create a finance entry.';
    end if;

    select membership.display_name
    into member_name
    from public.club_members as membership
    where membership.workspace_id = new.workspace_id
      and membership.user_id = auth.uid()
      and membership.membership_status = 'active';

    if member_name is null then
      raise exception 'Only active club members can create finance entries.';
    end if;

    new.submitted_by := auth.uid();
    new.submitter_name := member_name;

    if not public.has_club_permission(new.workspace_id, 'financials') then
      new.status := 'pending';
      new.source_dues_id := null;
    end if;

    if new.status in ('approved', 'rejected') then
      new.reviewed_by := auth.uid();
      new.reviewed_at := now();
    else
      new.reviewed_by := null;
      new.reviewed_at := null;
    end if;
  else
    if new.id is distinct from old.id
      or new.workspace_id is distinct from old.workspace_id
      or (new.submitted_by is distinct from old.submitted_by
        and not (new.submitted_by is null and old.submitted_by is not null
          and not exists (select 1 from auth.users as account where account.id = old.submitted_by)))
      or new.submitter_name is distinct from old.submitter_name
      or (new.source_dues_id is distinct from old.source_dues_id
        and not (new.source_dues_id is null and old.source_dues_id is not null
          and not exists (select 1 from public.club_member_dues where id = old.source_dues_id)))
      or new.created_at is distinct from old.created_at then
      raise exception 'The transaction identity cannot be changed.';
    end if;

    new.updated_at := now();
    if new.status is distinct from old.status then
      if new.status = 'pending' then
        new.reviewed_by := null;
        new.reviewed_at := null;
      else
        new.reviewed_by := auth.uid();
        new.reviewed_at := now();
      end if;
    else
      if old.reviewed_by is not null and not exists (
        select 1 from auth.users as account where account.id = old.reviewed_by
      ) then
        new.reviewed_by := null;
      else
        new.reviewed_by := old.reviewed_by;
      end if;
      new.reviewed_at := old.reviewed_at;
    end if;
  end if;

  return new;
end;
$$;

create trigger set_club_finance_transaction_actor
  before insert or update on public.club_finance_transactions
  for each row execute function public.set_club_finance_transaction_actor();

create or replace function public.set_club_member_dues_actor()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if tg_op = 'INSERT' then
    select membership.display_name
    into new.member_name
    from public.club_members as membership
    where membership.workspace_id = new.workspace_id
      and membership.user_id = new.member_user_id
      and membership.membership_status = 'active';

    if new.member_name is null then
      raise exception 'Dues can only be created for active club members.';
    end if;
  else
    if new.id is distinct from old.id
      or new.workspace_id is distinct from old.workspace_id
      or (new.member_user_id is distinct from old.member_user_id
        and not (new.member_user_id is null and old.member_user_id is not null
          and not exists (select 1 from auth.users as account where account.id = old.member_user_id)))
      or new.member_name is distinct from old.member_name
      or new.period is distinct from old.period
      or new.created_at is distinct from old.created_at then
      raise exception 'The dues record cannot be changed directly.';
    end if;

    if old.member_user_id is not null
      and new.member_user_id is null
      and not exists (select 1 from auth.users as account where account.id = old.member_user_id) then
      new.updated_at := now();
      return new;
    end if;

    if public.has_club_permission(old.workspace_id, 'financials') then
      if new.status not in ('due', 'payment_reported', 'paid') then
        raise exception 'The dues status is invalid.';
      end if;
    else
      if new.amount_cents is distinct from old.amount_cents
        or not (old.member_user_id = auth.uid() and old.status = 'due' and new.status = 'payment_reported') then
        raise exception 'You do not have permission to update this dues record.';
      end if;
    end if;
    new.updated_at := now();
  end if;

  return new;
end;
$$;

create trigger set_club_member_dues_actor
  before insert or update on public.club_member_dues
  for each row execute function public.set_club_member_dues_actor();

create or replace function public.generate_club_monthly_dues(
  p_workspace_id uuid,
  p_period date,
  p_amount_cents bigint
)
returns integer
language plpgsql
security definer
set search_path = ''
as $$
declare
  affected_rows integer;
begin
  if auth.uid() is null or not public.has_club_permission(p_workspace_id, 'financials') then
    raise exception 'You do not have permission to prepare club dues.';
  end if;

  if p_period is null or p_period <> pg_catalog.date_trunc('month', p_period::timestamp)::date
    or p_amount_cents not between 1 and 100000000000 then
    raise exception 'Choose a valid month and a positive dues amount.';
  end if;

  insert into public.club_member_dues (workspace_id, member_user_id, member_name, period, amount_cents)
  select p_workspace_id, membership.user_id, membership.display_name, p_period, p_amount_cents
  from public.club_members as membership
  where membership.workspace_id = p_workspace_id
    and membership.membership_status = 'active'
  on conflict (workspace_id, member_user_id, period)
  do update set amount_cents = excluded.amount_cents
  where public.club_member_dues.status = 'due';

  get diagnostics affected_rows = row_count;
  return affected_rows;
end;
$$;

create or replace function public.report_club_dues_payment(p_dues_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  dues_status text;
begin
  if auth.uid() is null then
    raise exception 'You must be signed in to report a dues payment.';
  end if;

  select status into dues_status
  from public.club_member_dues
  where id = p_dues_id
    and member_user_id = auth.uid()
    and public.is_club_member(workspace_id)
  for update;

  if dues_status is distinct from 'due' then
    raise exception 'This dues payment cannot be reported.';
  end if;

  update public.club_member_dues
  set status = 'payment_reported'
  where id = p_dues_id;
end;
$$;

create or replace function public.review_club_dues_payment(p_dues_id uuid, p_approve boolean)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  dues public.club_member_dues%rowtype;
begin
  select * into dues
  from public.club_member_dues
  where id = p_dues_id
  for update;

  if dues.id is null or auth.uid() is null
    or not public.has_club_permission(dues.workspace_id, 'financials') then
    raise exception 'You do not have permission to review this dues payment.';
  end if;

  if p_approve then
    if dues.status not in ('due', 'payment_reported') then
      raise exception 'This dues payment has already been reviewed.';
    end if;

    insert into public.club_finance_transactions (
      workspace_id, submitted_by, submitter_name, type, category, description,
      amount_cents, transaction_date, status, source_dues_id, reviewed_by, reviewed_at
    )
    select dues.workspace_id, auth.uid(), membership.display_name, 'income', 'membership-dues',
      'Membership dues - ' || dues.member_name || ' (' || to_char(dues.period, 'YYYY-MM') || ')',
      dues.amount_cents, current_date, 'approved', dues.id, auth.uid(), now()
    from public.club_members as membership
    where membership.workspace_id = dues.workspace_id
      and membership.user_id = auth.uid()
      and membership.membership_status = 'active';

    if not found then
      raise exception 'Your active club membership could not be verified.';
    end if;

    update public.club_member_dues
    set status = 'paid'
    where id = dues.id;
  else
    if dues.status is distinct from 'payment_reported' then
      raise exception 'Only reported dues payments can be returned.';
    end if;
    update public.club_member_dues
    set status = 'due'
    where id = dues.id;
  end if;
end;
$$;

revoke all on function public.set_club_finance_transaction_actor() from public;
revoke all on function public.set_club_member_dues_actor() from public;
revoke all on function public.generate_club_monthly_dues(uuid, date, bigint) from public;
revoke all on function public.report_club_dues_payment(uuid) from public;
revoke all on function public.review_club_dues_payment(uuid, boolean) from public;
grant execute on function public.generate_club_monthly_dues(uuid, date, bigint) to authenticated;
grant execute on function public.report_club_dues_payment(uuid) to authenticated;
grant execute on function public.review_club_dues_payment(uuid, boolean) to authenticated;

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('club-finance-receipts', 'club-finance-receipts', false, 10485760, array['application/pdf', 'image/jpeg', 'image/png'])
on conflict (id) do update
set public = false, file_size_limit = 10485760, allowed_mime_types = array['application/pdf', 'image/jpeg', 'image/png'];

create policy "Active club members can view linked finance receipts"
  on storage.objects for select to authenticated
  using (
    bucket_id = 'club-finance-receipts'
    and exists (
      select 1
      from public.club_finance_transactions as finance_entry
      where finance_entry.workspace_id::text = (storage.foldername(name))[1]
        and finance_entry.receipt_path = storage.objects.name
        and public.is_club_member(finance_entry.workspace_id)
    )
  );

create policy "Members can upload receipts to their finance entries"
  on storage.objects for insert to authenticated
  with check (
    bucket_id = 'club-finance-receipts'
    and name ~ '^[0-9a-f-]{36}/[0-9a-f-]{36}[.](pdf|jpg|png)$'
    and exists (
      select 1
      from public.club_finance_transactions as finance_entry
      where finance_entry.workspace_id::text = (storage.foldername(name))[1]
        and finance_entry.id::text = split_part(split_part(name, '/', 2), '.', 1)
        and public.is_club_member(finance_entry.workspace_id)
        and (
          public.has_club_permission(finance_entry.workspace_id, 'financials')
          or (finance_entry.submitted_by = auth.uid() and finance_entry.status = 'pending')
        )
    )
  );

create policy "Finance managers or request authors can remove receipts"
  on storage.objects for delete to authenticated
  using (
    bucket_id = 'club-finance-receipts'
    and exists (
      select 1
      from public.club_finance_transactions as finance_entry
      where finance_entry.workspace_id::text = (storage.foldername(name))[1]
        and finance_entry.receipt_path = storage.objects.name
        and (
          public.has_club_permission(finance_entry.workspace_id, 'financials')
          or (finance_entry.submitted_by = auth.uid() and finance_entry.status = 'pending')
        )
    )
  );

do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'club_finance_transactions'
  ) then
    alter publication supabase_realtime add table public.club_finance_transactions;
  end if;
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'club_finance_budgets'
  ) then
    alter publication supabase_realtime add table public.club_finance_budgets;
  end if;
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'club_member_dues'
  ) then
    alter publication supabase_realtime add table public.club_member_dues;
  end if;
end;
$$;
