create or replace function public.join_club(p_invite_code text)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  target_workspace_id uuid;
  display_name text;
  inserted_count integer;
begin
  if auth.uid() is null then
    raise exception 'You must be signed in to join a club.';
  end if;

  select id into target_workspace_id
  from public.club_workspaces
  where upper(invite_code) = upper(trim(p_invite_code));

  if target_workspace_id is null then
    raise exception 'That invite code is not valid.';
  end if;

  if exists (
    select 1 from public.club_members
    where user_id = auth.uid() and workspace_id <> target_workspace_id
  ) then
    raise exception 'This account already belongs to a different club.';
  end if;

  display_name := coalesce(nullif(trim(auth.jwt() -> 'user_metadata' ->> 'display_name'), ''), 'Club member');

  insert into public.club_members (workspace_id, user_id, display_name, role)
  values (target_workspace_id, auth.uid(), display_name, 'member')
  on conflict (workspace_id, user_id) do nothing;

  get diagnostics inserted_count = row_count;
  if inserted_count > 0 then
    update public.club_workspaces
    set data = jsonb_set(
      data,
      '{members}',
      coalesce(data -> 'members', '[]'::jsonb) || jsonb_build_array(jsonb_build_object(
        'id', 'account:' || auth.uid()::text,
        'userId', auth.uid()::text,
        'name', display_name,
        'role', 'Member',
        'year', 'Club member',
        'initials', '',
        'color', 'avatar-lilac',
        'joined', to_char(now(), 'Mon YYYY')
      ))
    )
    where id = target_workspace_id;
  end if;

  return target_workspace_id;
end;
$$;
