create table public.club_workspaces (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 1 and 60),
  invite_code text not null unique,
  data jsonb not null default '{"clubName":"","adminName":"","events":[],"members":[],"announcements":[],"rsvps":{}}'::jsonb,
  created_at timestamptz not null default now()
);

create table public.club_members (
  workspace_id uuid not null references public.club_workspaces(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  display_name text not null check (char_length(display_name) between 1 and 80),
  role text not null check (role in ('owner', 'member')),
  joined_at timestamptz not null default now(),
  primary key (workspace_id, user_id)
);

create index club_members_user_id_idx on public.club_members(user_id);

alter table public.club_workspaces enable row level security;
alter table public.club_members enable row level security;

create or replace function public.is_club_member(p_workspace_id uuid)
returns boolean
language sql
security definer
set search_path = ''
stable
as $$
  select exists (
    select 1 from public.club_members
    where workspace_id = p_workspace_id and user_id = auth.uid()
  );
$$;

create policy "Club members can read their workspace"
  on public.club_workspaces for select to authenticated
  using (public.is_club_member(id));

create policy "Users can see memberships in their workspace"
  on public.club_members for select to authenticated
  using (public.is_club_member(workspace_id));

create or replace function public.create_club(p_name text)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  new_workspace_id uuid;
  new_invite_code text;
  display_name text;
begin
  if auth.uid() is null then
    raise exception 'You must be signed in to create a club.';
  end if;

  if exists (select 1 from public.club_members where user_id = auth.uid()) then
    raise exception 'This account already belongs to a club.';
  end if;

  if char_length(trim(p_name)) not between 1 and 60 then
    raise exception 'Club name must be between 1 and 60 characters.';
  end if;

  display_name := coalesce(nullif(trim(auth.jwt() -> 'user_metadata' ->> 'display_name'), ''), 'Club admin');
  new_invite_code := upper(substr(replace(pg_catalog.gen_random_uuid()::text, '-', ''), 1, 32));

  insert into public.club_workspaces (name, invite_code, data)
  values (
    trim(p_name),
    new_invite_code,
    jsonb_build_object('clubName', trim(p_name), 'adminName', display_name, 'events', '[]'::jsonb, 'members', '[]'::jsonb, 'announcements', '[]'::jsonb, 'rsvps', '{}'::jsonb)
  )
  returning id into new_workspace_id;

  insert into public.club_members (workspace_id, user_id, display_name, role)
  values (new_workspace_id, auth.uid(), display_name, 'owner');

  return new_workspace_id;
end;
$$;

create or replace function public.join_club(p_invite_code text)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  target_workspace_id uuid;
  display_name text;
  inserted_count integer;
begin
  if auth.uid() is null then
    raise exception 'You must be signed in to join a club.';
  end if;

  select id into target_workspace_id
  from public.club_workspaces
  where invite_code = upper(trim(p_invite_code));

  if target_workspace_id is null then
    raise exception 'That invite code is not valid.';
  end if;

  if exists (
    select 1 from public.club_members
    where user_id = auth.uid() and workspace_id <> target_workspace_id
  ) then
    raise exception 'This account already belongs to a different club.';
  end if;

  display_name := coalesce(nullif(trim(auth.jwt() -> 'user_metadata' ->> 'display_name'), ''), 'Club member');

  insert into public.club_members (workspace_id, user_id, display_name, role)
  values (target_workspace_id, auth.uid(), display_name, 'member')
  on conflict (workspace_id, user_id) do nothing;

  get diagnostics inserted_count = row_count;
  if inserted_count > 0 then
    update public.club_workspaces
    set data = jsonb_set(
      data,
      '{members}',
      coalesce(data -> 'members', '[]'::jsonb) || jsonb_build_array(jsonb_build_object(
        'id', 'account:' || auth.uid()::text,
        'userId', auth.uid()::text,
        'name', display_name,
        'role', 'Member',
        'year', 'Club member',
        'initials', '',
        'color', 'avatar-lilac',
        'joined', to_char(now(), 'Mon YYYY')
      ))
    )
    where id = target_workspace_id;
  end if;

  return target_workspace_id;
end;
$$;

create or replace function public.save_club_data(p_workspace_id uuid, p_data jsonb)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  actor_role text;
  current_data jsonb;
  safe_data jsonb;
begin
  select role into actor_role
  from public.club_members
  where workspace_id = p_workspace_id and user_id = auth.uid();

  if auth.uid() is null or actor_role is null then
    raise exception 'You do not have access to this club.';
  end if;

  select data into current_data
  from public.club_workspaces
  where id = p_workspace_id
  for update;

  if jsonb_typeof(p_data) is distinct from 'object'
    or jsonb_typeof(p_data -> 'events') is distinct from 'array'
    or jsonb_typeof(p_data -> 'members') is distinct from 'array'
    or jsonb_typeof(p_data -> 'announcements') is distinct from 'array'
    or jsonb_typeof(p_data -> 'rsvps') is distinct from 'object'
    or char_length(coalesce(p_data ->> 'clubName', '')) not between 1 and 60
    or char_length(coalesce(p_data ->> 'adminName', '')) not between 1 and 80 then
    raise exception 'Club data is invalid.';
  end if;

  if jsonb_typeof(coalesce(p_data -> 'rsvps' -> auth.uid()::text, '[]'::jsonb)) is distinct from 'array' then
    raise exception 'Your RSVP data is invalid.';
  end if;

  if exists (
    select 1
    from jsonb_array_elements(coalesce(p_data -> 'rsvps' -> auth.uid()::text, '[]'::jsonb)) as entries(event_id)
    where jsonb_typeof(event_id) is distinct from 'string'
  ) then
    raise exception 'Your RSVP data is invalid.';
  end if;

  safe_data := p_data;
  if actor_role = 'owner' then
    safe_data := jsonb_set(
      safe_data,
      '{members}',
      coalesce((
        select jsonb_agg(member)
        from jsonb_array_elements(p_data -> 'members') as entries(member)
        where member ->> 'userId' is null
      ), '[]'::jsonb) || coalesce((
        select jsonb_agg(member)
        from jsonb_array_elements(current_data -> 'members') as entries(member)
        where member ->> 'userId' is not null
      ), '[]'::jsonb)
    );
  else
    safe_data := jsonb_set(safe_data, '{clubName}', current_data -> 'clubName');
    safe_data := jsonb_set(safe_data, '{adminName}', current_data -> 'adminName');
    safe_data := jsonb_set(safe_data, '{members}', current_data -> 'members');
  end if;

  safe_data := jsonb_set(
    safe_data,
    '{rsvps}',
    (current_data -> 'rsvps') || jsonb_build_object(
      auth.uid()::text,
      coalesce(p_data -> 'rsvps' -> auth.uid()::text, current_data -> 'rsvps' -> auth.uid()::text, '[]'::jsonb)
    )
  );

  update public.club_workspaces
  set data = safe_data, name = safe_data ->> 'clubName'
  where id = p_workspace_id;
end;
$$;

create or replace function public.remove_club_member(p_workspace_id uuid, p_user_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  actor_role text;
begin
  select role into actor_role
  from public.club_members
  where workspace_id = p_workspace_id and user_id = auth.uid();

  if actor_role is distinct from 'owner' then
    raise exception 'Only the club owner can remove members.';
  end if;

  if not exists (
    select 1 from public.club_members
    where workspace_id = p_workspace_id and user_id = p_user_id and role = 'member'
  ) then
    raise exception 'That member cannot be removed.';
  end if;

  delete from public.club_members
  where workspace_id = p_workspace_id and user_id = p_user_id;

  update public.club_workspaces
  set data = jsonb_set(
    data,
    '{members}',
    coalesce((
      select jsonb_agg(member)
      from jsonb_array_elements(data -> 'members') as entries(member)
      where member ->> 'userId' is distinct from p_user_id::text
    ), '[]'::jsonb)
  )
  where id = p_workspace_id;
end;
$$;

revoke all on function public.is_club_member(uuid) from public;
revoke all on function public.remove_club_member(uuid, uuid) from public;
revoke all on function public.create_club(text) from public;
revoke all on function public.join_club(text) from public;
revoke all on function public.save_club_data(uuid, jsonb) from public;
grant execute on function public.create_club(text) to authenticated;
grant execute on function public.is_club_member(uuid) to authenticated;
grant execute on function public.join_club(text) to authenticated;
grant execute on function public.remove_club_member(uuid, uuid) to authenticated;
grant execute on function public.save_club_data(uuid, jsonb) to authenticated;

grant select on public.club_workspaces to authenticated;
grant select on public.club_members to authenticated;

alter publication supabase_realtime add table public.club_workspaces;
