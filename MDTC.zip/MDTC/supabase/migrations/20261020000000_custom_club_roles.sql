alter table public.club_members
  add column if not exists position_role_id uuid;

create or replace function public.default_club_roles()
returns jsonb
language sql
immutable
set search_path = ''
as $$
  select jsonb_build_array(
    jsonb_build_object(
      'id', '10000000-0000-4000-8000-000000000001',
      'name', 'President',
      'permissions', jsonb_build_object('events', true, 'announcements', true, 'members', true, 'settings', true, 'financials', true, 'manageRoles', true)
    ),
    jsonb_build_object(
      'id', '10000000-0000-4000-8000-000000000002',
      'name', 'Vice-President',
      'permissions', jsonb_build_object('events', true, 'announcements', true, 'members', false, 'settings', false, 'financials', false, 'manageRoles', false)
    ),
    jsonb_build_object(
      'id', '10000000-0000-4000-8000-000000000003',
      'name', 'Secretary',
      'permissions', jsonb_build_object('events', false, 'announcements', true, 'members', false, 'settings', false, 'financials', false, 'manageRoles', false)
    ),
    jsonb_build_object(
      'id', '10000000-0000-4000-8000-000000000004',
      'name', 'Treasurer',
      'permissions', jsonb_build_object('events', false, 'announcements', false, 'members', false, 'settings', false, 'financials', true, 'manageRoles', false)
    ),
    jsonb_build_object(
      'id', '10000000-0000-4000-8000-000000000005',
      'name', 'Events Coordinator',
      'permissions', jsonb_build_object('events', true, 'announcements', false, 'members', false, 'settings', false, 'financials', false, 'manageRoles', false)
    ),
    jsonb_build_object(
      'id', '10000000-0000-4000-8000-000000000006',
      'name', 'Technical Officer',
      'permissions', jsonb_build_object('events', false, 'announcements', false, 'members', true, 'settings', false, 'financials', false, 'manageRoles', false)
    )
  );
$$;

update public.club_workspaces
set data = jsonb_set(data, '{roles}', public.default_club_roles(), true)
where jsonb_typeof(data -> 'roles') is distinct from 'array';

create or replace function public.create_club(p_name text)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  new_workspace_id uuid;
  new_invite_code text;
  display_name text;
begin
  if auth.uid() is null then
    raise exception 'You must be signed in to create a club.';
  end if;

  if exists (select 1 from public.club_members where user_id = auth.uid()) then
    raise exception 'This account already belongs to a club.';
  end if;

  if char_length(trim(p_name)) not between 1 and 60 then
    raise exception 'Club name must be between 1 and 60 characters.';
  end if;

  display_name := coalesce(nullif(trim(auth.jwt() -> 'user_metadata' ->> 'display_name'), ''), 'Club admin');
  new_invite_code := upper(substr(replace(pg_catalog.gen_random_uuid()::text, '-', ''), 1, 32));

  insert into public.club_workspaces (name, invite_code, data)
  values (
    trim(p_name),
    new_invite_code,
    jsonb_build_object(
      'clubName', trim(p_name),
      'adminName', display_name,
      'events', '[]'::jsonb,
      'members', '[]'::jsonb,
      'announcements', '[]'::jsonb,
      'rsvps', '{}'::jsonb,
      'roles', public.default_club_roles()
    )
  )
  returning id into new_workspace_id;

  insert into public.club_members (workspace_id, user_id, display_name, role)
  values (new_workspace_id, auth.uid(), display_name, 'owner');

  return new_workspace_id;
end;
$$;

create or replace function public.has_club_permission(p_workspace_id uuid, p_permission text)
returns boolean
language sql
security definer
set search_path = ''
stable
as $$
  select exists (
    select 1
    from public.club_members as membership
    where membership.workspace_id = p_workspace_id
      and membership.user_id = auth.uid()
      and membership.role = 'owner'
      and membership.membership_status = 'active'
  ) or exists (
    select 1
    from public.club_members as membership
    join public.club_workspaces as workspace on workspace.id = membership.workspace_id
    cross join lateral jsonb_array_elements(coalesce(workspace.data -> 'roles', '[]'::jsonb)) as entries(role_definition)
    where membership.workspace_id = p_workspace_id
      and membership.user_id = auth.uid()
      and membership.membership_status = 'active'
      and membership.position_role_id::text = entries.role_definition ->> 'id'
      and entries.role_definition -> 'permissions' ->> p_permission = 'true'
  );
$$;

create or replace function public.save_club_roles(p_workspace_id uuid, p_roles jsonb)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  current_data jsonb;
  role_definition jsonb;
  permission_name text;
  permission_value jsonb;
begin
  if auth.uid() is null or not public.has_club_permission(p_workspace_id, 'manageRoles') then
    raise exception 'You do not have permission to manage club roles.';
  end if;

  if jsonb_typeof(p_roles) is distinct from 'array' then
    raise exception 'Club role definitions must be an array.';
  end if;
  if jsonb_array_length(p_roles) > 50 then
    raise exception 'A club can have at most 50 roles.';
  end if;

  for role_definition in select value from jsonb_array_elements(p_roles)
  loop
    if jsonb_typeof(role_definition) is distinct from 'object'
      or coalesce(role_definition ->> 'id', '') !~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
      or char_length(trim(coalesce(role_definition ->> 'name', ''))) not between 1 and 50
      or jsonb_typeof(role_definition -> 'permissions') is distinct from 'object'
      or not (role_definition -> 'permissions' ?& array['events', 'announcements', 'members', 'settings', 'financials', 'manageRoles']) then
      raise exception 'Club role definitions are invalid. Provide a name and all permissions.';
    end if;
    for permission_name, permission_value in
      select key, value from jsonb_each(role_definition -> 'permissions')
    loop
      if permission_name not in ('events', 'announcements', 'members', 'settings', 'financials', 'manageRoles')
        or jsonb_typeof(permission_value) is distinct from 'boolean' then
        raise exception 'Club role definitions contain an invalid permission.';
      end if;
    end loop;
  end loop;

  if (select count(*) from jsonb_array_elements(p_roles)) <>
    (select count(distinct lower(trim(entries.entry ->> 'name'))) from jsonb_array_elements(p_roles) as entries(entry))
    or (select count(*) from jsonb_array_elements(p_roles)) <>
    (select count(distinct entries.entry ->> 'id') from jsonb_array_elements(p_roles) as entries(entry)) then
    raise exception 'Club role names and IDs must be unique.';
  end if;

  select data into current_data
  from public.club_workspaces
  where id = p_workspace_id
  for update;

  if current_data is null then
    raise exception 'The club workspace does not exist.';
  end if;

  if exists (
    select 1
    from public.club_members
    where workspace_id = p_workspace_id
      and position_role_id is not null
      and position_role_id::text not in (
        select entries.entry ->> 'id'
        from jsonb_array_elements(p_roles) as entries(entry)
      )
  ) then
    raise exception 'A role is assigned to a member. Reassign those members before deleting it.';
  end if;

  update public.club_workspaces
  set data = jsonb_set(current_data, '{roles}', p_roles, true)
  where id = p_workspace_id;
end;
$$;

create or replace function public.set_club_member_position(
  p_workspace_id uuid,
  p_user_id uuid,
  p_role_id uuid
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  workspace_data jsonb;
begin
  if auth.uid() is null or not public.has_club_permission(p_workspace_id, 'manageRoles') then
    raise exception 'You do not have permission to assign club roles.';
  end if;

  if not exists (
    select 1 from public.club_members
    where workspace_id = p_workspace_id and user_id = p_user_id
  ) then
    raise exception 'That account does not belong to this club.';
  end if;

  select data into workspace_data
  from public.club_workspaces
  where id = p_workspace_id
  for update;

  if workspace_data is null then
    raise exception 'The club workspace does not exist.';
  end if;

  if p_role_id is not null then
    if not exists (
      select 1 from jsonb_array_elements(coalesce(workspace_data -> 'roles', '[]'::jsonb)) as entries(role_definition)
      where role_definition ->> 'id' = p_role_id::text
    ) then
      raise exception 'Choose a role that belongs to this club.';
    end if;
  end if;

  update public.club_members
  set position_role_id = p_role_id
  where workspace_id = p_workspace_id and user_id = p_user_id;
end;
$$;

create or replace function public.save_club_data(p_workspace_id uuid, p_data jsonb)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  actor_role text;
  actor_status text;
  current_data jsonb;
  safe_data jsonb;
begin
  select role, membership_status into actor_role, actor_status
  from public.club_members
  where workspace_id = p_workspace_id and user_id = auth.uid();

  if auth.uid() is null or actor_role is null or actor_status is distinct from 'active' then
    raise exception 'You do not have access to this club.';
  end if;

  select data into current_data
  from public.club_workspaces
  where id = p_workspace_id
  for update;

  if jsonb_typeof(p_data) is distinct from 'object'
    or jsonb_typeof(p_data -> 'events') is distinct from 'array'
    or jsonb_typeof(p_data -> 'members') is distinct from 'array'
    or jsonb_typeof(p_data -> 'announcements') is distinct from 'array'
    or jsonb_typeof(p_data -> 'rsvps') is distinct from 'object'
    or char_length(coalesce(p_data ->> 'clubName', '')) not between 1 and 60
    or char_length(coalesce(p_data ->> 'adminName', '')) not between 1 and 80 then
    raise exception 'Club data is invalid.';
  end if;

  if jsonb_typeof(coalesce(p_data -> 'rsvps' -> auth.uid()::text, '[]'::jsonb)) is distinct from 'array' then
    raise exception 'Your RSVP data is invalid.';
  end if;

  if exists (
    select 1
    from jsonb_array_elements(coalesce(p_data -> 'rsvps' -> auth.uid()::text, '[]'::jsonb)) as entries(event_id)
    where jsonb_typeof(event_id) is distinct from 'string'
  ) then
    raise exception 'Your RSVP data is invalid.';
  end if;

  safe_data := p_data;
  if not public.has_club_permission(p_workspace_id, 'settings') then
    safe_data := jsonb_set(safe_data, '{clubName}', current_data -> 'clubName');
    safe_data := jsonb_set(safe_data, '{adminName}', current_data -> 'adminName');
  end if;
  if not public.has_club_permission(p_workspace_id, 'events') then
    safe_data := jsonb_set(safe_data, '{events}', current_data -> 'events');
  end if;
  if not public.has_club_permission(p_workspace_id, 'announcements') then
    safe_data := jsonb_set(safe_data, '{announcements}', current_data -> 'announcements');
  end if;
  if not public.has_club_permission(p_workspace_id, 'members') then
    safe_data := jsonb_set(safe_data, '{members}', current_data -> 'members');
  else
    safe_data := jsonb_set(
      safe_data,
      '{members}',
      coalesce((
        select jsonb_agg(member)
        from jsonb_array_elements(p_data -> 'members') as entries(member)
        where member ->> 'userId' is null
      ), '[]'::jsonb) || coalesce((
        select jsonb_agg(member)
        from jsonb_array_elements(current_data -> 'members') as entries(member)
        where member ->> 'userId' is not null
      ), '[]'::jsonb)
    );
  end if;

  safe_data := jsonb_set(safe_data, '{roles}', coalesce(current_data -> 'roles', '[]'::jsonb), true);
  safe_data := jsonb_set(
    safe_data,
    '{rsvps}',
    (current_data -> 'rsvps') || jsonb_build_object(
      auth.uid()::text,
      coalesce(p_data -> 'rsvps' -> auth.uid()::text, current_data -> 'rsvps' -> auth.uid()::text, '[]'::jsonb)
    )
  );

  update public.club_workspaces
  set data = safe_data, name = safe_data ->> 'clubName'
  where id = p_workspace_id;
end;
$$;

create or replace function public.remove_club_member(p_workspace_id uuid, p_user_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  if not public.has_club_permission(p_workspace_id, 'members') then
    raise exception 'You do not have permission to remove club members.';
  end if;

  if p_user_id = auth.uid() then
    raise exception 'You cannot remove your own club membership.';
  end if;

  if not exists (
    select 1 from public.club_members
    where workspace_id = p_workspace_id and user_id = p_user_id and role = 'member'
  ) then
    raise exception 'That member cannot be removed.';
  end if;

  delete from public.club_members
  where workspace_id = p_workspace_id and user_id = p_user_id;

  update public.club_workspaces
  set data = jsonb_set(
    data,
    '{members}',
    coalesce((
      select jsonb_agg(member)
      from jsonb_array_elements(data -> 'members') as entries(member)
      where member ->> 'userId' is distinct from p_user_id::text
    ), '[]'::jsonb)
  )
  where id = p_workspace_id;
end;
$$;

revoke all on function public.default_club_roles() from public;
revoke all on function public.has_club_permission(uuid, text) from public;
revoke all on function public.save_club_roles(uuid, jsonb) from public;
revoke all on function public.set_club_member_position(uuid, uuid, uuid) from public;
grant execute on function public.has_club_permission(uuid, text) to authenticated;
grant execute on function public.save_club_roles(uuid, jsonb) to authenticated;
grant execute on function public.set_club_member_position(uuid, uuid, uuid) to authenticated;

do $$
begin
  if not exists (
    select 1
    from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'club_members'
  ) then
    alter publication supabase_realtime add table public.club_members;
  end if;
end;
$$;
