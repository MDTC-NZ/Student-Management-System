alter table public.club_members
  add column membership_status text not null default 'active'
  check (membership_status in ('pending', 'active', 'inactive'));

create or replace function public.is_club_member(p_workspace_id uuid)
returns boolean
language sql
security definer
set search_path = ''
stable
as $$
  select exists (
    select 1 from public.club_members
    where workspace_id = p_workspace_id
      and user_id = auth.uid()
      and membership_status = 'active'
  );
$$;

drop policy "Users can see memberships in their workspace" on public.club_members;

create policy "Users can see memberships in their workspace"
  on public.club_members for select to authenticated
  using (user_id = auth.uid() or public.is_club_member(workspace_id));
