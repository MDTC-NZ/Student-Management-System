create table public.club_chat_messages (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.club_workspaces(id) on delete cascade,
  user_id uuid references auth.users(id) on delete set null,
  display_name text not null check (char_length(display_name) between 1 and 80),
  channel text not null check (channel in ('general', 'events', 'announcements')),
  content text not null check (char_length(btrim(content)) between 1 and 2000),
  created_at timestamptz not null default now()
);

create index club_chat_messages_workspace_channel_created_idx
  on public.club_chat_messages(workspace_id, channel, created_at desc);

alter table public.club_chat_messages enable row level security;

create policy "Active club members can read chat"
  on public.club_chat_messages for select to authenticated
  using (public.is_club_member(workspace_id));

create policy "Active club members can send chat messages"
  on public.club_chat_messages for insert to authenticated
  with check (
    user_id = auth.uid()
    and public.is_club_member(workspace_id)
  );

create policy "Authors and club admins can delete chat messages"
  on public.club_chat_messages for delete to authenticated
  using (
    public.is_club_member(workspace_id)
    and (
      user_id = auth.uid()
      or exists (
        select 1
        from public.club_members as membership
        where membership.workspace_id = club_chat_messages.workspace_id
          and membership.user_id = auth.uid()
          and membership.role = 'owner'
          and membership.membership_status = 'active'
      )
    )
  );

create or replace function public.set_club_chat_message_author()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  select membership.display_name
  into new.display_name
  from public.club_members as membership
  where membership.workspace_id = new.workspace_id
    and membership.user_id = auth.uid()
    and membership.membership_status = 'active';

  if new.display_name is null then
    raise exception 'Only active members of this club can send messages.';
  end if;

  return new;
end;
$$;

create trigger set_club_chat_message_author
  before insert on public.club_chat_messages
  for each row execute function public.set_club_chat_message_author();

revoke all on function public.set_club_chat_message_author() from public;

grant select, insert, delete on public.club_chat_messages to authenticated;

do $$
begin
  if not exists (
    select 1
    from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'club_chat_messages'
  ) then
    alter publication supabase_realtime add table public.club_chat_messages;
  end if;
end;
$$;
