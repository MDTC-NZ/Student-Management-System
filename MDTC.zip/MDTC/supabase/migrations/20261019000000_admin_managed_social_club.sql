create or replace function public.save_club_data(p_workspace_id uuid, p_data jsonb)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  actor_role text;
  current_data jsonb;
  safe_data jsonb;
begin
  select role into actor_role
  from public.club_members
  where workspace_id = p_workspace_id and user_id = auth.uid();

  if auth.uid() is null or actor_role is null then
    raise exception 'You do not have access to this club.';
  end if;

  select data into current_data
  from public.club_workspaces
  where id = p_workspace_id
  for update;

  if jsonb_typeof(p_data) is distinct from 'object'
    or jsonb_typeof(p_data -> 'events') is distinct from 'array'
    or jsonb_typeof(p_data -> 'members') is distinct from 'array'
    or jsonb_typeof(p_data -> 'announcements') is distinct from 'array'
    or jsonb_typeof(p_data -> 'rsvps') is distinct from 'object'
    or char_length(coalesce(p_data ->> 'clubName', '')) not between 1 and 60
    or char_length(coalesce(p_data ->> 'adminName', '')) not between 1 and 80 then
    raise exception 'Club data is invalid.';
  end if;

  if jsonb_typeof(coalesce(p_data -> 'rsvps' -> auth.uid()::text, '[]'::jsonb)) is distinct from 'array' then
    raise exception 'Your RSVP data is invalid.';
  end if;

  if exists (
    select 1
    from jsonb_array_elements(coalesce(p_data -> 'rsvps' -> auth.uid()::text, '[]'::jsonb)) as entries(event_id)
    where jsonb_typeof(event_id) is distinct from 'string'
  ) then
    raise exception 'Your RSVP data is invalid.';
  end if;

  safe_data := p_data;
  if actor_role = 'owner' then
    safe_data := jsonb_set(
      safe_data,
      '{members}',
      coalesce((
        select jsonb_agg(member)
        from jsonb_array_elements(p_data -> 'members') as entries(member)
        where member ->> 'userId' is null
      ), '[]'::jsonb) || coalesce((
        select jsonb_agg(member)
        from jsonb_array_elements(current_data -> 'members') as entries(member)
        where member ->> 'userId' is not null
      ), '[]'::jsonb)
    );
  else
    safe_data := jsonb_set(safe_data, '{clubName}', current_data -> 'clubName');
    safe_data := jsonb_set(safe_data, '{adminName}', current_data -> 'adminName');
    safe_data := jsonb_set(safe_data, '{members}', current_data -> 'members');
    safe_data := jsonb_set(safe_data, '{events}', current_data -> 'events');
    safe_data := jsonb_set(safe_data, '{announcements}', current_data -> 'announcements');
  end if;

  safe_data := jsonb_set(
    safe_data,
    '{rsvps}',
    (current_data -> 'rsvps') || jsonb_build_object(
      auth.uid()::text,
      coalesce(p_data -> 'rsvps' -> auth.uid()::text, current_data -> 'rsvps' -> auth.uid()::text, '[]'::jsonb)
    )
  );

  update public.club_workspaces
  set data = safe_data, name = safe_data ->> 'clubName'
  where id = p_workspace_id;
end;
$$;
