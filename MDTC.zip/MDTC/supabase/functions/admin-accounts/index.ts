import { createClient } from 'npm:@supabase/supabase-js@2'

type Action = 'list' | 'update-profile' | 'confirm-email' | 'send-reset' | 'set-ban' | 'set-role' | 'set-position-role' | 'set-membership-status' | 'delete'

const siteUrl = Deno.env.get('PUBLIC_SITE_URL') ?? 'https://mdtc.kiaoragaming.xyz'
const allowedOrigins = new Set([
  siteUrl.replace(/\/+$/, ''),
  ...(Deno.env.get('ADMIN_ALLOWED_ORIGINS') ?? '').split(',').map((origin) => origin.trim().replace(/\/+$/, '')).filter(Boolean),
])
const corsHeaders = (origin: string) => ({
  'Access-Control-Allow-Origin': origin,
  'Access-Control-Allow-Headers': 'authorization, apikey, x-client-info, x-supabase-api-version, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Vary': 'Origin',
})

function jsonResponse(body: unknown, status: number, origin: string) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders(origin), 'Content-Type': 'application/json' },
  })
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null
}

Deno.serve(async (request) => {
  const origin = request.headers.get('Origin') ?? ''
  if (!allowedOrigins.has(origin.replace(/\/+$/, ''))) {
    return new Response('Origin is not allowed.', { status: 403 })
  }
  if (request.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders(origin) })
  if (request.method !== 'POST') return jsonResponse({ error: 'Method not allowed.' }, 405, origin)

  const supabaseUrl = Deno.env.get('SUPABASE_URL')
  const anonKey = Deno.env.get('SUPABASE_ANON_KEY')
  const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')
  const superadminEmail = Deno.env.get('SUPERADMIN_EMAIL')?.trim().toLowerCase()
  if (!supabaseUrl || !anonKey || !serviceRoleKey || !superadminEmail) {
    console.error('Admin function is missing required Supabase configuration.')
    return jsonResponse({ error: 'The account-management service is not configured.' }, 500, origin)
  }

  const authorization = request.headers.get('Authorization')
  const accessToken = authorization?.match(/^Bearer\s+(.+)$/i)?.[1]
  if (!accessToken) return jsonResponse({ error: 'Sign in to continue.' }, 401, origin)

  const userClient = createClient(supabaseUrl, anonKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  })
  const { data: authData, error: authError } = await userClient.auth.getUser(accessToken)
  if (authError || !authData.user || authData.user.email?.trim().toLowerCase() !== superadminEmail) {
    return jsonResponse({ error: 'This account is not authorized to manage club accounts.' }, 403, origin)
  }

  const admin = createClient(supabaseUrl, serviceRoleKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  })
  const { data: workspaces, error: workspaceLookupError } = await admin
    .from('club_workspaces')
    .select('id')
    .ilike('name', 'Manukau Digital Tech Collective')
    .limit(2)
  if (workspaceLookupError) {
    console.error('Unable to find the MDTC workspace:', workspaceLookupError.message)
    return jsonResponse({ error: 'Could not find the Manukau Digital Tech Collective workspace.' }, 500, origin)
  }
  if (workspaces?.length !== 1) {
    console.error(`Expected one MDTC workspace; found ${workspaces?.length ?? 0}.`)
    return jsonResponse({ error: 'Could not uniquely identify the Manukau Digital Tech Collective workspace.' }, 500, origin)
  }
  const workspaceId = workspaces[0].id
  const { data: superadminMembership, error: superadminMembershipError } = await admin
    .from('club_members')
    .select('role,membership_status')
    .eq('workspace_id', workspaceId)
    .eq('user_id', authData.user.id)
    .maybeSingle()
  if (superadminMembershipError) {
    console.error('Unable to verify superadmin club membership:', superadminMembershipError.message)
    return jsonResponse({ error: 'Could not verify club access.' }, 500, origin)
  }
  if (superadminMembership?.role !== 'owner' || superadminMembership.membership_status !== 'active') {
    return jsonResponse({ error: 'The superadmin account must be a club administrator.' }, 403, origin)
  }

  let body: Record<string, unknown>
  try {
    const parsed: unknown = await request.json()
    if (!isObject(parsed)) return jsonResponse({ error: 'Invalid request.' }, 400, origin)
    body = parsed
  } catch (error) {
    console.error('Unable to read account-management request:', error)
    return jsonResponse({ error: 'Invalid request body.' }, 400, origin)
  }

  const action = body.action as Action
  if (!['list', 'update-profile', 'confirm-email', 'send-reset', 'set-ban', 'set-role', 'set-position-role', 'set-membership-status', 'delete'].includes(action)) {
    return jsonResponse({ error: 'Unknown account-management action.' }, 400, origin)
  }

  const { data: memberships, error: membershipsError } = await admin
    .from('club_members')
    .select('user_id,display_name,role,position_role_id,membership_status,joined_at')
    .eq('workspace_id', workspaceId)
    .order('joined_at', { ascending: true })
  if (membershipsError) {
    console.error('Unable to list club memberships:', membershipsError.message)
    return jsonResponse({ error: 'Could not load club accounts.' }, 500, origin)
  }
  const membershipById = new Map((memberships ?? []).map((membership) => [membership.user_id, membership]))
  const targetUserId = typeof body.userId === 'string' ? body.userId : ''
  const targetMembership = membershipById.get(targetUserId)
  if (action !== 'list' && (!targetUserId || !targetMembership)) {
    return jsonResponse({ error: 'That account does not belong to this club.' }, 404, origin)
  }

  try {
    if (action === 'list') {
      const accounts = []
      const membershipIds = new Set(membershipById.keys())
      for (let page = 1; membershipIds.size > 0; page++) {
        const { data, error } = await admin.auth.admin.listUsers({ page, perPage: 1000 })
        if (error) throw error
        for (const account of data.users) {
          if (!membershipIds.has(account.id)) continue
          const membership = membershipById.get(account.id)
          if (!membership) continue
          accounts.push({
            id: account.id,
            email: account.email ?? '',
            emailConfirmed: Boolean(account.email_confirmed_at),
            name: String(account.user_metadata.display_name ?? membership.display_name),
            role: membership.role,
            positionRoleId: membership.position_role_id,
            membershipStatus: membership.membership_status,
            banned: Boolean(account.banned_until && Date.parse(account.banned_until) > Date.now()),
            createdAt: account.created_at,
          })
          membershipIds.delete(account.id)
        }
        if (data.users.length < 1000) break
      }
      return jsonResponse({ accounts }, 200, origin)
    }

    if (!targetUserId || !targetMembership) {
      return jsonResponse({ error: 'That account does not belong to this club.' }, 404, origin)
    }

    if (targetUserId === authData.user.id && action !== 'update-profile' && action !== 'set-position-role') {
      return jsonResponse({ error: 'The superadmin account cannot be confirmed, disabled, deleted, reset here, or demoted.' }, 403, origin)
    }

    if (action === 'set-membership-status' && !['pending', 'active', 'inactive'].includes(String(body.status))) {
      return jsonResponse({ error: 'Choose pending, active, or inactive membership status.' }, 400, origin)
    }

    if ((action === 'delete'
      || (action === 'set-ban' && body.banned === true)
      || (action === 'set-role' && body.role === 'member')
      || (action === 'set-membership-status' && body.status !== 'active'))
      && targetMembership.role === 'owner') {
      const ownerIds = new Set((memberships ?? [])
        .filter((membership) => membership.role === 'owner' && membership.membership_status === 'active')
        .map((membership) => membership.user_id))
      let activeOwnerCount = 0
      let targetIsActiveOwner = false
      for (let page = 1; ownerIds.size > 0; page++) {
        const { data, error } = await admin.auth.admin.listUsers({ page, perPage: 1000 })
        if (error) throw error
        for (const account of data.users) {
          if (!ownerIds.has(account.id)) continue
          const active = !account.banned_until || Date.parse(account.banned_until) <= Date.now()
          if (active) activeOwnerCount++
          if (account.id === targetUserId) targetIsActiveOwner = active
          ownerIds.delete(account.id)
        }
        if (data.users.length < 1000) break
      }
      if (targetIsActiveOwner && activeOwnerCount <= 1) {
        return jsonResponse({ error: 'The club must keep at least one active administrator.' }, 409, origin)
      }
    }

    if (action === 'confirm-email') {
      if (targetUserId === authData.user.id) {
        return jsonResponse({ error: 'The superadmin cannot confirm their own email from this panel.' }, 403, origin)
      }
      const { data: target, error: targetError } = await admin.auth.admin.getUserById(targetUserId)
      if (targetError || !target.user) throw targetError ?? new Error('Could not find the account.')
      if (target.user.email_confirmed_at) {
        return jsonResponse({ success: true, message: 'This email address is already confirmed.' }, 200, origin)
      }
      const { error } = await admin.auth.admin.updateUserById(targetUserId, { email_confirm: true })
      if (error) throw error
      return jsonResponse({ success: true, message: `Email confirmed for ${target.user.email}.` }, 200, origin)
    }

    if (action === 'update-profile') {
      const email = typeof body.email === 'string' ? body.email.trim().toLowerCase() : ''
      const name = typeof body.name === 'string' ? body.name.trim() : ''
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) {
        return jsonResponse({ error: 'Enter a valid email address.' }, 400, origin)
      }
      if (!name || name.length > 80) return jsonResponse({ error: 'Display name must be between 1 and 80 characters.' }, 400, origin)
      if (email === superadminEmail || targetUserId === authData.user.id) {
        return jsonResponse({ error: 'The superadmin email and account cannot be changed here.' }, 403, origin)
      }
      const { data: target, error: targetError } = await admin.auth.admin.getUserById(targetUserId)
      if (targetError || !target.user) throw targetError ?? new Error('Could not find the account.')
      const { error } = await admin.auth.admin.updateUserById(targetUserId, {
        email,
        user_metadata: { ...target.user.user_metadata, display_name: name },
      })
      if (error) throw error
      const { error: membershipUpdateError } = await admin
        .from('club_members')
        .update({ display_name: name })
        .eq('workspace_id', workspaceId)
        .eq('user_id', targetUserId)
      if (membershipUpdateError) throw membershipUpdateError
      const { data: workspace, error: workspaceReadError } = await admin
        .from('club_workspaces')
        .select('data')
        .eq('id', workspaceId)
        .single()
      if (workspaceReadError) throw workspaceReadError
      if (isObject(workspace.data) && Array.isArray(workspace.data.members)) {
        const updatedMembers = workspace.data.members.map((member) =>
          isObject(member) && member.userId === targetUserId ? { ...member, name } : member)
        const { error: workspaceUpdateError } = await admin
          .from('club_workspaces')
          .update({ data: { ...workspace.data, members: updatedMembers } })
          .eq('id', workspaceId)
        if (workspaceUpdateError) throw workspaceUpdateError
      }
      return jsonResponse({ success: true, message: 'Account details updated. Supabase may ask the user to confirm the new email.' }, 200, origin)
    }

    if (action === 'send-reset') {
      const { data: target, error: targetError } = await admin.auth.admin.getUserById(targetUserId)
      if (targetError || !target.user?.email) throw targetError ?? new Error('This account does not have an email address.')
      const { error } = await userClient.auth.resetPasswordForEmail(target.user.email, {
        redirectTo: siteUrl.replace(/\/+$/, ''),
      })
      if (error) throw error
      return jsonResponse({ success: true, message: 'Password reset email sent.' }, 200, origin)
    }

    if (action === 'set-ban') {
      if (typeof body.banned !== 'boolean') return jsonResponse({ error: 'Choose whether to suspend or reactivate the account.' }, 400, origin)
      const { error } = await admin.auth.admin.updateUserById(targetUserId, {
        ban_duration: body.banned ? '876000h' : 'none',
      })
      if (error) throw error
      return jsonResponse({ success: true, message: body.banned ? 'Account suspended. Existing sign-in sessions may remain active until their access tokens expire.' : 'Account reactivated.' }, 200, origin)
    }

    if (action === 'set-role') {
      if (body.role !== 'owner' && body.role !== 'member') {
        return jsonResponse({ error: 'Choose member or club administrator.' }, 400, origin)
      }
      if (targetUserId === authData.user.id && body.role !== 'owner') {
        return jsonResponse({ error: 'The superadmin account must remain a club administrator.' }, 403, origin)
      }
      const { error } = await admin
        .from('club_members')
        .update({ role: body.role })
        .eq('workspace_id', workspaceId)
        .eq('user_id', targetUserId)
      if (error) throw error
      return jsonResponse({ success: true, message: 'Club role updated.' }, 200, origin)
    }

    if (action === 'set-position-role') {
      const roleId = body.roleId === null || body.roleId === '' ? null : body.roleId
      if (roleId !== null && (typeof roleId !== 'string' || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(roleId))) {
        return jsonResponse({ error: 'Choose a valid club position.' }, 400, origin)
      }
      if (roleId !== null) {
        const { data: workspace, error: workspaceError } = await admin
          .from('club_workspaces')
          .select('data')
          .eq('id', workspaceId)
          .single()
        if (workspaceError) throw workspaceError
        const workspaceData: unknown = workspace.data
        const roleList = isObject(workspaceData) && Array.isArray(workspaceData.roles) ? workspaceData.roles : []
        if (!roleList.some((role) => isObject(role) && role.id === roleId)) {
          return jsonResponse({ error: 'Choose a role that belongs to this club.' }, 400, origin)
        }
      }
      const { error } = await admin
        .from('club_members')
        .update({ position_role_id: roleId })
        .eq('workspace_id', workspaceId)
        .eq('user_id', targetUserId)
      if (error) throw error
      return jsonResponse({ success: true, message: 'Club position updated.' }, 200, origin)
    }

    if (action === 'set-membership-status') {
      const status = body.status
      if (status !== 'pending' && status !== 'active' && status !== 'inactive') {
        return jsonResponse({ error: 'Choose pending, active, or inactive membership status.' }, 400, origin)
      }
      const { error } = await admin
        .from('club_members')
        .update({ membership_status: status })
        .eq('workspace_id', workspaceId)
        .eq('user_id', targetUserId)
      if (error) throw error
      return jsonResponse({
        success: true,
        message: status === 'active'
          ? 'Membership activated. The member can access the club.'
          : `Membership set to ${status}. The member can no longer access the club.`,
      }, 200, origin)
    }

    if (action === 'delete') {
      const { error } = await admin.auth.admin.deleteUser(targetUserId)
      if (error) throw error
      return jsonResponse({ success: true, message: 'Account permanently deleted.' }, 200, origin)
    }
  } catch (error) {
    console.error(`Admin account action failed (${action}):`, error)
    return jsonResponse({ error: error instanceof Error ? error.message : 'Account action failed.' }, 500, origin)
  }

  return jsonResponse({ error: 'Account action was not completed.' }, 500, origin)
})
