import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  preview: {
    host: '0.0.0.0',
    port: 4174,
    strictPort: true,
    allowedHosts: ['mdtc.kiaoragaming.xyz'],
  },
})