import { createClient } from '@supabase/supabase-js'

const projectUrl = import.meta.env.VITE_SUPABASE_URL
const publishableKey = import.meta.env.VITE_SUPABASE_ANON_KEY
const configuredSiteUrl = import.meta.env.VITE_PUBLIC_SITE_URL?.trim()

export const backendConfigured = Boolean(projectUrl && publishableKey)
export const supabase = backendConfigured ? createClient(projectUrl, publishableKey) : null
export const authRedirectUrl = configuredSiteUrl
  ? configuredSiteUrl.replace(/\/+$/, '')
  : null
