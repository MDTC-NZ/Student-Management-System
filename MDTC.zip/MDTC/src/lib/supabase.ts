import { createClient } from '@supabase/supabase-js'

const projectUrl = import.meta.env.VITE_SUPABASE_URL
const publishableKey = import.meta.env.VITE_SUPABASE_ANON_KEY

export const backendConfigured = Boolean(projectUrl && publishableKey)
export const supabase = backendConfigured ? createClient(projectUrl, publishableKey) : null
