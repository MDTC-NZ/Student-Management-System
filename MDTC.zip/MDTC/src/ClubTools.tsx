import { useCallback, useEffect, useState, type FormEvent } from 'react'
import {
  CalendarCheck, Check, ClipboardList, Clock3, Download, Pencil, Plus, Trash2, Users, X,
} from 'lucide-react'
import { supabase } from './lib/supabase'

type ClubToolTab = 'attendance' | 'tasks' | 'volunteer'
type ToolEvent = { id: string; title: string; date: string }
type ToolMember = { userId?: string; name: string }
type AttendanceRecord = { id: string; workspace_id: string; event_id: string; user_id: string | null; display_name: string; status: 'present' | 'absent' | 'excused'; marked_at: string }
type ClubTask = { id: string; workspace_id: string; title: string; description: string; due_on: string | null; status: 'open' | 'in_progress' | 'done'; created_by: string | null; created_by_name: string; assigned_to: string | null; assignee_name: string | null; created_at: string }
type VolunteerEntry = { id: string; workspace_id: string; submitted_by: string | null; volunteer_name: string; service_date: string; minutes_spent: number; description: string; status: 'pending' | 'approved' | 'rejected'; reviewed_by: string | null; reviewed_at: string | null; created_at: string }

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null
}

function isAttendance(value: unknown): value is AttendanceRecord {
  return isRecord(value)
    && typeof value.id === 'string'
    && typeof value.workspace_id === 'string'
    && typeof value.event_id === 'string'
    && (typeof value.user_id === 'string' || value.user_id === null)
    && typeof value.display_name === 'string'
    && (value.status === 'present' || value.status === 'absent' || value.status === 'excused')
    && typeof value.marked_at === 'string'
}

function isTask(value: unknown): value is ClubTask {
  return isRecord(value)
    && typeof value.id === 'string'
    && typeof value.workspace_id === 'string'
    && typeof value.title === 'string'
    && typeof value.description === 'string'
    && (typeof value.due_on === 'string' || value.due_on === null)
    && (value.status === 'open' || value.status === 'in_progress' || value.status === 'done')
    && (typeof value.created_by === 'string' || value.created_by === null)
    && typeof value.created_by_name === 'string'
    && (typeof value.assigned_to === 'string' || value.assigned_to === null)
    && (typeof value.assignee_name === 'string' || value.assignee_name === null)
    && typeof value.created_at === 'string'
}

function isVolunteerEntry(value: unknown): value is VolunteerEntry {
  return isRecord(value)
    && typeof value.id === 'string'
    && typeof value.workspace_id === 'string'
    && (typeof value.submitted_by === 'string' || value.submitted_by === null)
    && typeof value.volunteer_name === 'string'
    && typeof value.service_date === 'string'
    && typeof value.minutes_spent === 'number'
    && Number.isSafeInteger(value.minutes_spent)
    && typeof value.description === 'string'
    && (value.status === 'pending' || value.status === 'approved' || value.status === 'rejected')
    && (typeof value.reviewed_by === 'string' || value.reviewed_by === null)
    && (typeof value.reviewed_at === 'string' || value.reviewed_at === null)
    && typeof value.created_at === 'string'
}

function today() {
  const date = new Date()
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`
}

function durationLabel(minutes: number) {
  const hours = Math.floor(minutes / 60)
  const remainder = minutes % 60
  if (!hours) return `${remainder} min`
  if (!remainder) return `${hours} hr`
  return `${hours} hr ${remainder} min`
}

function exportCsv(fileName: string, headings: string[], rows: string[][]) {
  const cell = (value: string) => `"${value.replace(/"/g, '""')}"`
  const content = [headings, ...rows].map((row) => row.map(cell).join(',')).join('\r\n')
  const url = URL.createObjectURL(new Blob([content], { type: 'text/csv;charset=utf-8' }))
  const link = document.createElement('a')
  link.href = url
  link.download = fileName
  link.click()
  URL.revokeObjectURL(url)
}

const toolTabs: { id: ClubToolTab; label: string; icon: typeof ClipboardList }[] = [
  { id: 'attendance', label: 'Attendance', icon: CalendarCheck },
  { id: 'tasks', label: 'Tasks', icon: ClipboardList },
  { id: 'volunteer', label: 'Volunteer hours', icon: Clock3 },
]

export function ClubTools({ workspaceId, userId, events, members, canManageAttendance, canManageTasks, canManageVolunteerHours }: {
  workspaceId: string
  userId: string
  events: ToolEvent[]
  members: ToolMember[]
  canManageAttendance: boolean
  canManageTasks: boolean
  canManageVolunteerHours: boolean
}) {
  const [tab, setTab] = useState<ClubToolTab>('attendance')
  const [selectedEventId, setSelectedEventId] = useState(events[0]?.id ?? '')
  const [attendance, setAttendance] = useState<AttendanceRecord[]>([])
  const [tasks, setTasks] = useState<ClubTask[]>([])
  const [volunteerEntries, setVolunteerEntries] = useState<VolunteerEntry[]>([])
  const [loading, setLoading] = useState(true)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [taskEditor, setTaskEditor] = useState<ClubTask | null | undefined>(undefined)

  const refresh = useCallback(async () => {
    if (!supabase) {
      setError('The club tools service is not configured.')
      setLoading(false)
      return
    }
    try {
      const [attendanceResult, tasksResult, hoursResult] = await Promise.all([
        supabase.from('club_event_attendance')
          .select('id,workspace_id,event_id,user_id,display_name,status,marked_at')
          .eq('workspace_id', workspaceId)
          .order('marked_at', { ascending: false }),
        supabase.from('club_tasks')
          .select('id,workspace_id,title,description,due_on,status,created_by,created_by_name,assigned_to,assignee_name,created_at')
          .eq('workspace_id', workspaceId)
          .order('due_on', { ascending: true, nullsFirst: false })
          .order('created_at', { ascending: false }),
        supabase.from('club_volunteer_hours')
          .select('id,workspace_id,submitted_by,volunteer_name,service_date,minutes_spent,description,status,reviewed_by,reviewed_at,created_at')
          .eq('workspace_id', workspaceId)
          .order('service_date', { ascending: false })
          .order('created_at', { ascending: false }),
      ])
      const failed = attendanceResult.error ?? tasksResult.error ?? hoursResult.error
      if (failed) {
        console.error('Unable to load club tools:', failed)
        setError(failed.message)
      } else {
        setAttendance((attendanceResult.data ?? []).filter(isAttendance))
        setTasks((tasksResult.data ?? []).filter(isTask))
        setVolunteerEntries((hoursResult.data ?? []).filter(isVolunteerEntry))
      }
    } catch (loadError: unknown) {
      console.error('Unable to load club tools:', loadError)
      setError(loadError instanceof Error ? loadError.message : 'Unable to load club tools.')
    } finally {
      setLoading(false)
    }
  }, [workspaceId])

  useEffect(() => {
    void refresh()
    if (!supabase) return
    const client = supabase
    const realtime = client.channel(`club-tools-${workspaceId}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'club_event_attendance', filter: `workspace_id=eq.${workspaceId}` }, () => { void refresh() })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'club_tasks', filter: `workspace_id=eq.${workspaceId}` }, () => { void refresh() })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'club_volunteer_hours', filter: `workspace_id=eq.${workspaceId}` }, () => { void refresh() })
      .subscribe((status) => {
        if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') {
          console.error('Realtime club tools updates failed:', status)
          setError('Live club-tool updates are unavailable. Refresh to see the latest changes.')
        }
      })
    return () => { void client.removeChannel(realtime) }
  }, [workspaceId, refresh])

  useEffect(() => {
    if (events.length && !events.some((event) => event.id === selectedEventId)) {
      setSelectedEventId(events[0].id)
    } else if (!events.length && selectedEventId) {
      setSelectedEventId('')
    }
  }, [events, selectedEventId])

  const selectedEvent = events.find((event) => event.id === selectedEventId)
  const eventAttendance = attendance.filter((entry) => entry.event_id === selectedEventId)
  const ownAttendance = eventAttendance.find((entry) => entry.user_id === userId)
  const approvedVolunteerMinutes = volunteerEntries
    .filter((entry) => entry.status === 'approved')
    .reduce((sum, entry) => sum + entry.minutes_spent, 0)
  const pendingVolunteerCount = volunteerEntries.filter((entry) => entry.status === 'pending').length

  async function checkIn() {
    if (!supabase || !selectedEvent || busy || selectedEvent.date > today()) return
    setBusy(true)
    setError('')
    const { error: checkInError } = await supabase.from('club_event_attendance')
      .insert({ workspace_id: workspaceId, event_id: selectedEvent.id, user_id: userId, status: 'present' })
    if (checkInError) {
      console.error('Unable to record event attendance:', checkInError)
      setError(checkInError.message)
    } else {
      await refresh()
    }
    setBusy(false)
  }

  async function recordAttendance(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!supabase || !canManageAttendance || !selectedEvent || busy) return
    const formElement = event.currentTarget
    const fields = new FormData(formElement)
    const memberId = String(fields.get('member') ?? '')
    const status = String(fields.get('status') ?? '')
    const member = members.find((entry) => entry.userId === memberId)
    if (!member || !['present', 'absent', 'excused'].includes(status)) {
      setError('Choose a club member and attendance status.')
      return
    }
    setBusy(true)
    setError('')
    const { error: saveError } = await supabase.from('club_event_attendance')
      .upsert({ workspace_id: workspaceId, event_id: selectedEvent.id, user_id: memberId, status }, { onConflict: 'workspace_id,event_id,user_id' })
    if (saveError) {
      console.error('Unable to save event attendance:', saveError)
      setError(saveError.message)
    } else {
      await refresh()
      formElement.reset()
    }
    setBusy(false)
  }

  async function createTask(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!supabase || busy) return
    const fields = new FormData(event.currentTarget)
    const title = String(fields.get('title') ?? '').trim()
    const description = String(fields.get('description') ?? '').trim()
    const dueOn = String(fields.get('due_on') ?? '') || null
    const assignedTo = String(fields.get('assigned_to') ?? '') || null
    if (!title || title.length > 120 || description.length > 1000) {
      setError('Enter a task title and keep its description under 1,000 characters.')
      return
    }
    setBusy(true)
    setError('')
    if (taskEditor) {
      const { data, error: updateError } = await supabase.from('club_tasks')
        .update({ title, description, due_on: dueOn, assigned_to: assignedTo })
        .eq('workspace_id', workspaceId)
        .eq('id', taskEditor.id)
        .select('id')
        .maybeSingle()
      if (updateError) {
        console.error('Unable to edit club task:', updateError)
        setError(updateError.message)
      } else if (!data) {
        setError('You no longer have permission to edit this task.')
      } else {
        setTaskEditor(undefined)
        await refresh()
      }
    } else {
      const { error: createError } = await supabase.from('club_tasks')
        .insert({ workspace_id: workspaceId, title, description, due_on: dueOn, assigned_to: assignedTo })
      if (createError) {
        console.error('Unable to create club task:', createError)
        setError(createError.message)
      } else {
        setTaskEditor(undefined)
        await refresh()
      }
    }
    setBusy(false)
  }

  async function updateTask(task: ClubTask, changes: { status?: ClubTask['status']; assigned_to?: string | null }) {
    if (!supabase || busy) return
    setBusy(true)
    setError('')
    const { data, error: updateError } = await supabase.from('club_tasks')
      .update(changes)
      .eq('workspace_id', workspaceId)
      .eq('id', task.id)
      .select('id')
      .maybeSingle()
    if (updateError) {
      console.error('Unable to update club task:', updateError)
      setError(updateError.message)
    } else if (!data) {
      setError('You no longer have permission to update this task.')
    } else {
      await refresh()
    }
    setBusy(false)
  }

  async function deleteTask(task: ClubTask) {
    if (!supabase || !canManageTasks || busy || !window.confirm(`Delete “${task.title}”?`)) return
    setBusy(true)
    setError('')
    const { error: deleteError } = await supabase.from('club_tasks')
      .delete().eq('workspace_id', workspaceId).eq('id', task.id)
    if (deleteError) {
      console.error('Unable to delete club task:', deleteError)
      setError(deleteError.message)
    } else {
      await refresh()
    }
    setBusy(false)
  }

  async function submitVolunteerHours(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!supabase || busy) return
    const formElement = event.currentTarget
    const fields = new FormData(formElement)
    const description = String(fields.get('description') ?? '').trim()
    const date = String(fields.get('service_date') ?? '')
    const hours = Number(fields.get('hours'))
    const minutesSpent = Math.round(hours * 60)
    if (!description || description.length > 500 || !/^\d{4}-\d{2}-\d{2}$/.test(date)
      || !Number.isFinite(hours) || minutesSpent < 1 || minutesSpent > 1440) {
      setError('Enter a valid date, activity description, and duration up to 24 hours.')
      return
    }
    setBusy(true)
    setError('')
    const { error: submitError } = await supabase.from('club_volunteer_hours')
      .insert({ workspace_id: workspaceId, service_date: date, minutes_spent: minutesSpent, description })
    if (submitError) {
      console.error('Unable to submit volunteer hours:', submitError)
      setError(submitError.message)
    } else {
      await refresh()
      formElement.reset()
    }
    setBusy(false)
  }

  async function reviewVolunteerHours(entry: VolunteerEntry, status: 'approved' | 'rejected') {
    if (!supabase || !canManageVolunteerHours || busy) return
    setBusy(true)
    setError('')
    const { error: reviewError } = await supabase.from('club_volunteer_hours')
      .update({ status })
      .eq('workspace_id', workspaceId)
      .eq('id', entry.id)
    if (reviewError) {
      console.error('Unable to review volunteer hours:', reviewError)
      setError(reviewError.message)
    } else {
      await refresh()
    }
    setBusy(false)
  }

  async function deleteVolunteerEntry(entry: VolunteerEntry) {
    if (!supabase || busy) return
    setBusy(true)
    setError('')
    const { error: deleteError } = await supabase.from('club_volunteer_hours')
      .delete().eq('workspace_id', workspaceId).eq('id', entry.id)
    if (deleteError) {
      console.error('Unable to delete volunteer-hour request:', deleteError)
      setError(deleteError.message)
    } else {
      await refresh()
    }
    setBusy(false)
  }

  return <>
    <div className="page-heading"><div><span className="eyebrow">GET THINGS DONE</span><h1>Club tools</h1><p>Coordinate events, share the workload, and celebrate the time members contribute.</p></div></div>
    {error && <p className="auth-error club-tools-error" role="alert">{error}</p>}
    <nav className="club-tools-tabs" aria-label="Club tools">{toolTabs.map(({ id, label, icon: Icon }) => <button key={id} type="button" className={tab === id ? 'active' : ''} aria-pressed={tab === id} onClick={() => { setTab(id); setError('') }}><Icon size={15} />{label}{id === 'volunteer' && canManageVolunteerHours && pendingVolunteerCount > 0 && <span className="finance-tab-count">{pendingVolunteerCount}</span>}</button>)}</nav>
    {loading && <p className="finance-hint">Loading club tools…</p>}
    {tab === 'attendance' && <section className="panel club-tool-panel">
      <div className="finance-section-heading"><div><span className="section-kicker">EVENT PARTICIPATION</span><h2>Event attendance</h2><p>Members can check in on or after an event date. Attendance managers can record the full register.</p></div>{selectedEvent && <button className="button button-secondary" type="button" onClick={() => exportCsv('club-event-attendance.csv', ['Event', 'Date', 'Member', 'Attendance'], eventAttendance.map((entry) => [selectedEvent.title, selectedEvent.date, entry.display_name, entry.status]))}><Download size={14} />Export</button>}</div>
      {events.length === 0 ? <p className="finance-empty">Add an event to the calendar before taking attendance.</p> : <>
        <label className="club-tool-event-select">Event<select value={selectedEventId} onChange={(event) => setSelectedEventId(event.target.value)}>{events.slice().sort((a, b) => b.date.localeCompare(a.date)).map((event) => <option key={event.id} value={event.id}>{event.date} · {event.title}</option>)}</select></label>
        {selectedEvent && <div className="club-checkin-bar"><span><strong>{selectedEvent.title}</strong><small>{selectedEvent.date} · {eventAttendance.filter((entry) => entry.status === 'present').length} present</small></span>{ownAttendance ? <span className={`finance-status finance-status-${ownAttendance.status}`}>You: {ownAttendance.status}</span> : selectedEvent.date <= today() ? <button className="button button-primary" type="button" disabled={busy} onClick={() => void checkIn()}><Check size={14} />Check in</button> : <span className="finance-hint">Check-in opens on the event date.</span>}</div>}
        {canManageAttendance && <form className="modal-form club-tool-inline-form" onSubmit={(event) => void recordAttendance(event)}><label>Member<select name="member" required defaultValue=""><option value="" disabled>Select a member</option>{members.filter((member) => member.userId).map((member) => <option key={member.userId} value={member.userId}>{member.name}</option>)}</select></label><label>Attendance<select name="status" defaultValue="present"><option value="present">Present</option><option value="absent">Absent</option><option value="excused">Excused</option></select></label><button className="button button-secondary" type="submit" disabled={busy}><Plus size={14} />Save attendance</button></form>}
        {eventAttendance.length > 0 && <div className="club-tool-list">{eventAttendance.slice().sort((a, b) => a.display_name.localeCompare(b.display_name)).map((entry) => <article className="club-tool-row" key={entry.id}><span className="club-tool-avatar"><Users size={15} /></span><div><strong>{entry.display_name}</strong><small>Marked {new Date(entry.marked_at).toLocaleDateString()}</small></div>{canManageAttendance ? <select aria-label={`Attendance for ${entry.display_name}`} value={entry.status} disabled={busy} onChange={(change) => void updateAttendance(entry, change.target.value as AttendanceRecord['status'])}><option value="present">Present</option><option value="absent">Absent</option><option value="excused">Excused</option></select> : <span className={`finance-status finance-status-${entry.status}`}>{entry.status}</span>}</article>)}</div>}
        {eventAttendance.length === 0 && <p className="finance-empty">No attendance recorded for this event yet.</p>}
      </>}
    </section>}
    {tab === 'tasks' && <section className="panel club-tool-panel">
      <div className="finance-section-heading"><div><span className="section-kicker">SHARED TO-DO LIST</span><h2>Club tasks</h2><p>Members can add tasks and update tasks assigned to them. Task managers can organize the full list.</p></div><div className="club-tool-heading-actions"><button className="button button-secondary" type="button" onClick={() => exportCsv('club-tasks.csv', ['Task', 'Details', 'Due date', 'Assignee', 'Status', 'Added by'], tasks.map((task) => [task.title, task.description, task.due_on ?? '', task.assignee_name ?? '', task.status, task.created_by_name]))}><Download size={14} />Export</button><button className="button button-primary" type="button" onClick={() => setTaskEditor((current) => current === undefined ? null : undefined)}><Plus size={14} />{taskEditor === undefined ? 'New task' : 'Close form'}</button></div></div>
      {taskEditor !== undefined && <form className="modal-form club-tool-form" onSubmit={(event) => void createTask(event)}><label>Task<input name="title" required maxLength={120} defaultValue={taskEditor?.title} placeholder="What needs doing?" /></label><label>Details<textarea name="description" rows={2} maxLength={1000} defaultValue={taskEditor?.description} placeholder="Add useful details (optional)" /></label><div className="form-row"><label>Due date<input name="due_on" type="date" defaultValue={taskEditor?.due_on ?? ''} /></label><label>Assign to<select name="assigned_to" defaultValue={taskEditor?.assigned_to ?? ''}><option value="">Unassigned</option>{members.filter((member) => member.userId).map((member) => <option key={member.userId} value={member.userId}>{member.name}</option>)}</select></label></div><div className="club-tool-form-actions"><button className="button button-secondary" type="submit" disabled={busy}>{taskEditor ? 'Save task' : 'Add task'}</button><button className="button button-secondary" type="button" onClick={() => setTaskEditor(undefined)}><X size={14} />Cancel</button></div></form>}
      {tasks.length === 0 ? <p className="finance-empty">No tasks yet. Add the first task for your club.</p> : <div className="club-tool-list">{tasks.map((task) => {
        const canUpdate = canManageTasks || task.created_by === userId || task.assigned_to === userId
        return <article className="club-tool-row club-task-row" key={task.id}><span className={`club-tool-avatar club-task-status-${task.status}`}><ClipboardList size={15} /></span><div className="club-tool-row-main"><strong>{task.title}</strong>{task.description && <small>{task.description}</small>}<small>{task.due_on ? `Due ${task.due_on}` : 'No due date'} · {task.assignee_name ? `Assigned to ${task.assignee_name}` : 'Unassigned'} · Added by {task.created_by_name}</small></div><div className="club-task-actions">{canUpdate && <select aria-label={`Status for ${task.title}`} value={task.status} disabled={busy} onChange={(change) => void updateTask(task, { status: change.target.value as ClubTask['status'] })}><option value="open">Open</option><option value="in_progress">In progress</option><option value="done">Done</option></select>}{(canManageTasks || task.created_by === userId) && <button className="icon-button" type="button" aria-label={`Edit ${task.title}`} disabled={busy} onClick={() => setTaskEditor(task)}><Pencil size={14} /></button>}{canManageTasks && <select aria-label={`Assignee for ${task.title}`} value={task.assigned_to ?? ''} disabled={busy} onChange={(change) => void updateTask(task, { assigned_to: change.target.value || null })}><option value="">Unassigned</option>{members.filter((member) => member.userId).map((member) => <option key={member.userId} value={member.userId}>{member.name}</option>)}</select>}{canManageTasks && <button className="icon-button danger-action" type="button" aria-label={`Delete ${task.title}`} disabled={busy} onClick={() => void deleteTask(task)}><Trash2 size={15} /></button>}</div></article>
      })}</div>}
    </section>}
    {tab === 'volunteer' && <section className="panel club-tool-panel">
      <div className="finance-section-heading"><div><span className="section-kicker">THANK YOU FOR HELPING</span><h2>Volunteer hours</h2><p>{durationLabel(approvedVolunteerMinutes)} approved across the club · {pendingVolunteerCount} awaiting review.</p></div><button className="button button-secondary" type="button" onClick={() => exportCsv('club-volunteer-hours.csv', ['Member', 'Date', 'Hours', 'Activity', 'Status'], volunteerEntries.map((entry) => [entry.volunteer_name, entry.service_date, (entry.minutes_spent / 60).toFixed(2), entry.description, entry.status]))}><Download size={14} />Export</button></div>
      <form className="modal-form club-tool-form" onSubmit={(event) => void submitVolunteerHours(event)}><div className="form-row"><label>Service date<input name="service_date" type="date" required max={today()} defaultValue={today()} /></label><label>Time contributed (hours)<input name="hours" type="number" min="0.25" max="24" step="0.25" required placeholder="e.g. 1.5" /></label></div><label>What did you help with?<textarea name="description" rows={2} maxLength={500} required placeholder="Describe the volunteer activity" /></label><button className="button button-primary" type="submit" disabled={busy}>Submit hours for approval</button></form>
      {volunteerEntries.length === 0 ? <p className="finance-empty">No volunteer hours have been submitted yet.</p> : <div className="club-tool-list">{volunteerEntries.map((entry) => <article className="club-tool-row" key={entry.id}><span className="club-tool-avatar"><Clock3 size={15} /></span><div className="club-tool-row-main"><strong>{entry.volunteer_name} · {durationLabel(entry.minutes_spent)}</strong><small>{entry.service_date} · {entry.description}</small></div><span className={`finance-status finance-status-${entry.status}`}>{entry.status}</span>{entry.status === 'pending' && canManageVolunteerHours && <div className="finance-row-actions"><button className="button button-primary" type="button" disabled={busy} onClick={() => void reviewVolunteerHours(entry, 'approved')}><Check size={14} />Approve</button><button className="button button-secondary" type="button" disabled={busy} onClick={() => void reviewVolunteerHours(entry, 'rejected')}>Decline</button></div>}{entry.submitted_by === userId && entry.status === 'pending' && <button className="icon-button danger-action" type="button" disabled={busy} aria-label={`Delete volunteer request: ${entry.description}`} onClick={() => void deleteVolunteerEntry(entry)}><Trash2 size={15} /></button>}</article>)}</div>}
    </section>}
  </>

  async function updateAttendance(entry: AttendanceRecord, status: AttendanceRecord['status']) {
    if (!supabase || !canManageAttendance || busy) return
    setBusy(true)
    setError('')
    const { error: updateError } = await supabase.from('club_event_attendance')
      .update({ status })
      .eq('workspace_id', workspaceId)
      .eq('id', entry.id)
    if (updateError) {
      console.error('Unable to update event attendance:', updateError)
      setError(updateError.message)
    } else {
      await refresh()
    }
    setBusy(false)
  }
}
