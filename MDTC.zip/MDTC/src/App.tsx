import { useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from 'react'
import {
  ArrowUpRight, Bell, CalendarDays, Check, ChevronDown, ChevronRight,
  CircleHelp, Clock3, Command, Download, Heart, Image, LayoutDashboard, MapPin,
  LogOut, Megaphone, MoreHorizontal, Plus, Search, Settings, Sparkles, Trash2, Users, X,
} from 'lucide-react'
import type { User } from '@supabase/supabase-js'
import { backendConfigured, supabase } from './lib/supabase'

type View = 'Overview' | 'Events' | 'Members' | 'Announcements' | 'Settings'
type ClubEvent = { id: string; title: string; category: string; date: string; time: string; location: string; attendees: number; color: string }
type Member = { id: string; name: string; role: string; year: string; initials: string; color: string; joined: string; userId?: string }
type Announcement = { id: string; title: string; body: string; author: string; initials: string; date: string; color: string; likes: number; liked?: boolean }
type ClubData = { clubName: string; adminName: string; events: ClubEvent[]; members: Member[]; announcements: Announcement[]; rsvps: Record<string, string[]> }
type Workspace = { id: string; name: string; invite_code: string; role: 'owner' | 'member'; data: ClubData }
const colors = ['lilac', 'peach', 'mint']
const avatarColors = ['avatar-lilac', 'avatar-peach', 'avatar-mint', 'avatar-blue', 'avatar-rose']

const navigation: { label: View; icon: typeof LayoutDashboard }[] = [
  { label: 'Overview', icon: LayoutDashboard }, { label: 'Events', icon: CalendarDays },
  { label: 'Members', icon: Users }, { label: 'Announcements', icon: Megaphone },
]

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null
}

function validateBackup(value: unknown): value is ClubData {
  if (!isRecord(value) || typeof value.clubName !== 'string' || typeof value.adminName !== 'string'
    || !Array.isArray(value.events) || !Array.isArray(value.members) || !Array.isArray(value.announcements)
    || !isRecord(value.rsvps) || !Object.values(value.rsvps).every((ids) => Array.isArray(ids) && ids.every((id) => typeof id === 'string'))) return false
  const eventIsValid = (entry: unknown) => isRecord(entry) && ['id', 'title', 'category', 'date', 'time', 'location', 'color'].every((key) => typeof entry[key] === 'string') && typeof entry.attendees === 'number'
  const memberIsValid = (entry: unknown) => isRecord(entry) && ['id', 'name', 'role', 'year', 'initials', 'color', 'joined'].every((key) => typeof entry[key] === 'string')
  const announcementIsValid = (entry: unknown) => isRecord(entry) && ['id', 'title', 'body', 'author', 'initials', 'date', 'color'].every((key) => typeof entry[key] === 'string') && typeof entry.likes === 'number'
    && (entry.liked === undefined || typeof entry.liked === 'boolean')
  return value.events.every(eventIsValid) && value.members.every(memberIsValid) && value.announcements.every(announcementIsValid)
}

function initials(name: string) {
  return name.trim().split(/\s+/).slice(0, 2).map((part) => part[0]?.toUpperCase() ?? '').join('')
}

function dateLabel(value: string) {
  const parsed = new Date(`${value}T12:00:00`)
  return Number.isNaN(parsed.getTime()) ? { month: 'TBA', day: '—' } : { month: parsed.toLocaleDateString('en', { month: 'short' }), day: parsed.toLocaleDateString('en', { day: '2-digit' }) }
}

function readableTime(value: string) {
  if (!value) return 'Time TBA'
  const [hour, minute] = value.split(':').map(Number)
  if (!Number.isFinite(hour) || !Number.isFinite(minute)) return value
  return new Date(2000, 0, 1, hour, minute).toLocaleTimeString('en', { hour: 'numeric', minute: '2-digit' })
}

function Avatar({ initials: letters, color, small = false }: { initials: string; color: string; small?: boolean }) {
  return <span className={`avatar ${color}${small ? ' avatar-small' : ''}`}>{letters}</span>
}

function AuthScreen({ mode, onModeChange, onSubmit, error, message, busy }: {
  mode: 'login' | 'register'
  onModeChange: (mode: 'login' | 'register') => void
  onSubmit: (event: FormEvent<HTMLFormElement>) => void
  error: string
  message: string
  busy: boolean
}) {
  const registering = mode === 'register'
  const [joinClub, setJoinClub] = useState(false)
  useEffect(() => setJoinClub(false), [mode])
  return <main className="auth-screen">
    <section className="auth-card">
      <a className="brand auth-brand" href="#" onClick={(event) => event.preventDefault()}><span className="brand-mark"><span /><span /><span /><span /></span><span className="brand-name">mdtc<span>.</span></span></a>
      <span className="auth-eyebrow">{registering ? 'START YOUR CLUBHOUSE' : 'WELCOME BACK'}</span>
      <h1>{registering ? 'Make a space for your club.' : 'Your club, together.'}</h1>
      <p className="auth-description">{registering ? 'Create an account to start organizing your people, events, and ideas.' : 'Sign in to pick up where your club left off.'}</p>
      <form className="auth-form" onSubmit={onSubmit}>
        {registering && <>
          <label>Your name<input name="name" autoComplete="name" required maxLength={80} placeholder="e.g. Maya Chen" /></label>
          <div className="auth-mode-toggle"><button type="button" className={!joinClub ? 'selected' : ''} onClick={() => setJoinClub(false)}>Create a club</button><button type="button" className={joinClub ? 'selected' : ''} onClick={() => setJoinClub(true)}>Join with invite</button></div>
          {joinClub
            ? <label>Club invite code<input name="inviteCode" required maxLength={32} autoCapitalize="characters" placeholder="Enter your club code" /></label>
            : <label>Club name<input name="clubName" autoComplete="organization" required maxLength={60} placeholder="e.g. Media & Design" /></label>}
        </>}
        <label>Email address<input name="email" type="email" autoComplete="email" required maxLength={254} placeholder="you@example.com" /></label>
        <label>Password<input name="password" type="password" autoComplete={registering ? 'new-password' : 'current-password'} required minLength={registering ? 8 : undefined} maxLength={128} placeholder={registering ? 'At least 8 characters' : 'Your password'} /></label>
        {registering && <label>Confirm password<input name="confirmPassword" type="password" autoComplete="new-password" required minLength={8} maxLength={128} placeholder="Enter your password again" /></label>}
        {error && <p className="auth-error" role="alert">{error}</p>}
        {message && <p className="password-success" role="status">{message}</p>}
        <button className="button button-primary auth-submit" type="submit" disabled={busy}>{busy ? 'Please wait…' : registering ? 'Create account' : 'Sign in'}</button>
      </form>
      <p className="auth-switch">{registering ? 'Already have an account?' : 'New to MDTC?'} <button onClick={() => onModeChange(registering ? 'login' : 'register')}>{registering ? 'Sign in' : 'Create an account'}</button></p>
      <p className="auth-notice">Accounts are securely managed by Supabase. Club members share updates and club data across devices.</p>
    </section>
  </main>
}

function AuthLoading({ message = 'Connecting securely…' }: { message?: string }) {
  return <main className="auth-screen"><section className="auth-card auth-status"><span className="auth-mark"><Sparkles size={20} /></span><h1>{message}</h1><p className="auth-description">Please keep this page open.</p></section></main>
}

function BackendSetup() {
  return <main className="auth-screen"><section className="auth-card"><a className="brand auth-brand" href="#" onClick={(event) => event.preventDefault()}><span className="brand-mark"><span /><span /><span /><span /></span><span className="brand-name">mdtc<span>.</span></span></a><span className="auth-eyebrow">ONE MORE SETUP STEP</span><h1>Connect your club online.</h1><p className="auth-description">Add your Supabase project URL and public anon key to the site environment variables, then redeploy. See <code>.env.example</code> and the README setup guide.</p><p className="auth-notice">Never put a Supabase service-role key in the website. Configure Row Level Security using the included database migration first.</p></section></main>
}

function WorkspaceError({ message, onSignOut }: { message: string; onSignOut: () => void }) {
  return <main className="auth-screen"><section className="auth-card"><span className="auth-eyebrow">CLUB WORKSPACE</span><h1>We couldn’t open your club.</h1><p className="auth-error" role="alert">{message}</p><p className="auth-description workspace-error-description">If you’re new, confirm your account email first. If you have a club invite, make sure it’s valid.</p><button className="button button-primary auth-submit" onClick={onSignOut}>Back to sign in</button></section></main>
}

function App() {
  const [user, setUser] = useState<User | null>(null)
  const [authReady, setAuthReady] = useState(false)
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login')
  const [authError, setAuthError] = useState('')
  const [authMessage, setAuthMessage] = useState('')
  const [authBusy, setAuthBusy] = useState(false)
  const [workspace, setWorkspace] = useState<Workspace | null>(null)
  const [workspaceLoading, setWorkspaceLoading] = useState(false)
  const [workspaceError, setWorkspaceError] = useState('')

  async function submitAuth(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setAuthError('')
    setAuthMessage('')
    setAuthBusy(true)
    const form = new FormData(event.currentTarget)
    const name = String(form.get('name') ?? '').trim()
    const email = String(form.get('email') ?? '').trim().toLowerCase()
    const password = String(form.get('password') ?? '')
    try {
      if (!supabase) throw new Error('The authentication service is not configured.')
      if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error('Enter a valid email address.')
      if (authMode === 'register') {
        const confirmPassword = String(form.get('confirmPassword') ?? '')
        const clubName = String(form.get('clubName') ?? '').trim()
        const inviteCode = String(form.get('inviteCode') ?? '').trim().toUpperCase()
        const joining = Boolean(inviteCode)
        if (!name) throw new Error('Enter your name.')
        if (joining && !inviteCode) throw new Error('Enter the club invite code.')
        if (!joining && !clubName) throw new Error('Enter your club name.')
        if (password.length < 8) throw new Error('Choose a password with at least 8 characters.')
        if (password !== confirmPassword) throw new Error('The passwords do not match.')
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: { data: { display_name: name, onboarding_mode: joining ? 'join' : 'create', club_name: joining ? '' : clubName, invite_code: joining ? inviteCode : '' } },
        })
        if (error) throw error
        if (!data.session) setAuthMessage('Check your email to confirm your account, then sign in to access your club.')
        else setUser(data.user)
      } else {
        const { data, error } = await supabase.auth.signInWithPassword({ email, password })
        if (error) throw error
        setUser(data.user)
      }
    } catch (error) {
      console.error('Authentication request failed:', error)
      setAuthError(error instanceof Error ? error.message : 'Unable to complete sign-in.')
    } finally {
      setAuthBusy(false)
    }
  }

  function signOut() {
    if (!supabase) return
    void supabase.auth.signOut().then(({ error }) => {
      if (error) {
        console.error('Unable to sign out:', error)
        setAuthError('Unable to sign out. Please try again.')
        return
      }
      setUser(null)
      setAuthMode('login')
      setAuthError('')
      setAuthMessage('')
      setWorkspace(null)
    }).catch((error: unknown) => {
      console.error('Unable to sign out:', error)
      setAuthError('Unable to sign out. Please try again.')
    })
  }

  useEffect(() => {
    if (!supabase) return
    let active = true
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (active) {
        setUser(session?.user ?? null)
        setAuthReady(true)
      }
    })
    void supabase.auth.getSession().then(({ data, error }) => {
      if (error) throw error
      if (active) {
        setUser(data.session?.user ?? null)
        setAuthReady(true)
      }
    }).catch((error: unknown) => {
      console.error('Unable to restore the Supabase session:', error)
      if (active) {
        setAuthError('Unable to connect to the account service. Try refreshing the page.')
        setAuthReady(true)
      }
    })
    return () => {
      active = false
      subscription.unsubscribe()
    }
  }, [])

  useEffect(() => {
    if (!supabase || !user) {
      setWorkspace(null)
      setWorkspaceLoading(false)
      setWorkspaceError('')
      return
    }
    let active = true
    setWorkspace(null)
    setWorkspaceLoading(true)
    setWorkspaceError('')
    void (async () => {
      const { data: memberships, error: membershipError } = await supabase
        .from('club_members').select('workspace_id').eq('user_id', user.id).limit(1)
      if (membershipError) throw membershipError
      let workspaceId = memberships?.[0]?.workspace_id as string | undefined
      if (!workspaceId) {
        const mode = user.user_metadata.onboarding_mode
        const result = mode === 'join'
          ? await supabase.rpc('join_club', { p_invite_code: String(user.user_metadata.invite_code ?? '') })
          : mode === 'create'
            ? await supabase.rpc('create_club', { p_name: String(user.user_metadata.club_name ?? '') })
            : { data: null, error: new Error('This account is not linked to a club. Sign up with a club invite or create a club.') }
        if (result.error) throw result.error
        if (typeof result.data !== 'string') throw new Error('The club setup did not return a workspace. Try signing in again.')
        workspaceId = result.data
      }
      const { data: row, error: workspaceError } = await supabase
        .from('club_workspaces').select('id,name,invite_code,data').eq('id', workspaceId).single()
      if (workspaceError) throw workspaceError
      if (!isRecord(row) || !validateBackup(row.data)) throw new Error('The club workspace data is invalid.')
      const [{ data: membership }, { data: members, error: membersError }] = await Promise.all([
        supabase.from('club_members').select('role').eq('workspace_id', workspaceId).eq('user_id', user.id).single(),
        supabase.from('club_members').select('user_id,display_name,role,joined_at').eq('workspace_id', workspaceId),
      ])
      if (membersError) throw membersError
      const accountMembers: Member[] = (members ?? []).map((member) => ({
        id: `account:${member.user_id}`,
        userId: member.user_id,
        name: member.display_name,
        role: member.role === 'owner' ? 'Club admin' : 'Member',
        year: member.role === 'owner' ? 'Club administrator' : 'Club member',
        initials: initials(member.display_name),
        color: 'avatar-lilac',
        joined: new Date(member.joined_at).toLocaleDateString('en', { month: 'short', year: 'numeric' }),
      }))
      const sharedData: ClubData = {
        ...row.data,
        members: [...row.data.members.filter((member) => !member.userId), ...accountMembers],
      }
      if (active) setWorkspace({
        id: String(row.id),
        name: String(row.name),
        invite_code: String(row.invite_code),
        role: membership?.role === 'owner' ? 'owner' : 'member',
        data: sharedData,
      })
    })().catch((error: unknown) => {
      console.error('Unable to load the shared club workspace:', error)
      if (active) setWorkspaceError(error instanceof Error ? error.message : 'Unable to load this club.')
    }).finally(() => {
      if (active) setWorkspaceLoading(false)
    })
    return () => { active = false }
  }, [user])

  if (!backendConfigured || !supabase) return <BackendSetup />
  if (!authReady) return <AuthLoading />
  if (!user) return <AuthScreen mode={authMode} onModeChange={(mode) => { setAuthMode(mode); setAuthError(''); setAuthMessage('') }} onSubmit={submitAuth} error={authError} message={authMessage} busy={authBusy} />
  if (workspaceLoading) return <AuthLoading message="Opening your club…" />
  if (workspaceError) return <WorkspaceError message={workspaceError} onSignOut={signOut} />
  if (!workspace) return <AuthLoading message="Preparing your club…" />
  const client = supabase
  if (!client) return <BackendSetup />
  return <Clubhouse user={user} workspace={workspace} onSignOut={signOut} onChangePassword={async (currentPassword, nextPassword) => {
    const email = user.email
    if (!email) throw new Error('This account does not have an email address.')
    const { error: verifyError } = await client.auth.signInWithPassword({ email, password: currentPassword })
    if (verifyError) throw new Error('Your current password is incorrect.')
    const { error } = await client.auth.updateUser({ password: nextPassword })
    if (error) throw error
  }} />
}

function Clubhouse({ user, workspace, onSignOut, onChangePassword }: { user: User; workspace: Workspace; onSignOut: () => void; onChangePassword: (currentPassword: string, nextPassword: string) => Promise<void> }) {
  const [data, setData] = useState<ClubData>(workspace.data)
  const currentUserName = String(user.user_metadata.display_name ?? user.email ?? data.adminName)
  const [activeView, setActiveView] = useState<View>('Overview')
  const [search, setSearch] = useState('')
  const [notice, setNotice] = useState('')
  const [storageError, setStorageError] = useState(false)
  const [eventEditor, setEventEditor] = useState<ClubEvent | null | undefined>(undefined)
  const [memberEditor, setMemberEditor] = useState<Member | null | undefined>(undefined)
  const [showAnnouncementForm, setShowAnnouncementForm] = useState(false)
  const [installPrompt, setInstallPrompt] = useState<Event & { prompt?: () => Promise<void>; userChoice?: Promise<{ outcome: string }> } | null>(null)
  const searchInput = useRef<HTMLInputElement>(null)

  useEffect(() => {
    const client = supabase
    if (!client) return
    const timer = window.setTimeout(() => {
      void client.rpc('save_club_data', { p_workspace_id: workspace.id, p_data: data })
        .then(({ error }) => {
          if (error) {
            console.error('Unable to save shared club changes:', error)
            setStorageError(true)
            setNotice('Could not sync changes. Check your connection and try again.')
          } else setStorageError(false)
        })
    }, 350)
    return () => window.clearTimeout(timer)
  }, [data, workspace.id])

  useEffect(() => {
    const client = supabase
    if (!client) return
    const channel = client.channel(`club-workspace-${workspace.id}`)
      .on('postgres_changes', {
        event: 'UPDATE',
        schema: 'public',
        table: 'club_workspaces',
        filter: `id=eq.${workspace.id}`,
      }, (payload) => {
        const remote = payload.new.data
        if (validateBackup(remote)) {
          setData((current) => JSON.stringify(current) === JSON.stringify(remote) ? current : remote)
        }
      })
      .subscribe((status) => {
        if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') {
          console.error('Realtime club sync failed:', status)
          setStorageError(true)
        }
      })
    return () => { void client.removeChannel(channel) }
  }, [workspace.id, workspace.data.members])

  useEffect(() => {
    const handleInstall = (event: Event) => {
      event.preventDefault()
      setInstallPrompt(event as Event & { prompt?: () => Promise<void>; userChoice?: Promise<{ outcome: string }> })
    }
    window.addEventListener('beforeinstallprompt', handleInstall)
    return () => window.removeEventListener('beforeinstallprompt', handleInstall)
  }, [])

  useEffect(() => {
    const handleShortcut = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault()
        searchInput.current?.focus()
      }
    }
    window.addEventListener('keydown', handleShortcut)
    return () => window.removeEventListener('keydown', handleShortcut)
  }, [])

  const filteredMembers = useMemo(() => data.members.filter((member) =>
    `${member.name} ${member.role} ${member.year}`.toLowerCase().includes(search.toLowerCase())), [data.members, search])

  function navigate(view: View) {
    setActiveView(view)
    setSearch('')
  }

  function saveEvent(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const form = new FormData(event.currentTarget)
    const title = String(form.get('title')).trim()
    const date = String(form.get('date'))
    if (!title || !date) return
    const item: ClubEvent = {
      id: eventEditor?.id ?? crypto.randomUUID(),
      title,
      date,
      time: String(form.get('time')),
      location: String(form.get('location')).trim() || 'Location TBA',
      category: String(form.get('category')),
      attendees: eventEditor?.attendees ?? 0,
      color: eventEditor?.color ?? colors[data.events.length % colors.length],
    }
    setData((current) => ({ ...current, events: eventEditor ? current.events.map((entry) => entry.id === item.id ? item : entry) : [...current.events, item] }))
    setEventEditor(undefined)
    setNotice(eventEditor ? 'Event updated.' : 'Event added to the calendar.')
  }

  function saveMember(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const form = new FormData(event.currentTarget)
    const name = String(form.get('name')).trim()
    if (!name) return
    const item: Member = {
      id: memberEditor?.id ?? crypto.randomUUID(),
      name,
      role: String(form.get('role')).trim() || 'Member',
      year: String(form.get('year')).trim() || 'Student',
      initials: initials(name),
      color: memberEditor?.color ?? avatarColors[data.members.length % avatarColors.length],
      joined: memberEditor?.joined ?? new Date().toLocaleDateString('en', { month: 'short', year: 'numeric' }),
    }
    setData((current) => ({ ...current, members: memberEditor ? current.members.map((entry) => entry.id === item.id ? item : entry) : [...current.members, item] }))
    setMemberEditor(undefined)
    setNotice(memberEditor ? 'Member details updated.' : `${name} added to the directory.`)
  }

  function saveAnnouncement(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const form = new FormData(event.currentTarget)
    const title = String(form.get('title')).trim()
    const body = String(form.get('body')).trim()
    if (!title || !body) return
    setData((current) => ({ ...current, announcements: [{
      id: crypto.randomUUID(), title, body, author: currentUserName, initials: initials(currentUserName),
      date: 'Just now', color: 'avatar-blue', likes: 0,
    }, ...current.announcements] }))
    setShowAnnouncementForm(false)
    setNotice('Announcement published.')
  }

  function toggleRsvp(id: string) {
    const userRsvps = data.rsvps[user.id] ?? []
    const joined = userRsvps.includes(id)
    setData((current) => ({
      ...current,
      rsvps: {
        ...current.rsvps,
        [user.id]: joined ? userRsvps.filter((entry) => entry !== id) : [...userRsvps, id],
      },
      events: current.events.map((event) => event.id === id ? { ...event, attendees: Math.max(0, event.attendees + (joined ? -1 : 1)) } : event),
    }))
    setNotice(joined ? 'Your RSVP was removed.' : 'You’re on the list!')
  }

  function deleteEvent(event: ClubEvent) {
    if (!window.confirm(`Delete “${event.title}”? This cannot be undone.`)) return
    setData((current) => ({ ...current, events: current.events.filter((item) => item.id !== event.id), rsvps: Object.fromEntries(Object.entries(current.rsvps).map(([userId, ids]) => [userId, ids.filter((id) => id !== event.id)])) }))
    setNotice('Event deleted.')
  }

  async function deleteMember(member: Member) {
    if (!window.confirm(`Remove ${member.name} from the member directory?`)) return
    if (member.userId) {
      if (workspace.role !== 'owner' || !supabase) return
      const { error } = await supabase.rpc('remove_club_member', { p_workspace_id: workspace.id, p_user_id: member.userId })
      if (error) {
        console.error('Unable to remove the club member:', error)
        setNotice(error.message)
        return
      }
    }
    setData((current) => ({ ...current, members: current.members.filter((item) => item.id !== member.id) }))
    setNotice('Member removed.')
  }

  function deleteAnnouncement(announcement: Announcement) {
    if (!window.confirm(`Delete “${announcement.title}”? This cannot be undone.`)) return
    setData((current) => ({ ...current, announcements: current.announcements.filter((item) => item.id !== announcement.id) }))
    setNotice('Announcement deleted.')
  }

  function toggleLike(id: string) {
    setData((current) => ({ ...current, announcements: current.announcements.map((item) => item.id === id ? { ...item, likes: Math.max(0, item.likes + (item.liked ? -1 : 1)), liked: !item.liked } : item) }))
  }

  function exportData() {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = 'mdtc-clubhouse-backup.json'
    link.click()
    URL.revokeObjectURL(url)
    setNotice('Your backup has been downloaded.')
  }

  async function importData(file: File | undefined) {
    if (!file) return
    if (workspace.role !== 'owner') {
      setNotice('Only the club owner can restore a shared backup.')
      return
    }
    try {
      const imported: unknown = JSON.parse(await file.text())
      if (!validateBackup(imported)) {
        setNotice('That backup file is not a valid MDTC Clubhouse backup.')
        return
      }
      if (!window.confirm('Replace the shared club content with the selected backup? This affects every member.')) return
      setData(imported)
      setNotice('Backup restored successfully.')
    } catch (error) {
      console.error('Unable to import club backup:', error)
      setNotice('Could not read that backup file. Choose a valid JSON backup.')
    }
  }

  function resetData() {
    if (!window.confirm('Clear all events, member entries, announcements, and RSVPs in this shared club? This affects every member and cannot be undone.')) return
    setData((current) => ({ ...current, events: [], announcements: [], rsvps: {}, members: current.members.filter((member) => member.userId) }))
    setNotice('Your workspace has been cleared.')
  }

  async function installApp() {
    if (!installPrompt?.prompt) return
    try {
      await installPrompt.prompt()
      const choice = await installPrompt.userChoice
      if (choice?.outcome === 'accepted') setNotice('MDTC Clubhouse is installing.')
      setInstallPrompt(null)
    } catch (error) {
      console.error('Unable to install the clubhouse app:', error)
      setNotice('The app could not be installed from this browser.')
    }
  }

  return <div className="app-shell">
    <aside className="sidebar">
      <a className="brand" href="#" onClick={(event) => { event.preventDefault(); navigate('Overview') }}><span className="brand-mark"><span /><span /><span /><span /></span><span className="brand-name">mdtc<span>.</span></span></a>
      <button className="club-switcher" onClick={() => navigate('Settings')}><span className="club-avatar">{data.clubName.slice(0, 1).toUpperCase()}</span><span className="club-info"><strong>{data.clubName}</strong><small>Student club</small></span><ChevronDown size={15} /></button>
      <div className="nav-section-label">WORKSPACE</div>
      <nav className="side-nav" aria-label="Main navigation">{navigation.map(({ label, icon: Icon }) => <button key={label} className={`nav-item${activeView === label ? ' active' : ''}`} onClick={() => navigate(label)}><Icon size={18} strokeWidth={1.8} /><span>{label}</span>{label === 'Announcements' && <span className="nav-count">{data.announcements.length}</span>}</button>)}</nav>
      <div className="sidebar-bottom">
        <div className="semester-card"><span className="semester-icon"><Sparkles size={15} /></span><div><strong>Clubhouse</strong><span>Shared club workspace</span></div><div className="semester-progress"><span /></div></div>
        <button className={`nav-item${activeView === 'Settings' ? ' active' : ''}`} onClick={() => navigate('Settings')}><Settings size={18} strokeWidth={1.8} /><span>Settings</span></button>
        <button className="profile-row" onClick={() => navigate('Settings')}><Avatar initials={initials(currentUserName)} color="avatar-lilac" small /><span className="profile-copy"><strong>{currentUserName}</strong><small>{workspace.role === 'owner' ? 'Club admin' : 'Club member'}</small></span><MoreHorizontal size={18} /></button>
      </div>
    </aside>
    <main className="main-area">
      <header className="topbar"><div className="breadcrumbs"><span>Workspace</span><ChevronRight size={14} /><strong>{activeView}</strong></div><div className="topbar-actions">
        <label className="search-box"><Search size={16} /><input ref={searchInput} aria-label="Search members" placeholder="Search members..." value={search} onChange={(event) => { setSearch(event.target.value); setActiveView('Members') }} /><kbd><Command size={11} /> K</kbd></label>
        <button className="icon-button notification-button" aria-label="Show sync status" onClick={() => setNotice(storageError ? 'Could not sync data. Check your connection and try again.' : 'Your club data is connected to the cloud.')}><Bell size={18} /><span /></button><button className="icon-button topbar-signout" aria-label="Sign out" title="Sign out" onClick={onSignOut}><LogOut size={17} /></button><Avatar initials={initials(currentUserName)} color="avatar-lilac" small />
      </div></header>
      <div className="mobile-brand"><span className="brand-mark"><span /><span /><span /><span /></span><span className="brand-name">mdtc<span>.</span></span></div>
      {storageError && <div className="storage-warning" role="alert">Cloud sync is unavailable. Changes may not reach other devices yet.<button onClick={() => setStorageError(false)} aria-label="Dismiss"><X size={14} /></button></div>}
      <section className="page-content">
        {activeView === 'Overview' && <Overview data={data} currentRsvps={data.rsvps[user.id] ?? []} onNavigate={navigate} onCreateEvent={() => setEventEditor(null)} onCreateAnnouncement={() => setShowAnnouncementForm(true)} onNotice={setNotice} onRsvp={toggleRsvp} />}
        {activeView === 'Events' && <EventsView events={data.events} rsvps={data.rsvps[user.id] ?? []} onCreate={() => setEventEditor(null)} onEdit={setEventEditor} onDelete={deleteEvent} onRsvp={toggleRsvp} />}
        {activeView === 'Members' && <MembersView members={filteredMembers} search={search} canManageAccounts={workspace.role === 'owner'} onCreate={() => setMemberEditor(null)} onEdit={setMemberEditor} onDelete={deleteMember} />}
        {activeView === 'Announcements' && <AnnouncementsView announcements={data.announcements} onCreate={() => setShowAnnouncementForm(true)} onDelete={deleteAnnouncement} onLike={toggleLike} />}
        {activeView === 'Settings' && <SettingsView data={data} user={user} workspace={workspace} onCopyInvite={() => { void navigator.clipboard.writeText(workspace.invite_code).then(() => setNotice('Invite code copied.')).catch((error: unknown) => { console.error('Unable to copy the invite code:', error); setNotice('Copy the invite code manually.') }) }} onSave={(clubName, adminName) => { setData((current) => ({ ...current, clubName, adminName })); setNotice('Club settings saved.') }} onChangePassword={onChangePassword} onExport={exportData} onImport={importData} onReset={resetData} onSignOut={onSignOut} canInstall={Boolean(installPrompt?.prompt)} onInstall={installApp} />}
      </section>
    </main>
    <nav className="mobile-nav" aria-label="Mobile navigation">{[...navigation, { label: 'Settings' as View, icon: Settings }].map(({ label, icon: Icon }) => <button key={label} className={activeView === label ? 'active' : ''} onClick={() => navigate(label)}><Icon size={19} /><span>{label === 'Announcements' ? 'Updates' : label}</span></button>)}</nav>
    {notice && <div className="toast" role="status"><Check size={16} />{notice}<button aria-label="Dismiss notification" onClick={() => setNotice('')}><X size={15} /></button></div>}
    {eventEditor !== undefined && <Modal title={eventEditor ? 'Edit event' : 'Create an event'} subtitle="Give your club something to look forward to." onClose={() => setEventEditor(undefined)}><form className="modal-form" onSubmit={saveEvent}>
      <label>Event name<input name="title" required defaultValue={eventEditor?.title} placeholder="e.g. Creative coding night" /></label>
      <div className="form-row"><label>Date<input name="date" type="date" required defaultValue={eventEditor?.date} /></label><label>Start time<input name="time" type="time" defaultValue={eventEditor?.time ?? '17:30'} /></label></div>
      <div className="form-row"><label>Event type<select name="category" defaultValue={eventEditor?.category ?? 'Workshop'}><option>Workshop</option><option>Talk</option><option>Social</option><option>Showcase</option></select></label><label>Location<input name="location" defaultValue={eventEditor?.location} placeholder="Room or venue" /></label></div>
      <button className="button button-primary button-full" type="submit"><Plus size={16} />{eventEditor ? 'Save changes' : 'Add to calendar'}</button>
    </form></Modal>}
    {memberEditor !== undefined && <Modal title={memberEditor ? 'Edit member' : 'Add a member'} subtitle="Keep your club directory up to date." onClose={() => setMemberEditor(undefined)}><form className="modal-form" onSubmit={saveMember}>
      <label>Full name<input name="name" required defaultValue={memberEditor?.name} placeholder="First and last name" /></label>
      <div className="form-row"><label>Role<input name="role" defaultValue={memberEditor?.role ?? 'Member'} placeholder="e.g. Events lead" /></label><label>Year and discipline<input name="year" defaultValue={memberEditor?.year} placeholder="e.g. Junior · Graphic Design" /></label></div>
      <button className="button button-primary button-full" type="submit"><Users size={16} />{memberEditor ? 'Save member' : 'Add to directory'}</button>
    </form></Modal>}
    {showAnnouncementForm && <Modal title="Share an update" subtitle="Let your members know what’s happening." onClose={() => setShowAnnouncementForm(false)}><form className="modal-form" onSubmit={saveAnnouncement}>
      <label>Headline<input name="title" required maxLength={100} placeholder="What’s the big news?" /></label><label>Message<textarea name="body" rows={4} required maxLength={2000} placeholder="Share the details with your club..." /></label>
      <button className="button button-primary button-full" type="submit"><Megaphone size={16} />Publish announcement</button>
    </form></Modal>}
  </div>
}

function PageHeading({ eyebrow, title, description, action }: { eyebrow: string; title: ReactNode; description: string; action?: ReactNode }) {
  return <div className="page-heading"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p>{description}</p></div>{action}</div>
}

function Overview({ data, currentRsvps, onNavigate, onCreateEvent, onCreateAnnouncement, onNotice, onRsvp }: { data: ClubData; currentRsvps: string[]; onNavigate: (view: View) => void; onCreateEvent: () => void; onCreateAnnouncement: () => void; onNotice: (message: string) => void; onRsvp: (id: string) => void }) {
  const activeMembers = data.members.length
  return <>
    <PageHeading eyebrow={new Date().toLocaleDateString('en', { weekday: 'long', month: 'long', day: 'numeric' }).toUpperCase()} title={<>Good afternoon, {data.adminName.split(' ')[0]} <span className="wave">✳</span></>} description="Here’s what’s happening in your club this week." action={<button className="button button-primary" onClick={onCreateEvent}><Plus size={16} />Create event</button>} />
    <section className="welcome-banner"><div className="welcome-copy"><span className="banner-kicker"><Sparkles size={14} /> YOUR CLUB, IN MOTION</span><h2>Make room for good ideas.</h2><p>Bring your people together, share what you’re making, and make this semester one to remember.</p><button className="banner-link" onClick={() => onNavigate('Events')}>Explore upcoming events <ArrowUpRight size={15} /></button></div><div className="banner-art" aria-hidden="true"><div className="art-sun" /><div className="art-card art-card-back" /><div className="art-card art-card-front"><span>MAKE<br />SOMETHING<br /><i>MATTERS.</i></span><div className="art-flower">✳</div></div><div className="art-spark">✳</div><div className="art-dot" /></div></section>
    <div className="stats-grid"><StatCard label="Members" value={String(activeMembers)} change="directory" detail="club members" icon={<Users size={17} />} tint="stat-lilac" /><StatCard label="Upcoming events" value={String(data.events.length)} change="scheduled" detail="club events" icon={<CalendarDays size={17} />} tint="stat-peach" /><StatCard label="Announcements" value={String(data.announcements.length)} change="shared" detail="club updates" icon={<Megaphone size={17} />} tint="stat-mint" /><StatCard label="Your RSVPs" value={String(currentRsvps.length)} change="confirmed" detail="events you’re attending" icon={<Check size={17} />} tint="stat-blue" /></div>
    <div className="content-grid">
      <section className="panel events-panel"><div className="panel-heading"><div><span className="section-kicker">COMING UP</span><h2>On the calendar</h2></div><button className="text-button" onClick={() => onNavigate('Events')}>All events <ChevronRight size={15} /></button></div>
        <div className="event-list">{data.events.slice().sort((a, b) => a.date.localeCompare(b.date)).slice(0, 3).map((event) => <EventRow key={event.id} event={event} going={currentRsvps.includes(event.id)} onRsvp={() => onRsvp(event.id)} />)}</div><button className="add-event-row" onClick={onCreateEvent}><span><Plus size={15} /></span>Add an event to the calendar</button>
      </section>
      <section className="panel activity-panel"><div className="panel-heading"><div><span className="section-kicker">THE LATEST</span><h2>Club updates</h2></div><button className="icon-button more-button" aria-label="View all announcements" onClick={() => onNavigate('Announcements')}><MoreHorizontal size={19} /></button></div>
        <div className="announcement-preview-list">{data.announcements.slice(0, 2).map((announcement) => <AnnouncementPreview key={announcement.id} announcement={announcement} onDelete={() => onNotice('Open announcements to manage posts.')} />)}</div><button className="compose-button" onClick={onCreateAnnouncement}><span className="compose-avatar">{initials(data.adminName)}</span><span>Share something with your club...</span><Image size={16} /></button>
      </section>
    </div>
    <section className="panel members-panel"><div className="panel-heading"><div><span className="section-kicker">YOUR PEOPLE</span><h2>Meet the members</h2></div><button className="text-button" onClick={() => onNavigate('Members')}>View directory <ChevronRight size={15} /></button></div><div className="member-strip">{data.members.slice(0, 5).map((member) => <div className="member-card" key={member.id}><Avatar initials={member.initials} color={member.color} /><strong>{member.name}</strong><span>{member.role}</span></div>)}</div></section>
    <div className="dashboard-footer"><span>Made for people who make things <span className="footer-star">✳</span></span><button onClick={() => onNotice('Use Settings to export a backup or manage club details.')}>Need a hand? <CircleHelp size={14} /></button></div>
  </>
}

function StatCard({ label, value, change, detail, icon, tint }: { label: string; value: string; change: string; detail: string; icon: ReactNode; tint: string }) {
  return <article className="stat-card"><div className="stat-top"><span>{label}</span><span className={`stat-icon ${tint}`}>{icon}</span></div><div className="stat-value">{value}</div><div className="stat-foot"><span className="trend-up"><Check size={13} />{change}</span><span>{detail}</span></div></article>
}

function EventRow({ event, going, onRsvp, onEdit, onDelete }: { event: ClubEvent; going: boolean; onRsvp: () => void; onEdit?: () => void; onDelete?: () => void }) {
  const date = dateLabel(event.date)
  return <article className="event-row"><div className={`date-tile ${event.color}`}><strong>{date.day}</strong><span>{date.month}</span></div><div className="event-details"><div className="event-title-line"><h3>{event.title}</h3><span className={`category-pill ${event.color}`}>{event.category}</span></div><div className="event-meta"><span><Clock3 size={13} />{readableTime(event.time)}</span><span><MapPin size={13} />{event.location}</span></div></div><div className="attendees"><span>{event.attendees} going</span><button className={`rsvp-button${going ? ' attending' : ''}`} onClick={onRsvp}>{going ? 'Going ✓' : 'RSVP'}</button></div>{onEdit && <button className="icon-button row-action" aria-label={`Edit ${event.title}`} onClick={onEdit}><Settings size={15} /></button>}{onDelete && <button className="icon-button row-action danger-action" aria-label={`Delete ${event.title}`} onClick={onDelete}><Trash2 size={15} /></button>}</article>
}

function AnnouncementPreview({ announcement, onDelete }: { announcement: Announcement; onDelete: () => void }) {
  return <article className="announcement-preview"><div className="announcement-head"><Avatar initials={announcement.initials} color={announcement.color} small /><span><strong>{announcement.author}</strong><small>{announcement.date}</small></span><button aria-label={`Announcement options: ${announcement.title}`} className="icon-button announcement-more" onClick={onDelete}><MoreHorizontal size={16} /></button></div><h3>{announcement.title}</h3><p>{announcement.body}</p></article>
}

function EventsView({ events, rsvps, onCreate, onEdit, onDelete, onRsvp }: { events: ClubEvent[]; rsvps: string[]; onCreate: () => void; onEdit: (event: ClubEvent) => void; onDelete: (event: ClubEvent) => void; onRsvp: (id: string) => void }) {
  const sortedEvents = events.slice().sort((a, b) => a.date.localeCompare(b.date))
  return <><PageHeading eyebrow="MAKE A DATE" title="Events" description="A little something to bring us all together." action={<button className="button button-primary" onClick={onCreate}><Plus size={16} />Create event</button>} /><div className="view-toolbar"><div className="view-filter"><CalendarDays size={16} /> All events</div><span>{events.length} events scheduled</span></div><section className="panel full-events-panel">{sortedEvents.length ? sortedEvents.map((event) => <EventRow key={event.id} event={event} going={rsvps.includes(event.id)} onRsvp={() => onRsvp(event.id)} onEdit={() => onEdit(event)} onDelete={() => onDelete(event)} />) : <EmptyState title="No events on the calendar" text="Create the first event and bring your club together." />}</section></>
}

function MembersView({ members, search, canManageAccounts, onCreate, onEdit, onDelete }: { members: Member[]; search: string; canManageAccounts: boolean; onCreate: () => void; onEdit: (member: Member) => void; onDelete: (member: Member) => void }) {
  return <><PageHeading eyebrow="THE PEOPLE BEHIND THE IDEAS" title="Members" description="The people who make this club what it is." action={canManageAccounts && <button className="button button-primary" onClick={onCreate}><Plus size={16} />Add member</button>} /><div className="member-summary"><div className="member-summary-icon"><Users size={19} /></div><div><strong>{members.length} {search ? 'matching' : 'club'} members</strong><span>Manage your club directory</span></div><div className="summary-avatars">{members.slice(0, 3).map((member) => <Avatar key={member.id} initials={member.initials} color={member.color} small />)}{members.length > 3 && <span>+{members.length - 3}</span>}</div></div><section className="panel directory-panel"><div className="directory-heading"><div><span className="section-kicker">MEMBER DIRECTORY</span><h2>{search ? `${members.length} search results` : 'All members'}</h2></div><span className="directory-sort">Alphabetical</span></div><div className="directory-list">{members.length ? members.map((member) => <div className="directory-row" key={member.id}><Avatar initials={member.initials} color={member.color} /><div className="directory-person"><strong>{member.name}</strong><span>{member.year}</span></div><span className="role-pill">{member.role}</span><span className="joined-date">Joined {member.joined}</span>{canManageAccounts && member.userId && member.role !== 'Club admin' && <button className="icon-button danger-action" aria-label={`Remove ${member.name}`} onClick={() => onDelete(member)}><Trash2 size={15} /></button>}{canManageAccounts && !member.userId && <><button className="icon-button danger-action" aria-label={`Remove ${member.name}`} onClick={() => onDelete(member)}><Trash2 size={15} /></button><button className="icon-button" aria-label={`Edit ${member.name}`} onClick={() => onEdit(member)}><Settings size={15} /></button></>}</div>) : <EmptyState title={search ? 'No members found' : 'Your directory is empty'} text={search ? 'Try another name, role, or area of study.' : 'Add your first member to get started.'} />}</div></section></>
}

function AnnouncementsView({ announcements, onCreate, onDelete, onLike }: { announcements: Announcement[]; onCreate: () => void; onDelete: (item: Announcement) => void; onLike: (id: string) => void }) {
  return <><PageHeading eyebrow="A NOTE TO THE CLUB" title="Announcements" description="The latest from your club, all in one place." action={<button className="button button-primary" onClick={onCreate}><Plus size={16} />Share an update</button>} /><div className="announcement-feed">{announcements.length ? announcements.map((announcement) => <article className="panel feed-card" key={announcement.id}><div className="announcement-head"><Avatar initials={announcement.initials} color={announcement.color} small /><span><strong>{announcement.author}</strong><small>{announcement.date}</small></span><button className="icon-button announcement-more danger-action" aria-label={`Delete ${announcement.title}`} onClick={() => onDelete(announcement)}><Trash2 size={15} /></button></div><h2>{announcement.title}</h2><p>{announcement.body}</p><button className={`reaction-button${announcement.liked ? ' reacted' : ''}`} aria-pressed={Boolean(announcement.liked)} onClick={() => onLike(announcement.id)}><Heart size={14} fill={announcement.liked ? 'currentColor' : 'none'} /> Appreciate · {announcement.likes}</button></article>) : <EmptyState title="No announcements yet" text="Share the first update with your club." />}<button className="compose-button feed-compose" onClick={onCreate}><span className="compose-avatar">MC</span><span>Share something with your club...</span><Image size={16} /></button></div></>
}

function SettingsView({ data, user, workspace, onCopyInvite, onSave, onChangePassword, onExport, onImport, onReset, onSignOut, canInstall, onInstall }: { data: ClubData; user: User; workspace: Workspace; onCopyInvite: () => void; onSave: (clubName: string, adminName: string) => void; onChangePassword: (currentPassword: string, nextPassword: string) => Promise<void>; onExport: () => void; onImport: (file: File | undefined) => void; onReset: () => void; onSignOut: () => void; canInstall: boolean; onInstall: () => void }) {
  const [passwordError, setPasswordError] = useState('')
  const [passwordChanged, setPasswordChanged] = useState(false)
  const [passwordBusy, setPasswordBusy] = useState(false)

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const form = new FormData(event.currentTarget)
    const club = String(form.get('clubName')).trim()
    const admin = String(form.get('adminName')).trim()
    if (club && admin) onSave(club, admin)
  }
  async function submitPassword(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const formElement = event.currentTarget
    setPasswordError('')
    setPasswordChanged(false)
    const form = new FormData(formElement)
    const currentPassword = String(form.get('currentPassword') ?? '')
    const nextPassword = String(form.get('newPassword') ?? '')
    const confirmPassword = String(form.get('confirmPassword') ?? '')
    if (nextPassword.length < 8) {
      setPasswordError('Your new password must be at least 8 characters.')
      return
    }
    if (nextPassword !== confirmPassword) {
      setPasswordError('The new passwords do not match.')
      return
    }
    if (currentPassword === nextPassword) {
      setPasswordError('Choose a new password that differs from your current password.')
      return
    }
    setPasswordBusy(true)
    try {
      await onChangePassword(currentPassword, nextPassword)
      formElement.reset()
      setPasswordChanged(true)
    } catch (error) {
      setPasswordError(error instanceof Error ? error.message : 'Unable to change your password.')
    } finally {
      setPasswordBusy(false)
    }
  }
  return <><PageHeading eyebrow="MAKE IT YOURS" title="Settings" description="Manage your shared club and account." /><div className="settings-grid">{workspace.role === 'owner' && <section className="panel settings-panel"><div className="settings-panel-heading"><span className="settings-icon"><Settings size={18} /></span><div><h2>Club profile</h2><p>Updates sync for everyone in your club.</p></div></div><form className="modal-form" key={`${data.clubName}-${data.adminName}`} onSubmit={submit}><label>Club name<input name="clubName" required maxLength={60} defaultValue={data.clubName} /></label><label>Administrator name<input name="adminName" required maxLength={60} defaultValue={data.adminName} /></label><button className="button button-primary" type="submit">Save details</button></form></section>}<section className="panel settings-panel"><div className="settings-panel-heading"><span className="settings-icon stat-lilac"><Users size={18} /></span><div><h2>Account</h2><p>Signed in as {user.user_metadata.display_name ?? user.email} · {user.email}</p></div></div><p className="install-help">Secure account access is available on any device with an internet connection.</p><form className="modal-form password-change-form" onSubmit={submitPassword}><h3>Change password</h3><label>Current password<input name="currentPassword" type="password" autoComplete="current-password" required maxLength={128} /></label><label>New password<input name="newPassword" type="password" autoComplete="new-password" required minLength={8} maxLength={128} /></label><label>Confirm new password<input name="confirmPassword" type="password" autoComplete="new-password" required minLength={8} maxLength={128} /></label>{passwordError && <p className="auth-error" role="alert">{passwordError}</p>}{passwordChanged && <p className="password-success" role="status">Password changed. Use your new password next time you sign in.</p>}<button className="button button-primary" type="submit" disabled={passwordBusy}>{passwordBusy ? 'Updating password…' : 'Update password'}</button></form><button className="button button-danger account-signout" onClick={onSignOut}><LogOut size={15} />Sign out</button></section><section className="panel settings-panel"><div className="settings-panel-heading"><span className="settings-icon stat-blue"><Users size={18} /></span><div><h2>Invite your members</h2><p>Share this code with people you trust. Anyone with it can join your club.</p></div></div><div className="invite-code-row"><code>{workspace.invite_code}</code><button className="button button-secondary" onClick={onCopyInvite}>Copy invite code</button></div></section><section className="panel settings-panel"><div className="settings-panel-heading"><span className="settings-icon stat-mint"><Download size={18} /></span><div><h2>Your data</h2><p>Shared club data is stored securely in your Supabase project.</p></div></div><div className="settings-actions"><button className="button button-secondary" onClick={onExport}><Download size={15} />Download a backup</button><label className="button button-secondary import-button"><Download size={15} />Restore from backup<input type="file" accept="application/json,.json" onChange={(event) => { onImport(event.currentTarget.files?.[0]); event.currentTarget.value = '' }} /></label>{workspace.role === 'owner' && <button className="button button-danger" onClick={onReset}><Trash2 size={15} />Clear shared workspace</button>}</div></section><section className="panel settings-panel"><div className="settings-panel-heading"><span className="settings-icon stat-peach"><Sparkles size={18} /></span><div><h2>Mobile app</h2><p>Open the hosted club on any device, or install it for an app-like experience.</p></div></div>{canInstall ? <button className="button button-primary" onClick={onInstall}>Install app</button> : <p className="install-help">On mobile, use your browser’s Share or menu button, then choose “Add to Home Screen”.</p>}</section></div></>
}

function EmptyState({ title, text }: { title: string; text: string }) {
  return <div className="empty-state"><span><CalendarDays size={22} /></span><strong>{title}</strong><p>{text}</p></div>
}

function Modal({ title, subtitle, onClose, children }: { title: string; subtitle: string; onClose: () => void; children: ReactNode }) {
  return <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose() }}><section className="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title"><button className="modal-close icon-button" onClick={onClose} aria-label="Close"><X size={18} /></button><span className="modal-mark"><Sparkles size={18} /></span><h2 id="modal-title">{title}</h2><p className="modal-subtitle">{subtitle}</p>{children}</section></div>
}

export default App
