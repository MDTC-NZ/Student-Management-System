import { useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from 'react'
import {
  ArrowUpRight, Bell, CalendarDays, Check, ChevronDown, ChevronRight,
  CircleHelp, Clock3, Command, Download, Heart, Image, LayoutDashboard, MapPin, Wallet,
  LogOut, Megaphone, MessageSquare, MoreHorizontal, Plus, Search, Send, Settings, Sparkles, Trash2, Users, X,
} from 'lucide-react'
import type { User } from '@supabase/supabase-js'
import { authRedirectUrl, backendConfigured, supabase } from './lib/supabase'
import { FinanceView } from './FinanceView'

type View = 'Overview' | 'Events' | 'Members' | 'Announcements' | 'Chat' | 'Finance' | 'Settings'
type ChatChannel = 'general' | 'events' | 'announcements'
type ChatMessage = { id: string; workspace_id: string; user_id: string | null; display_name: string; channel: ChatChannel; content: string; created_at: string }
type ClubEvent = { id: string; title: string; category: string; date: string; time: string; location: string; attendees: number; color: string }
type Permission = 'events' | 'announcements' | 'members' | 'settings' | 'financials' | 'manageRoles'
type ClubPermissions = Record<Permission, boolean>
type ClubRole = { id: string; name: string; permissions: ClubPermissions }
type Member = { id: string; name: string; role: string; roleId?: string; isOwner?: boolean; year: string; initials: string; color: string; joined: string; userId?: string }
type Announcement = { id: string; title: string; body: string; author: string; initials: string; date: string; color: string; likes: number; liked?: boolean }
type ClubData = { clubName: string; adminName: string; events: ClubEvent[]; members: Member[]; announcements: Announcement[]; rsvps: Record<string, string[]> }
type Workspace = { id: string; name: string; invite_code: string; role: 'owner' | 'member'; positionRoleId: string | null; roles: ClubRole[]; permissions: ClubPermissions; data: ClubData }
type ManagedAccount = { id: string; email: string; emailConfirmed: boolean; name: string; role: 'owner' | 'member'; positionRoleId: string | null; membershipStatus: 'pending' | 'active' | 'inactive'; banned: boolean; createdAt: string }
type AdminResponse = { accounts?: ManagedAccount[]; message?: string; error?: string }
const superadminEmail = 'mdtc@kiaoragaming.xyz'
const colors = ['lilac', 'peach', 'mint']
const avatarColors = ['avatar-lilac', 'avatar-peach', 'avatar-mint', 'avatar-blue', 'avatar-rose']
const permissionKeys: Permission[] = ['events', 'announcements', 'members', 'settings', 'financials', 'manageRoles']
const permissionLabels: Record<Permission, string> = {
  events: 'Manage events',
  announcements: 'Manage announcements',
  members: 'Manage the member directory',
  settings: 'Manage club settings',
  financials: 'Manage club finances',
  manageRoles: 'Create roles and assign positions',
}
const noPermissions: ClubPermissions = { events: false, announcements: false, members: false, settings: false, financials: false, manageRoles: false }
const fullPermissions: ClubPermissions = { events: true, announcements: true, members: true, settings: true, financials: true, manageRoles: true }
const initialClubRoles: ClubRole[] = [
  { id: '10000000-0000-4000-8000-000000000001', name: 'President', permissions: { ...fullPermissions } },
  { id: '10000000-0000-4000-8000-000000000002', name: 'Vice-President', permissions: { ...noPermissions, events: true, announcements: true } },
  { id: '10000000-0000-4000-8000-000000000003', name: 'Secretary', permissions: { ...noPermissions, announcements: true } },
  { id: '10000000-0000-4000-8000-000000000004', name: 'Treasurer', permissions: { ...noPermissions, financials: true } },
  { id: '10000000-0000-4000-8000-000000000005', name: 'Events Coordinator', permissions: { ...noPermissions, events: true } },
  { id: '10000000-0000-4000-8000-000000000006', name: 'Technical Officer', permissions: { ...noPermissions, members: true } },
]

const navigation: { label: View; icon: typeof LayoutDashboard }[] = [
  { label: 'Overview', icon: LayoutDashboard }, { label: 'Events', icon: CalendarDays },
  { label: 'Members', icon: Users }, { label: 'Announcements', icon: Megaphone },
  { label: 'Chat', icon: MessageSquare }, { label: 'Finance', icon: Wallet },
]

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null
}

function errorMessage(error: unknown, fallback: string) {
  if (error instanceof Error) return error.message
  if (isRecord(error) && typeof error.message === 'string') {
    const code = typeof error.code === 'string' ? ` (${error.code})` : ''
    const details = typeof error.details === 'string' ? ` ${error.details}` : ''
    return `${error.message}${code}${details}`
  }
  return fallback
}

async function invokeAdminAccounts(action: string, details: Record<string, unknown> = {}) {
  if (!supabase) throw new Error('The account-management service is not configured.')
  const { data, error } = await supabase.functions.invoke<AdminResponse>('admin-accounts', {
    body: { action, ...details },
  })
  if (error) {
    if (error.context instanceof Response) {
      const responseText = await error.context.clone().text()
      let responseBody: unknown
      try {
        responseBody = JSON.parse(responseText)
      } catch (parseError) {
        if (!(parseError instanceof SyntaxError)) throw parseError
      }
      if (isRecord(responseBody) && typeof responseBody.error === 'string') {
        throw new Error(responseBody.error)
      }
    }
    throw new Error(error.message)
  }
  if (!data) throw new Error('The account-management service returned no response.')
  if (data.error) throw new Error(data.error)
  return data
}

function validateBackup(value: unknown): value is ClubData {
  if (!isRecord(value) || typeof value.clubName !== 'string' || typeof value.adminName !== 'string'
    || !Array.isArray(value.events) || !Array.isArray(value.members) || !Array.isArray(value.announcements)
    || (value.roles !== undefined && !validRoles(value.roles))
    || !isRecord(value.rsvps) || !Object.values(value.rsvps).every((ids) => Array.isArray(ids) && ids.every((id) => typeof id === 'string'))) return false
  const eventIsValid = (entry: unknown) => isRecord(entry) && ['id', 'title', 'category', 'date', 'time', 'location', 'color'].every((key) => typeof entry[key] === 'string') && typeof entry.attendees === 'number'
  const memberIsValid = (entry: unknown) => isRecord(entry) && ['id', 'name', 'role', 'year', 'initials', 'color', 'joined'].every((key) => typeof entry[key] === 'string')
  const announcementIsValid = (entry: unknown) => isRecord(entry) && ['id', 'title', 'body', 'author', 'initials', 'date', 'color'].every((key) => typeof entry[key] === 'string') && typeof entry.likes === 'number'
    && (entry.liked === undefined || typeof entry.liked === 'boolean')
  return value.events.every(eventIsValid) && value.members.every(memberIsValid) && value.announcements.every(announcementIsValid)
}

function isClubRole(value: unknown): value is ClubRole {
  if (!isRecord(value) || typeof value.id !== 'string' || typeof value.name !== 'string') return false
  const permissions = value.permissions
  if (!isRecord(permissions)) return false
  return permissionKeys.every((key) => typeof permissions[key] === 'boolean')
}

function validRoles(value: unknown): value is ClubRole[] {
  return Array.isArray(value) && value.every(isClubRole)
}

function isChatChannel(value: unknown): value is ChatChannel {
  return value === 'general' || value === 'events' || value === 'announcements'
}

function isChatMessage(value: unknown): value is ChatMessage {
  return isRecord(value)
    && typeof value.id === 'string'
    && typeof value.workspace_id === 'string'
    && (typeof value.user_id === 'string' || value.user_id === null)
    && typeof value.display_name === 'string'
    && isChatChannel(value.channel)
    && typeof value.content === 'string'
    && typeof value.created_at === 'string'
}

function permissionsForRole(role: ClubRole | undefined, isOwner: boolean): ClubPermissions {
  return isOwner ? { ...fullPermissions } : role ? { ...role.permissions } : { ...noPermissions }
}

function clubContent(value: ClubData): ClubData {
  return {
    clubName: value.clubName,
    adminName: value.adminName,
    events: value.events,
    members: value.members,
    announcements: value.announcements,
    rsvps: value.rsvps,
  }
}

function initials(name: string) {
  return name.trim().split(/\s+/).slice(0, 2).map((part) => part[0]?.toUpperCase() ?? '').join('')
}

function dateLabel(value: string) {
  const parsed = new Date(`${value}T12:00:00`)
  return Number.isNaN(parsed.getTime()) ? { month: 'TBA', day: '—' } : { month: parsed.toLocaleDateString('en', { month: 'short' }), day: parsed.toLocaleDateString('en', { day: '2-digit' }) }
}

function readableTime(value: string) {
  if (!value) return 'Time TBA'
  const [hour, minute] = value.split(':').map(Number)
  if (!Number.isFinite(hour) || !Number.isFinite(minute)) return value
  return new Date(2000, 0, 1, hour, minute).toLocaleTimeString('en', { hour: 'numeric', minute: '2-digit' })
}

function Avatar({ initials: letters, color, small = false }: { initials: string; color: string; small?: boolean }) {
  return <span className={`avatar ${color}${small ? ' avatar-small' : ''}`}>{letters}</span>
}

function AuthScreen({ mode, onModeChange, onSubmit, onForgotPassword, error, message, busy }: {
  mode: 'login' | 'register'
  onModeChange: (mode: 'login' | 'register') => void
  onSubmit: (event: FormEvent<HTMLFormElement>) => void
  onForgotPassword: (email: string) => void
  error: string
  message: string
  busy: boolean
}) {
  const registering = mode === 'register'
  const [joinClub, setJoinClub] = useState(false)
  useEffect(() => setJoinClub(false), [mode])
  return <main className="auth-screen">
    <section className="auth-card">
      <a className="brand auth-brand" href="#" onClick={(event) => event.preventDefault()}><span className="brand-mark"><span /><span /><span /><span /></span><span className="brand-name">mdtc<span>.</span></span></a>
      <span className="auth-eyebrow">{registering ? 'START YOUR SOCIAL CLUB' : 'WELCOME BACK'}</span>
      <h1>{registering ? 'Bring your people together.' : 'Your people, your plans.'}</h1>
      <p className="auth-description">{registering ? 'Create an account to plan get-togethers, share interests, and stay connected.' : 'Sign in to see what your social club has planned.'}</p>
      <form className="auth-form" onSubmit={onSubmit}>
        {registering && <>
          <label>Your name<input name="name" autoComplete="name" required maxLength={80} placeholder="e.g. Maya Chen" /></label>
          <div className="auth-mode-toggle"><button type="button" className={!joinClub ? 'selected' : ''} onClick={() => setJoinClub(false)}>Create a social club</button><button type="button" className={joinClub ? 'selected' : ''} onClick={() => setJoinClub(true)}>Join with invite</button></div>
          {joinClub
            ? <label>Club invite code<input name="inviteCode" required maxLength={36} autoCapitalize="characters" placeholder="Enter your club code" /></label>
            : <label>Social club name<input name="clubName" autoComplete="organization" required maxLength={60} defaultValue="Manukau Digital Tech Collective" /></label>}
        </>}
        <label>Email address<input name="email" type="email" autoComplete="email" required maxLength={254} placeholder="you@example.com" /></label>
        <label>Password<input name="password" type="password" autoComplete={registering ? 'new-password' : 'current-password'} required minLength={registering ? 8 : undefined} maxLength={128} placeholder={registering ? 'At least 8 characters' : 'Your password'} /></label>
        {!registering && <button className="auth-forgot-link" type="button" onClick={(event) => {
          const form = event.currentTarget.form
          const email = String(new FormData(form ?? undefined).get('email') ?? '').trim().toLowerCase()
          onForgotPassword(email)
        }}>Forgot password?</button>}
        {registering && <label>Confirm password<input name="confirmPassword" type="password" autoComplete="new-password" required minLength={8} maxLength={128} placeholder="Enter your password again" /></label>}
        {error && <p className="auth-error" role="alert">{error}</p>}
        {message && <p className="password-success" role="status">{message}</p>}
        <button className="button button-primary auth-submit" type="submit" disabled={busy}>{busy ? 'Please wait…' : registering ? 'Create account' : 'Sign in'}</button>
      </form>
      <p className="auth-switch">{registering ? 'Already have an account?' : 'New to MDTC?'} <button onClick={() => onModeChange(registering ? 'login' : 'register')}>{registering ? 'Sign in' : 'Create an account'}</button></p>
      <p className="auth-notice">Accounts are securely managed by Supabase. Social club members share plans and updates across devices.</p>
    </section>
  </main>
}

function ResetPasswordScreen({ onSubmit, onBack, error, busy }: {
  onSubmit: (event: FormEvent<HTMLFormElement>) => void
  onBack: () => void
  error: string
  busy: boolean
}) {
  const [passwordError, setPasswordError] = useState('')

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setPasswordError('')
    const form = new FormData(event.currentTarget)
    const password = String(form.get('newPassword') ?? '')
    const confirmation = String(form.get('confirmPassword') ?? '')
    if (password.length < 8) {
      setPasswordError('Your new password must be at least 8 characters.')
      return
    }
    if (password !== confirmation) {
      setPasswordError('The passwords do not match.')
      return
    }
    onSubmit(event)
  }

  return <main className="auth-screen"><section className="auth-card">
    <a className="brand auth-brand" href="#" onClick={(event) => event.preventDefault()}><span className="brand-mark"><span /><span /><span /><span /></span><span className="brand-name">mdtc<span>.</span></span></a>
    <span className="auth-eyebrow">ACCOUNT RECOVERY</span>
    <h1>Choose a new password.</h1>
    <p className="auth-description">Use at least 8 characters. You’ll use this password the next time you sign in.</p>
    <form className="auth-form" onSubmit={submit}>
      <label>New password<input name="newPassword" type="password" autoComplete="new-password" required minLength={8} maxLength={128} /></label>
      <label>Confirm new password<input name="confirmPassword" type="password" autoComplete="new-password" required minLength={8} maxLength={128} /></label>
      {(passwordError || error) && <p className="auth-error" role="alert">{passwordError || error}</p>}
      <button className="button button-primary auth-submit" type="submit" disabled={busy}>{busy ? 'Updating password…' : 'Reset password'}</button>
    </form>
    <p className="auth-switch"><button onClick={onBack}>Back to sign in</button></p>
  </section></main>
}

function AuthLoading({ message = 'Connecting securely…' }: { message?: string }) {
  return <main className="auth-screen"><section className="auth-card auth-status"><span className="auth-mark"><Sparkles size={20} /></span><h1>{message}</h1><p className="auth-description">Please keep this page open.</p></section></main>
}

function BackendSetup() {
  return <main className="auth-screen"><section className="auth-card"><a className="brand auth-brand" href="#" onClick={(event) => event.preventDefault()}><span className="brand-mark"><span /><span /><span /><span /></span><span className="brand-name">mdtc<span>.</span></span></a><span className="auth-eyebrow">ONE MORE SETUP STEP</span><h1>Connect your club online.</h1><p className="auth-description">Add your Supabase project URL and public anon key to <code>.env.local</code>, then rebuild and restart the local website. See the README setup guide.</p><p className="auth-notice">Never put a Supabase service-role key in the website. Configure Row Level Security using the included database migration first.</p></section></main>
}

function WorkspaceError({ message, onSignOut, onJoinClub, canJoinClub }: { message: string; onSignOut: () => void; onJoinClub: (inviteCode: string) => Promise<void>; canJoinClub: boolean }) {
  const [inviteCode, setInviteCode] = useState('')
  const [joinError, setJoinError] = useState('')
  const [joining, setJoining] = useState(false)

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setJoinError('')
    setJoining(true)
    try {
      await onJoinClub(inviteCode)
    } catch (error) {
      console.error('Unable to join a club from the workspace recovery screen:', error)
      setJoinError(errorMessage(error, 'Unable to join this club.'))
    } finally {
      setJoining(false)
    }
  }

  return <main className="auth-screen"><section className="auth-card"><span className="auth-eyebrow">CLUB WORKSPACE</span><h1>We couldn’t open your club.</h1><p className="auth-error" role="alert">{message}</p><p className="auth-description workspace-error-description">{canJoinClub ? 'If this account has not joined a club yet, enter the Manukau Digital Tech Collective invite code below. If it already belongs to another club, ask the club owner for help moving the account.' : 'Your current membership status prevents access. Contact the club administrator to activate your membership, then sign in again.'}</p>{canJoinClub && <form className="auth-form workspace-join-form" onSubmit={submit}><label>Club invite code<input name="inviteCode" value={inviteCode} onChange={(event) => setInviteCode(event.target.value.toUpperCase())} required maxLength={36} autoCapitalize="characters" placeholder="Enter your code exactly as shown in Settings" /></label>{joinError && <p className="auth-error" role="alert">{joinError}</p>}<button className="button button-primary auth-submit" type="submit" disabled={joining}>{joining ? 'Joining club…' : 'Join club'}</button></form>}<button className="button button-secondary auth-submit" onClick={onSignOut}>Back to sign in</button></section></main>
}

function App() {
  const [user, setUser] = useState<User | null>(null)
  const [authReady, setAuthReady] = useState(false)
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login')
  const [authError, setAuthError] = useState('')
  const [authMessage, setAuthMessage] = useState('')
  const [authBusy, setAuthBusy] = useState(false)
  const [passwordRecovery, setPasswordRecovery] = useState(false)
  const [workspace, setWorkspace] = useState<Workspace | null>(null)
  const [workspaceLoading, setWorkspaceLoading] = useState(false)
  const [workspaceError, setWorkspaceError] = useState('')
  const [membershipStatusBlocked, setMembershipStatusBlocked] = useState(false)
  const [workspaceReload, setWorkspaceReload] = useState(0)

  async function submitAuth(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setAuthError('')
    setAuthMessage('')
    setAuthBusy(true)
    const form = new FormData(event.currentTarget)
    const name = String(form.get('name') ?? '').trim()
    const email = String(form.get('email') ?? '').trim().toLowerCase()
    const password = String(form.get('password') ?? '')
    try {
      if (!supabase) throw new Error('The authentication service is not configured.')
      if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error('Enter a valid email address.')
      if (authMode === 'register') {
        const confirmPassword = String(form.get('confirmPassword') ?? '')
        const clubName = String(form.get('clubName') ?? '').trim()
        const inviteCode = String(form.get('inviteCode') ?? '').trim().toUpperCase()
        const joining = Boolean(inviteCode)
        if (!name) throw new Error('Enter your name.')
        if (joining && !inviteCode) throw new Error('Enter the club invite code.')
        if (!joining && !clubName) throw new Error('Enter your club name.')
        if (password.length < 8) throw new Error('Choose a password with at least 8 characters.')
        if (password !== confirmPassword) throw new Error('The passwords do not match.')
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: authRedirectUrl ?? window.location.origin,
            data: { display_name: name, onboarding_mode: joining ? 'join' : 'create', club_name: joining ? '' : clubName, invite_code: joining ? inviteCode : '' },
          },
        })
        if (error) throw error
        if (!data.session) setAuthMessage('This Supabase project still requires email confirmation. To sign in automatically, disable Confirm email in Supabase under Authentication → Providers → Email, then register again.')
        else setUser(data.user)
      } else {
        const { data, error } = await supabase.auth.signInWithPassword({ email, password })
        if (error) throw error
        setUser(data.user)
      }
    } catch (error) {
      console.error('Authentication request failed:', error)
      setAuthError(error instanceof Error ? error.message : 'Unable to complete sign-in.')
    } finally {
      setAuthBusy(false)
    }
  }

  async function requestPasswordReset(email: string) {
    setAuthError('')
    setAuthMessage('')
    if (!supabase) {
      setAuthError('The authentication service is not configured.')
      return
    }
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setAuthError('Enter your account email address first.')
      return
    }
    setAuthBusy(true)
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: authRedirectUrl ?? window.location.origin,
      })
      if (error) throw error
      setAuthMessage('If an account exists for that email, a password reset link will be sent. Check your inbox and spam folder.')
    } catch (error) {
      console.error('Password reset email request failed:', error)
      setAuthError(error instanceof Error ? error.message : 'Unable to send a password reset email.')
    } finally {
      setAuthBusy(false)
    }
  }

  async function submitRecoveredPassword(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setAuthError('')
    const form = new FormData(event.currentTarget)
    const password = String(form.get('newPassword') ?? '')
    setAuthBusy(true)
    try {
      if (!supabase) throw new Error('The authentication service is not configured.')
      const { error } = await supabase.auth.updateUser({ password })
      if (error) throw error
      setPasswordRecovery(false)
      setAuthMessage('Your password was updated successfully.')
    } catch (error) {
      console.error('Password reset failed:', error)
      setAuthError(error instanceof Error ? error.message : 'Unable to update your password. Request a new reset link and try again.')
    } finally {
      setAuthBusy(false)
    }
  }

  function signOut() {
    if (!supabase) return
    void supabase.auth.signOut().then(({ error }) => {
      if (error) {
        console.error('Unable to sign out:', error)
        setAuthError('Unable to sign out. Please try again.')
        return
      }
      setUser(null)
      setAuthMode('login')
      setAuthError('')
      setAuthMessage('')
      setWorkspace(null)
      setPasswordRecovery(false)
    }).catch((error: unknown) => {
      console.error('Unable to sign out:', error)
      setAuthError('Unable to sign out. Please try again.')
    })
  }

  useEffect(() => {
    if (!supabase) return
    let active = true
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (active) {
        if (event === 'PASSWORD_RECOVERY') {
          setPasswordRecovery(true)
          setAuthError('')
          setAuthMessage('')
        }
        setUser(session?.user ?? null)
        setAuthReady(true)
      }
    })
    void supabase.auth.getSession().then(({ data, error }) => {
      if (error) throw error
      if (active) {
        setUser(data.session?.user ?? null)
        setAuthReady(true)
      }
    }).catch((error: unknown) => {
      console.error('Unable to restore the Supabase session:', error)
      if (active) {
        setAuthError('Unable to connect to the account service. Try refreshing the page.')
        setAuthReady(true)
      }
    })
    return () => {
      active = false
      subscription.unsubscribe()
    }
  }, [])

  useEffect(() => {
    if (!supabase || !user) {
      setWorkspace(null)
      setWorkspaceLoading(false)
      setWorkspaceError('')
      setMembershipStatusBlocked(false)
      return
    }
    let active = true
    setWorkspace(null)
    setWorkspaceLoading(true)
    setWorkspaceError('')
    setMembershipStatusBlocked(false)
    void (async () => {
      const { data: memberships, error: membershipError } = await supabase
        .from('club_members').select('workspace_id,membership_status').eq('user_id', user.id).limit(1)
      if (membershipError) throw membershipError
      const currentMembership = memberships?.[0]
      if (currentMembership && currentMembership.membership_status !== 'active') {
        if (active) setMembershipStatusBlocked(true)
        const statusMessage = currentMembership.membership_status === 'pending'
          ? 'Your club membership is pending approval. Contact the club administrator.'
          : 'Your club membership is inactive. Contact the club administrator.'
        throw new Error(statusMessage)
      }
      let workspaceId = currentMembership?.workspace_id as string | undefined
      if (!workspaceId) {
        const mode = user.user_metadata.onboarding_mode
        const result = mode === 'join'
          ? await supabase.rpc('join_club', { p_invite_code: String(user.user_metadata.invite_code ?? '') })
          : mode === 'create'
            ? await supabase.rpc('create_club', { p_name: String(user.user_metadata.club_name ?? '') })
            : { data: null, error: new Error('This account is not linked to a club. Sign up with a club invite or create a club.') }
        if (result.error) throw result.error
        if (typeof result.data !== 'string') throw new Error('The club setup did not return a workspace. Try signing in again.')
        workspaceId = result.data
      }
      const { data: row, error: workspaceError } = await supabase
        .from('club_workspaces').select('id,name,invite_code,data').eq('id', workspaceId).single()
      if (workspaceError) throw workspaceError
      if (!isRecord(row) || !validateBackup(row.data)) throw new Error('The club workspace data is invalid.')
      const [{ data: membership, error: roleError }, { data: members, error: membersError }] = await Promise.all([
        supabase.from('club_members').select('role,position_role_id').eq('workspace_id', workspaceId).eq('user_id', user.id).single(),
        supabase.from('club_members').select('user_id,display_name,role,position_role_id,joined_at').eq('workspace_id', workspaceId).eq('membership_status', 'active'),
      ])
      if (roleError) throw new Error(`Could not verify your club membership: ${errorMessage(roleError, 'Unknown database error.')}`)
      if (membersError) throw membersError
      const rowData = row.data as ClubData & { roles?: unknown }
      const roles = validRoles(rowData.roles) ? rowData.roles : initialClubRoles
      const roleById = new Map(roles.map((role) => [role.id, role]))
      const accountMembers: Member[] = (members ?? []).map((member) => ({
        id: `account:${member.user_id}`,
        userId: member.user_id,
        name: member.display_name,
        role: roleById.get(member.position_role_id ?? '')?.name ?? (member.role === 'owner' ? 'Club admin' : 'Member'),
        roleId: member.position_role_id ?? undefined,
        isOwner: member.role === 'owner',
        year: member.role === 'owner' ? 'Club administrator' : 'Club member',
        initials: initials(member.display_name),
        color: 'avatar-lilac',
        joined: new Date(member.joined_at).toLocaleDateString('en', { month: 'short', year: 'numeric' }),
      }))
      const sharedData: ClubData = {
        ...row.data,
        members: [...row.data.members.filter((member) => !member.userId), ...accountMembers],
      }
      if (active) setWorkspace({
        id: String(row.id),
        name: String(row.name),
        invite_code: String(row.invite_code),
        role: membership?.role === 'owner' ? 'owner' : 'member',
        positionRoleId: membership?.position_role_id ?? null,
        roles,
        permissions: permissionsForRole(roleById.get(membership?.position_role_id ?? ''), membership?.role === 'owner'),
        data: clubContent(sharedData),
      })
    })().catch((error: unknown) => {
      console.error('Unable to load the shared club workspace:', error)
      if (active) setWorkspaceError(errorMessage(error, 'Unable to load this club.'))
    }).finally(() => {
      if (active) setWorkspaceLoading(false)
    })
    return () => { active = false }
  }, [user, workspaceReload])

  if (!backendConfigured || !supabase) return <BackendSetup />
  if (!authReady) return <AuthLoading />
  if (passwordRecovery) return <ResetPasswordScreen onSubmit={submitRecoveredPassword} onBack={signOut} error={authError} busy={authBusy} />
  if (!user) return <AuthScreen mode={authMode} onModeChange={(mode) => { setAuthMode(mode); setAuthError(''); setAuthMessage('') }} onSubmit={submitAuth} onForgotPassword={requestPasswordReset} error={authError} message={authMessage} busy={authBusy} />
  if (workspaceLoading) return <AuthLoading message="Opening your club…" />
  if (workspaceError) return <WorkspaceError message={workspaceError} onSignOut={signOut} canJoinClub={!membershipStatusBlocked} onJoinClub={async (inviteCode) => {
    if (!supabase) throw new Error('The authentication service is not configured.')
    const code = inviteCode.trim().toUpperCase()
    if (!code) throw new Error('Enter the club invite code.')
    const { error } = await supabase.rpc('join_club', { p_invite_code: code })
    if (error) throw error
    setWorkspaceError('')
    setWorkspaceLoading(true)
    setWorkspaceReload((attempt) => attempt + 1)
  }} />
  if (!workspace) return <AuthLoading message="Preparing your club…" />
  const client = supabase
  if (!client) return <BackendSetup />
  return <Clubhouse user={user} workspace={workspace} onSignOut={signOut}
    onReloadWorkspace={() => setWorkspaceReload((attempt) => attempt + 1)}
    onRolesUpdated={(roles) => setWorkspace((current) => {
      if (!current || JSON.stringify(current.roles) === JSON.stringify(roles)) return current
      return {
        ...current,
        roles,
        permissions: permissionsForRole(roles.find((role) => role.id === (current.positionRoleId ?? '')), current.role === 'owner'),
      }
    })}
    onChangePassword={async (currentPassword, nextPassword) => {
    const email = user.email
    if (!email) throw new Error('This account does not have an email address.')
    const { error: verifyError } = await client.auth.signInWithPassword({ email, password: currentPassword })
    if (verifyError) throw new Error('Your current password is incorrect.')
    const { error } = await client.auth.updateUser({ password: nextPassword })
    if (error) throw error
  }} />
}

function Clubhouse({ user, workspace, onSignOut, onReloadWorkspace, onRolesUpdated, onChangePassword }: { user: User; workspace: Workspace; onSignOut: () => void; onReloadWorkspace: () => void; onRolesUpdated: (roles: ClubRole[]) => void; onChangePassword: (currentPassword: string, nextPassword: string) => Promise<void> }) {
  const [data, setData] = useState<ClubData>(workspace.data)
  const currentUserName = String(user.user_metadata.display_name ?? user.email ?? data.adminName)
  const canRestoreData = workspace.permissions.events && workspace.permissions.announcements
    && workspace.permissions.members && workspace.permissions.settings
  const [activeView, setActiveView] = useState<View>('Overview')
  const [search, setSearch] = useState('')
  const [notice, setNotice] = useState('')
  const [storageError, setStorageError] = useState(false)
  const [eventEditor, setEventEditor] = useState<ClubEvent | null | undefined>(undefined)
  const [memberEditor, setMemberEditor] = useState<Member | null | undefined>(undefined)
  const [showAnnouncementForm, setShowAnnouncementForm] = useState(false)
  const [installPrompt, setInstallPrompt] = useState<Event & { prompt?: () => Promise<void>; userChoice?: Promise<{ outcome: string }> } | null>(null)
  const searchInput = useRef<HTMLInputElement>(null)

  useEffect(() => {
    const client = supabase
    if (!client) return
    const timer = window.setTimeout(() => {
      void client.rpc('save_club_data', { p_workspace_id: workspace.id, p_data: data })
        .then(({ error }) => {
          if (error) {
            console.error('Unable to save shared club changes:', error)
            setStorageError(true)
            setNotice('Could not sync changes. Check your connection and try again.')
          } else setStorageError(false)
        })
    }, 350)
    return () => window.clearTimeout(timer)
  }, [data, workspace.id])

  useEffect(() => {
    const client = supabase
    if (!client) return
    const channel = client.channel(`club-workspace-${workspace.id}`)
      .on('postgres_changes', {
        event: 'UPDATE',
        schema: 'public',
        table: 'club_workspaces',
        filter: `id=eq.${workspace.id}`,
      }, (payload) => {
        const remote = payload.new.data
        if (validateBackup(remote)) {
          const remoteContent = clubContent(remote)
          setData((current) => JSON.stringify(current) === JSON.stringify(remoteContent) ? current : remoteContent)
          const roles = (remote as ClubData & { roles?: unknown }).roles
          if (validRoles(roles)) onRolesUpdated(roles)
        }
      })
      .on('postgres_changes', {
        event: 'UPDATE',
        schema: 'public',
        table: 'club_members',
        filter: `workspace_id=eq.${workspace.id}`,
      }, () => onReloadWorkspace())
      .subscribe((status) => {
        if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') {
          console.error('Realtime club sync failed:', status)
          setStorageError(true)
        }
      })
    return () => { void client.removeChannel(channel) }
  }, [workspace.id, workspace.data.members])

  useEffect(() => {
    const handleInstall = (event: Event) => {
      event.preventDefault()
      setInstallPrompt(event as Event & { prompt?: () => Promise<void>; userChoice?: Promise<{ outcome: string }> })
    }
    window.addEventListener('beforeinstallprompt', handleInstall)
    return () => window.removeEventListener('beforeinstallprompt', handleInstall)
  }, [])

  useEffect(() => {
    const handleShortcut = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault()
        searchInput.current?.focus()
      }
    }
    window.addEventListener('keydown', handleShortcut)
    return () => window.removeEventListener('keydown', handleShortcut)
  }, [])

  const filteredMembers = useMemo(() => data.members.filter((member) =>
    `${member.name} ${member.role} ${member.year}`.toLowerCase().includes(search.toLowerCase())), [data.members, search])

  function navigate(view: View) {
    setActiveView(view)
    setSearch('')
  }

  function saveEvent(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!workspace.permissions.events) return
    const form = new FormData(event.currentTarget)
    const title = String(form.get('title')).trim()
    const date = String(form.get('date'))
    if (!title || !date) return
    const item: ClubEvent = {
      id: eventEditor?.id ?? crypto.randomUUID(),
      title,
      date,
      time: String(form.get('time')),
      location: String(form.get('location')).trim() || 'Location TBA',
      category: String(form.get('category')),
      attendees: eventEditor?.attendees ?? 0,
      color: eventEditor?.color ?? colors[data.events.length % colors.length],
    }
    setData((current) => ({ ...current, events: eventEditor ? current.events.map((entry) => entry.id === item.id ? item : entry) : [...current.events, item] }))
    setEventEditor(undefined)
    setNotice(eventEditor ? 'Event updated.' : 'Event added to the calendar.')
  }

  function saveMember(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!workspace.permissions.members) return
    const form = new FormData(event.currentTarget)
    const name = String(form.get('name')).trim()
    if (!name) return
    const item: Member = {
      id: memberEditor?.id ?? crypto.randomUUID(),
      name,
      role: String(form.get('role')).trim() || 'Member',
      year: String(form.get('year')).trim() || 'Social club member',
      initials: initials(name),
      color: memberEditor?.color ?? avatarColors[data.members.length % avatarColors.length],
      joined: memberEditor?.joined ?? new Date().toLocaleDateString('en', { month: 'short', year: 'numeric' }),
    }
    setData((current) => ({ ...current, members: memberEditor ? current.members.map((entry) => entry.id === item.id ? item : entry) : [...current.members, item] }))
    setMemberEditor(undefined)
    setNotice(memberEditor ? 'Member details updated.' : `${name} added to the directory.`)
  }

  function saveAnnouncement(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!workspace.permissions.announcements) return
    const form = new FormData(event.currentTarget)
    const title = String(form.get('title')).trim()
    const body = String(form.get('body')).trim()
    if (!title || !body) return
    setData((current) => ({ ...current, announcements: [{
      id: crypto.randomUUID(), title, body, author: currentUserName, initials: initials(currentUserName),
      date: 'Just now', color: 'avatar-blue', likes: 0,
    }, ...current.announcements] }))
    setShowAnnouncementForm(false)
    setNotice('Announcement published.')
  }

  function toggleRsvp(id: string) {
    const userRsvps = data.rsvps[user.id] ?? []
    const joined = userRsvps.includes(id)
    setData((current) => ({
      ...current,
      rsvps: {
        ...current.rsvps,
        [user.id]: joined ? userRsvps.filter((entry) => entry !== id) : [...userRsvps, id],
      },
      events: current.events.map((event) => event.id === id ? { ...event, attendees: Math.max(0, event.attendees + (joined ? -1 : 1)) } : event),
    }))
    setNotice(joined ? 'Your RSVP was removed.' : 'You’re on the list!')
  }

  function deleteEvent(event: ClubEvent) {
    if (!workspace.permissions.events) return
    if (!window.confirm(`Delete “${event.title}”? This cannot be undone.`)) return
    setData((current) => ({ ...current, events: current.events.filter((item) => item.id !== event.id), rsvps: Object.fromEntries(Object.entries(current.rsvps).map(([userId, ids]) => [userId, ids.filter((id) => id !== event.id)])) }))
    setNotice('Event deleted.')
  }

  async function deleteMember(member: Member) {
    if (!workspace.permissions.members) return
    if (!window.confirm(`Remove ${member.name} from the member directory?`)) return
    if (member.userId) {
      if (!supabase) return
      const { error } = await supabase.rpc('remove_club_member', { p_workspace_id: workspace.id, p_user_id: member.userId })
      if (error) {
        console.error('Unable to remove the club member:', error)
        setNotice(error.message)
        return
      }
    }
    setData((current) => ({ ...current, members: current.members.filter((item) => item.id !== member.id) }))
    setNotice('Member removed.')
  }

  function deleteAnnouncement(announcement: Announcement) {
    if (!workspace.permissions.announcements) return
    if (!window.confirm(`Delete “${announcement.title}”? This cannot be undone.`)) return
    setData((current) => ({ ...current, announcements: current.announcements.filter((item) => item.id !== announcement.id) }))
    setNotice('Announcement deleted.')
  }

  function toggleLike(id: string) {
    if (!workspace.permissions.announcements) return
    setData((current) => ({ ...current, announcements: current.announcements.map((item) => item.id === id ? { ...item, likes: Math.max(0, item.likes + (item.liked ? -1 : 1)), liked: !item.liked } : item) }))
  }

  function exportData() {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = 'mdtc-clubhouse-backup.json'
    link.click()
    URL.revokeObjectURL(url)
    setNotice('Your backup has been downloaded.')
  }

  async function importData(file: File | undefined) {
    if (!file) return
    if (!canRestoreData) {
      setNotice('Your club role does not have permission to restore all shared club data.')
      return
    }
    try {
      const imported: unknown = JSON.parse(await file.text())
      if (!validateBackup(imported)) {
        setNotice('That backup file is not a valid MDTC Clubhouse backup.')
        return
      }
      if (!window.confirm('Replace the shared club content with the selected backup? This affects every member.')) return
      setData(clubContent(imported))
      setNotice('Backup restored successfully.')
    } catch (error) {
      console.error('Unable to import club backup:', error)
      setNotice('Could not read that backup file. Choose a valid JSON backup.')
    }
  }

  function resetData() {
    if (!canRestoreData) return
    if (!window.confirm('Clear all events, member entries, announcements, and RSVPs in this shared club? This affects every member and cannot be undone.')) return
    setData((current) => ({ ...current, events: [], announcements: [], rsvps: {}, members: current.members.filter((member) => member.userId) }))
    setNotice('Your workspace has been cleared.')
  }

  async function assignPosition(userId: string, roleId: string): Promise<void> {
    if (!workspace.permissions.manageRoles) throw new Error('You do not have permission to assign club positions.')
    if (!supabase) throw new Error('The club service is not configured.')
    const selectedRole = workspace.roles.find((role) => role.id === roleId)
    const { error } = await supabase.rpc('set_club_member_position', {
      p_workspace_id: workspace.id,
      p_user_id: userId,
      p_role_id: roleId || null,
    })
    if (error) throw error
    if (userId === user.id) {
      onReloadWorkspace()
    } else {
      setData((current) => ({
        ...current,
        members: current.members.map((entry) => entry.userId === userId
          ? { ...entry, role: selectedRole?.name ?? 'Member', roleId: roleId || undefined }
          : entry),
      }))
    }
    setNotice(`${selectedRole?.name ?? 'Member'} position assigned.`)
  }

  async function assignDirectoryPosition(member: Member, roleId: string) {
    if (!member.userId) return
    try {
      await assignPosition(member.userId, roleId)
    } catch (error) {
      console.error('Unable to assign club position:', error)
      setNotice(errorMessage(error, 'Unable to update this club position.'))
    }
  }

  async function saveRoles(roles: ClubRole[]) {
    if (!workspace.permissions.manageRoles || !supabase) return
    const { error } = await supabase.rpc('save_club_roles', {
      p_workspace_id: workspace.id,
      p_roles: roles,
    })
    if (error) throw error
    setData((current) => ({
      ...current,
      members: current.members.map((member) => {
        if (!member.roleId) return member
        return { ...member, role: roles.find((role) => role.id === member.roleId)?.name ?? 'Member' }
      }),
    }))
    onRolesUpdated(roles)
    setNotice('Club roles saved.')
  }

  async function installApp() {
    if (!installPrompt?.prompt) return
    try {
      await installPrompt.prompt()
      const choice = await installPrompt.userChoice
      if (choice?.outcome === 'accepted') setNotice('MDTC Clubhouse is installing.')
      setInstallPrompt(null)
    } catch (error) {
      console.error('Unable to install the clubhouse app:', error)
      setNotice('The app could not be installed from this browser.')
    }
  }

  return <div className="app-shell">
    <aside className="sidebar">
      <a className="brand" href="#" onClick={(event) => { event.preventDefault(); navigate('Overview') }}><span className="brand-mark"><span /><span /><span /><span /></span><span className="brand-name">mdtc<span>.</span></span></a>
      <button className="club-switcher" onClick={() => navigate('Settings')}><span className="club-avatar">{data.clubName.slice(0, 1).toUpperCase()}</span><span className="club-info"><strong>{data.clubName}</strong><small>Social club</small></span><ChevronDown size={15} /></button>
      <div className="nav-section-label">WORKSPACE</div>
      <nav className="side-nav" aria-label="Main navigation">{navigation.map(({ label, icon: Icon }) => <button key={label} className={`nav-item${activeView === label ? ' active' : ''}`} onClick={() => navigate(label)}><Icon size={18} strokeWidth={1.8} /><span>{label}</span>{label === 'Announcements' && <span className="nav-count">{data.announcements.length}</span>}</button>)}</nav>
      <div className="sidebar-bottom">
        <div className="semester-card"><span className="semester-icon"><Sparkles size={15} /></span><div><strong>Social club</strong><span>Plans, people, and good times</span></div><div className="semester-progress"><span /></div></div>
        <button className={`nav-item${activeView === 'Settings' ? ' active' : ''}`} onClick={() => navigate('Settings')}><Settings size={18} strokeWidth={1.8} /><span>Settings</span></button>
        <button className="profile-row" onClick={() => navigate('Settings')}><Avatar initials={initials(currentUserName)} color="avatar-lilac" small /><span className="profile-copy"><strong>{currentUserName}</strong><small>{workspace.roles.find((role) => role.id === workspace.positionRoleId)?.name ?? (workspace.role === 'owner' ? 'Club admin' : 'Club member')}</small></span><MoreHorizontal size={18} /></button>
      </div>
    </aside>
    <main className="main-area">
      <header className="topbar"><div className="breadcrumbs"><span>Workspace</span><ChevronRight size={14} /><strong>{activeView}</strong></div><div className="topbar-actions">
        <label className="search-box"><Search size={16} /><input ref={searchInput} aria-label="Search members" placeholder="Search members..." value={search} onChange={(event) => { setSearch(event.target.value); setActiveView('Members') }} /><kbd><Command size={11} /> K</kbd></label>
        <button className="icon-button notification-button" aria-label="Show sync status" onClick={() => setNotice(storageError ? 'Could not sync data. Check your connection and try again.' : 'Your club data is connected to the cloud.')}><Bell size={18} /><span /></button><button className="icon-button topbar-signout" aria-label="Sign out" title="Sign out" onClick={onSignOut}><LogOut size={17} /></button><Avatar initials={initials(currentUserName)} color="avatar-lilac" small />
      </div></header>
      <div className="mobile-brand"><span className="brand-mark"><span /><span /><span /><span /></span><span className="brand-name">mdtc<span>.</span></span></div>
      {storageError && <div className="storage-warning" role="alert">Cloud sync is unavailable. Changes may not reach other devices yet.<button onClick={() => setStorageError(false)} aria-label="Dismiss"><X size={14} /></button></div>}
      <section className="page-content">
        {activeView === 'Overview' && <Overview data={data} currentRsvps={data.rsvps[user.id] ?? []} canManageEvents={workspace.permissions.events} canManageAnnouncements={workspace.permissions.announcements} onNavigate={navigate} onCreateEvent={() => setEventEditor(null)} onCreateAnnouncement={() => setShowAnnouncementForm(true)} onNotice={setNotice} onRsvp={toggleRsvp} />}
        {activeView === 'Events' && <EventsView events={data.events} rsvps={data.rsvps[user.id] ?? []} isAdmin={workspace.permissions.events} onCreate={() => setEventEditor(null)} onEdit={setEventEditor} onDelete={deleteEvent} onRsvp={toggleRsvp} />}
        {activeView === 'Members' && <MembersView members={filteredMembers} search={search} currentUserId={user.id} roles={workspace.roles} canManageAccounts={workspace.permissions.members} canManageRoles={workspace.permissions.manageRoles} onAssignRole={assignDirectoryPosition} onCreate={() => setMemberEditor(null)} onEdit={setMemberEditor} onDelete={deleteMember} />}
        {activeView === 'Announcements' && <AnnouncementsView announcements={data.announcements} isAdmin={workspace.permissions.announcements} onCreate={() => setShowAnnouncementForm(true)} onDelete={deleteAnnouncement} onLike={toggleLike} />}
        {activeView === 'Chat' && <ChatView workspaceId={workspace.id} userId={user.id} isAdmin={workspace.role === 'owner'} />}
        {activeView === 'Finance' && <FinanceView workspaceId={workspace.id} userId={user.id} isFinanceManager={workspace.permissions.financials} members={data.members} />}
        {activeView === 'Settings' && <SettingsView data={data} user={user} workspace={workspace} onCopyInvite={() => { void navigator.clipboard.writeText(workspace.invite_code).then(() => setNotice('Invite code copied.')).catch((error: unknown) => { console.error('Unable to copy the invite code:', error); setNotice('Copy the invite code manually.') }) }} onSave={(clubName, adminName) => { setData((current) => ({ ...current, clubName, adminName })); setNotice('Club settings saved.') }} onSaveRoles={saveRoles} onAssignPosition={assignPosition} onChangePassword={onChangePassword} onExport={exportData} onImport={importData} onReset={resetData} onSignOut={onSignOut} canInstall={Boolean(installPrompt?.prompt)} onInstall={installApp} />}
      </section>
    </main>
    <nav className="mobile-nav" aria-label="Mobile navigation">{[...navigation, { label: 'Settings' as View, icon: Settings }].map(({ label, icon: Icon }) => <button key={label} className={activeView === label ? 'active' : ''} onClick={() => navigate(label)}><Icon size={19} /><span>{label === 'Announcements' ? 'Updates' : label}</span></button>)}</nav>
    {notice && <div className="toast" role="status"><Check size={16} />{notice}<button aria-label="Dismiss notification" onClick={() => setNotice('')}><X size={15} /></button></div>}
    {eventEditor !== undefined && <Modal title={eventEditor ? 'Edit event' : 'Create an event'} subtitle="Give your club something to look forward to." onClose={() => setEventEditor(undefined)}><form className="modal-form" onSubmit={saveEvent}>
      <label>Event name<input name="title" required defaultValue={eventEditor?.title} placeholder="e.g. Creative coding night" /></label>
      <div className="form-row"><label>Date<input name="date" type="date" required defaultValue={eventEditor?.date} /></label><label>Start time<input name="time" type="time" defaultValue={eventEditor?.time ?? '17:30'} /></label></div>
      <div className="form-row"><label>Event type<select name="category" defaultValue={eventEditor?.category ?? 'Meetup'}><option>Meetup</option><option>Outing</option><option>Meal</option><option>Game night</option><option>Other</option></select></label><label>Location<input name="location" defaultValue={eventEditor?.location} placeholder="Venue or meeting spot" /></label></div>
      <button className="button button-primary button-full" type="submit"><Plus size={16} />{eventEditor ? 'Save changes' : 'Add to calendar'}</button>
    </form></Modal>}
    {memberEditor !== undefined && <Modal title={memberEditor ? 'Edit member' : 'Add a member'} subtitle="Keep your club directory up to date." onClose={() => setMemberEditor(undefined)}><form className="modal-form" onSubmit={saveMember}>
      <label>Full name<input name="name" required defaultValue={memberEditor?.name} placeholder="First and last name" /></label>
      <div className="form-row"><label>Role<input name="role" list="club-role-options" defaultValue={memberEditor?.role ?? 'Member'} placeholder="e.g. Member, organizer" /><datalist id="club-role-options">{workspace.roles.map((role) => <option key={role.id} value={role.name} />)}</datalist></label><label>Interests<input name="year" defaultValue={memberEditor?.year} placeholder="e.g. Hiking · Live music" /></label></div>
      <button className="button button-primary button-full" type="submit"><Users size={16} />{memberEditor ? 'Save member' : 'Add to directory'}</button>
    </form></Modal>}
    {showAnnouncementForm && <Modal title="Share an update" subtitle="Let your members know what’s happening." onClose={() => setShowAnnouncementForm(false)}><form className="modal-form" onSubmit={saveAnnouncement}>
      <label>Headline<input name="title" required maxLength={100} placeholder="What’s the big news?" /></label><label>Message<textarea name="body" rows={4} required maxLength={2000} placeholder="Share the details with your club..." /></label>
      <button className="button button-primary button-full" type="submit"><Megaphone size={16} />Publish announcement</button>
    </form></Modal>}
  </div>
}

function PageHeading({ eyebrow, title, description, action }: { eyebrow: string; title: ReactNode; description: string; action?: ReactNode }) {
  return <div className="page-heading"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p>{description}</p></div>{action}</div>
}

function Overview({ data, currentRsvps, canManageEvents, canManageAnnouncements, onNavigate, onCreateEvent, onCreateAnnouncement, onNotice, onRsvp }: { data: ClubData; currentRsvps: string[]; canManageEvents: boolean; canManageAnnouncements: boolean; onNavigate: (view: View) => void; onCreateEvent: () => void; onCreateAnnouncement: () => void; onNotice: (message: string) => void; onRsvp: (id: string) => void }) {
  const activeMembers = data.members.length
  return <>
    <PageHeading eyebrow={new Date().toLocaleDateString('en', { weekday: 'long', month: 'long', day: 'numeric' }).toUpperCase()} title={<>Good afternoon, {data.adminName.split(' ')[0]} <span className="wave">✳</span></>} description="Here’s what your social club has planned." action={canManageEvents && <button className="button button-primary" onClick={onCreateEvent}><Plus size={16} />Plan a get-together</button>} />
    <section className="welcome-banner"><div className="welcome-copy"><span className="banner-kicker"><Sparkles size={14} /> YOUR CLUB, IN MOTION</span><h2>Make time for good company.</h2><p>Plan get-togethers, share your interests, and make great memories with your people.</p><button className="banner-link" onClick={() => onNavigate('Events')}>Explore upcoming events <ArrowUpRight size={15} /></button></div><div className="banner-art" aria-hidden="true"><div className="art-sun" /><div className="art-card art-card-back" /><div className="art-card art-card-front"><span>GOOD TIMES<br />BETTER<br /><i>TOGETHER.</i></span><div className="art-flower">✳</div></div><div className="art-spark">✳</div><div className="art-dot" /></div></section>
    <div className="stats-grid"><StatCard label="Members" value={String(activeMembers)} change="directory" detail="club members" icon={<Users size={17} />} tint="stat-lilac" /><StatCard label="Upcoming events" value={String(data.events.length)} change="scheduled" detail="club events" icon={<CalendarDays size={17} />} tint="stat-peach" /><StatCard label="Announcements" value={String(data.announcements.length)} change="shared" detail="club updates" icon={<Megaphone size={17} />} tint="stat-mint" /><StatCard label="Your RSVPs" value={String(currentRsvps.length)} change="confirmed" detail="events you’re attending" icon={<Check size={17} />} tint="stat-blue" /></div>
    <div className="content-grid">
      <section className="panel events-panel"><div className="panel-heading"><div><span className="section-kicker">COMING UP</span><h2>On the calendar</h2></div><button className="text-button" onClick={() => onNavigate('Events')}>All events <ChevronRight size={15} /></button></div>
        <div className="event-list">{data.events.slice().sort((a, b) => a.date.localeCompare(b.date)).slice(0, 3).map((event) => <EventRow key={event.id} event={event} going={currentRsvps.includes(event.id)} onRsvp={() => onRsvp(event.id)} />)}</div>{canManageEvents && <button className="add-event-row" onClick={onCreateEvent}><span><Plus size={15} /></span>Add an event to the calendar</button>}
      </section>
      <section className="panel activity-panel"><div className="panel-heading"><div><span className="section-kicker">THE LATEST</span><h2>Club updates</h2></div><button className="icon-button more-button" aria-label="View all announcements" onClick={() => onNavigate('Announcements')}><MoreHorizontal size={19} /></button></div>
        <div className="announcement-preview-list">{data.announcements.slice(0, 2).map((announcement) => <AnnouncementPreview key={announcement.id} announcement={announcement} onDelete={() => onNotice('Open announcements to manage posts.')} />)}</div>{canManageAnnouncements && <button className="compose-button" onClick={onCreateAnnouncement}><span className="compose-avatar">{initials(data.adminName)}</span><span>Share something with your club...</span><Image size={16} /></button>}
      </section>
    </div>
    <section className="panel members-panel"><div className="panel-heading"><div><span className="section-kicker">YOUR PEOPLE</span><h2>Meet the members</h2></div><button className="text-button" onClick={() => onNavigate('Members')}>View directory <ChevronRight size={15} /></button></div><div className="member-strip">{data.members.slice(0, 5).map((member) => <div className="member-card" key={member.id}><Avatar initials={member.initials} color={member.color} /><strong>{member.name}</strong><span>{member.role}</span></div>)}</div></section>
    <div className="dashboard-footer"><span>Made for people who bring people together <span className="footer-star">✳</span></span><button onClick={() => onNotice('Use Settings to export a backup or manage club details.')}>Need a hand? <CircleHelp size={14} /></button></div>
  </>
}

function StatCard({ label, value, change, detail, icon, tint }: { label: string; value: string; change: string; detail: string; icon: ReactNode; tint: string }) {
  return <article className="stat-card"><div className="stat-top"><span>{label}</span><span className={`stat-icon ${tint}`}>{icon}</span></div><div className="stat-value">{value}</div><div className="stat-foot"><span className="trend-up"><Check size={13} />{change}</span><span>{detail}</span></div></article>
}

function EventRow({ event, going, onRsvp, onEdit, onDelete }: { event: ClubEvent; going: boolean; onRsvp: () => void; onEdit?: () => void; onDelete?: () => void }) {
  const date = dateLabel(event.date)
  return <article className="event-row"><div className={`date-tile ${event.color}`}><strong>{date.day}</strong><span>{date.month}</span></div><div className="event-details"><div className="event-title-line"><h3>{event.title}</h3><span className={`category-pill ${event.color}`}>{event.category}</span></div><div className="event-meta"><span><Clock3 size={13} />{readableTime(event.time)}</span><span><MapPin size={13} />{event.location}</span></div></div><div className="attendees"><span>{event.attendees} going</span><button className={`rsvp-button${going ? ' attending' : ''}`} onClick={onRsvp}>{going ? 'Going ✓' : 'RSVP'}</button></div>{onEdit && <button className="icon-button row-action" aria-label={`Edit ${event.title}`} onClick={onEdit}><Settings size={15} /></button>}{onDelete && <button className="icon-button row-action danger-action" aria-label={`Delete ${event.title}`} onClick={onDelete}><Trash2 size={15} /></button>}</article>
}

function AnnouncementPreview({ announcement, onDelete }: { announcement: Announcement; onDelete: () => void }) {
  return <article className="announcement-preview"><div className="announcement-head"><Avatar initials={announcement.initials} color={announcement.color} small /><span><strong>{announcement.author}</strong><small>{announcement.date}</small></span><button aria-label={`Announcement options: ${announcement.title}`} className="icon-button announcement-more" onClick={onDelete}><MoreHorizontal size={16} /></button></div><h3>{announcement.title}</h3><p>{announcement.body}</p></article>
}

const chatChannels: { id: ChatChannel; label: string; description: string }[] = [
  { id: 'general', label: 'General', description: 'Anything and everything' },
  { id: 'events', label: 'Events', description: 'Plans, meetups, and outings' },
  { id: 'announcements', label: 'Announcements', description: 'Club news and updates' },
]

function ChatView({ workspaceId, userId, isAdmin }: { workspaceId: string; userId: string; isAdmin: boolean }) {
  const [channel, setChannel] = useState<ChatChannel>('general')
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [draft, setDraft] = useState('')
  const [loading, setLoading] = useState(true)
  const [sending, setSending] = useState(false)
  const [error, setError] = useState('')
  const messageList = useRef<HTMLDivElement>(null)
  const currentChannel = useRef(channel)
  currentChannel.current = channel
  const activeChannel = chatChannels.find((entry) => entry.id === channel) ?? chatChannels[0]

  useEffect(() => {
    if (!supabase) {
      setError('The chat service is not configured.')
      setLoading(false)
      return
    }
    let active = true
    const realtimeMessages = new Map<string, ChatMessage>()
    const deletedMessageIds = new Set<string>()
    setMessages([])
    setDraft('')
    setLoading(true)
    setError('')
    const client = supabase
    const realtime = client.channel(`club-chat-${workspaceId}-${channel}`)
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'club_chat_messages',
        filter: `workspace_id=eq.${workspaceId}`,
      }, (payload) => {
        if (payload.eventType === 'DELETE') {
          const deletedId = payload.old.id
          if (typeof deletedId === 'string') {
            deletedMessageIds.add(deletedId)
            realtimeMessages.delete(deletedId)
            setMessages((current) => current.filter((message) => message.id !== deletedId))
          }
          return
        }
        if (isChatMessage(payload.new) && payload.new.channel === channel) {
          const incomingMessage = payload.new
          realtimeMessages.set(incomingMessage.id, incomingMessage)
          setMessages((current) => {
            const updated = [...current.filter((message) => message.id !== incomingMessage.id), incomingMessage]
            return updated.sort((a, b) => a.created_at.localeCompare(b.created_at)).slice(-100)
          })
        }
      })
      .subscribe((status) => {
        if (!active) return
        if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') {
          setError('Live chat connection failed. Try switching channels or refreshing the page.')
        } else if (status === 'SUBSCRIBED') {
          setError('')
        }
      })

    void (async () => {
      try {
        const { data: rows, error: loadError } = await client.from('club_chat_messages')
          .select('id,workspace_id,user_id,display_name,channel,content,created_at')
          .eq('workspace_id', workspaceId)
          .eq('channel', channel)
          .order('created_at', { ascending: false })
          .limit(100)
        if (loadError) throw loadError
        if (active) {
          const merged = new Map<string, ChatMessage>()
          for (const row of (rows ?? []).filter(isChatMessage).reverse()) merged.set(row.id, row)
          for (const [id, row] of realtimeMessages) merged.set(id, row)
          setMessages([...merged.values()]
            .filter((message) => !deletedMessageIds.has(message.id))
            .sort((a, b) => a.created_at.localeCompare(b.created_at))
            .slice(-100))
        }
      } catch (loadError: unknown) {
        console.error('Unable to load club chat messages:', loadError)
        if (active) setError(errorMessage(loadError, 'Unable to load chat messages.'))
      } finally {
        if (active) setLoading(false)
      }
    })()

    return () => {
      active = false
      void client.removeChannel(realtime)
    }
  }, [workspaceId, channel])

  useEffect(() => {
    const list = messageList.current
    if (list) list.scrollTop = list.scrollHeight
  }, [messages, channel])

  async function sendMessage(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const content = draft.trim()
    if (!content || sending || !supabase) return
    setSending(true)
    setError('')
    try {
      const { data: message, error: sendError } = await supabase
        .from('club_chat_messages')
        .insert({ workspace_id: workspaceId, user_id: userId, channel, content })
        .select('id,workspace_id,user_id,display_name,channel,content,created_at')
        .single()
      if (sendError) throw sendError
      if (!isChatMessage(message)) throw new Error('The chat service returned an invalid message.')
      if (currentChannel.current === message.channel) {
        setMessages((current) => {
          const updated = [...current.filter((entry) => entry.id !== message.id), message]
          return updated.sort((a, b) => a.created_at.localeCompare(b.created_at)).slice(-100)
        })
        setDraft('')
      }
    } catch (sendError) {
      console.error('Unable to send club chat message:', sendError)
      setError(errorMessage(sendError, 'Unable to send your message.'))
    } finally {
      setSending(false)
    }
  }

  async function deleteMessage(message: ChatMessage) {
    if (!supabase || (message.user_id !== userId && !isAdmin)) return
    if (!window.confirm('Delete this message for everyone? This cannot be undone.')) return
    setError('')
    const { error: deleteError } = await supabase
      .from('club_chat_messages')
      .delete()
      .eq('workspace_id', workspaceId)
      .eq('id', message.id)
    if (deleteError) {
      console.error('Unable to delete club chat message:', deleteError)
      setError(errorMessage(deleteError, 'Unable to delete this message.'))
    } else {
      setMessages((current) => current.filter((entry) => entry.id !== message.id))
    }
  }

  return <>
    <PageHeading eyebrow="STAY IN TOUCH" title="Club chat" description="Catch up with everyone in your club." />
    <section className="panel chat-panel">
      <nav className="chat-channel-list" aria-label="Chat channels">
        {chatChannels.map((entry) => <button key={entry.id} type="button" className={`chat-channel${channel === entry.id ? ' active' : ''}`} aria-pressed={channel === entry.id} onClick={() => setChannel(entry.id)}>
          <span className="chat-channel-icon"><MessageSquare size={16} /></span><span><strong>{entry.label}</strong><small>{entry.description}</small></span>
        </button>)}
      </nav>
      <div className="chat-conversation">
        <header className="chat-conversation-heading"><div><h2>{activeChannel.label}</h2><p>{activeChannel.description}</p></div><span>Messages stay in your club</span></header>
        {error && <p className="auth-error chat-error" role="alert">{error}</p>}
        <div className="chat-message-list" ref={messageList} aria-live="polite">
          {loading ? <p className="chat-empty">Loading messages…</p> : messages.length === 0
            ? <p className="chat-empty">No messages yet. Start the conversation!</p>
            : messages.map((message) => {
              const mine = message.user_id === userId
              const canDelete = mine || isAdmin
              return <article className={`chat-message${mine ? ' chat-message-mine' : ''}`} key={message.id}>
                <Avatar initials={initials(message.display_name)} color={mine ? 'avatar-lilac' : 'avatar-blue'} small />
                <div className="chat-message-content"><div className="chat-message-meta"><strong>{message.display_name}</strong><time dateTime={message.created_at}>{new Date(message.created_at).toLocaleString(undefined, { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })}</time></div><p>{message.content}</p></div>
                {canDelete && <button className="icon-button chat-delete-button" type="button" aria-label={`Delete message from ${message.display_name}`} onClick={() => void deleteMessage(message)}><Trash2 size={14} /></button>}
              </article>
            })}
        </div>
        <form className="chat-composer" onSubmit={(event) => void sendMessage(event)}>
          <label className="sr-only" htmlFor="chat-message-input">Message {activeChannel.label}</label>
          <textarea id="chat-message-input" value={draft} maxLength={2000} rows={2} placeholder={`Message ${activeChannel.label.toLowerCase()}…`} onChange={(event) => setDraft(event.target.value)} onKeyDown={(event) => {
            if (event.key === 'Enter' && !event.shiftKey) {
              event.preventDefault()
              event.currentTarget.form?.requestSubmit()
            }
          }} />
          <button className="button button-primary" type="submit" disabled={sending || !draft.trim()}>{sending ? 'Sending…' : 'Send'}<Send size={15} /></button>
          <small>Enter to send · Shift+Enter for a new line</small>
        </form>
      </div>
    </section>
  </>
}

function EventsView({ events, rsvps, isAdmin, onCreate, onEdit, onDelete, onRsvp }: { events: ClubEvent[]; rsvps: string[]; isAdmin: boolean; onCreate: () => void; onEdit: (event: ClubEvent) => void; onDelete: (event: ClubEvent) => void; onRsvp: (id: string) => void }) {
  const sortedEvents = events.slice().sort((a, b) => a.date.localeCompare(b.date))
  return <><PageHeading eyebrow="MAKE A DATE" title="Events" description="A little something to bring us all together." action={isAdmin && <button className="button button-primary" onClick={onCreate}><Plus size={16} />Create event</button>} /><div className="view-toolbar"><div className="view-filter"><CalendarDays size={16} /> All events</div><span>{events.length} events scheduled</span></div><section className="panel full-events-panel">{sortedEvents.length ? sortedEvents.map((event) => <EventRow key={event.id} event={event} going={rsvps.includes(event.id)} onRsvp={() => onRsvp(event.id)} onEdit={isAdmin ? () => onEdit(event) : undefined} onDelete={isAdmin ? () => onDelete(event) : undefined} />) : <EmptyState title="No events on the calendar" text="Your club admin can add the first get-together." />}</section></>
}

function MembersView({ members, search, currentUserId, roles, canManageAccounts, canManageRoles, onAssignRole, onCreate, onEdit, onDelete }: { members: Member[]; search: string; currentUserId: string; roles: ClubRole[]; canManageAccounts: boolean; canManageRoles: boolean; onAssignRole: (member: Member, roleId: string) => void; onCreate: () => void; onEdit: (member: Member) => void; onDelete: (member: Member) => void }) {
  return <><PageHeading eyebrow="YOUR SOCIAL CIRCLE" title="Members" description="Get to know the people who make your club special." action={canManageAccounts && <button className="button button-primary" onClick={onCreate}><Plus size={16} />Add member</button>} /><div className="member-summary"><div className="member-summary-icon"><Users size={19} /></div><div><strong>{members.length} {search ? 'matching' : 'club'} members</strong><span>Manage your club directory</span></div><div className="summary-avatars">{members.slice(0, 3).map((member) => <Avatar key={member.id} initials={member.initials} color={member.color} small />)}{members.length > 3 && <span>+{members.length - 3}</span>}</div></div><section className="panel directory-panel"><div className="directory-heading"><div><span className="section-kicker">MEMBER DIRECTORY</span><h2>{search ? `${members.length} search results` : 'All members'}</h2></div><span className="directory-sort">Alphabetical</span></div><div className="directory-list">{members.length ? members.map((member) => <div className="directory-row" key={member.id}><Avatar initials={member.initials} color={member.color} /><div className="directory-person"><strong>{member.name}</strong><span>{member.year}</span></div>{canManageRoles && member.userId ? <label className="position-select-label"><span className="sr-only">Position for {member.name}</span><select aria-label={`Position for ${member.name}`} value={member.roleId ?? ''} onChange={(event) => onAssignRole(member, event.target.value)}><option value="">No position</option>{roles.map((role) => <option key={role.id} value={role.id}>{role.name}</option>)}</select></label> : <span className="role-pill">{member.role}</span>}<span className="joined-date">Joined {member.joined}</span>{canManageAccounts && member.userId && !member.isOwner && member.userId !== currentUserId && <button className="icon-button danger-action" aria-label={`Remove ${member.name}`} onClick={() => onDelete(member)}><Trash2 size={15} /></button>}{canManageAccounts && !member.userId && <><button className="icon-button danger-action" aria-label={`Remove ${member.name}`} onClick={() => onDelete(member)}><Trash2 size={15} /></button><button className="icon-button" aria-label={`Edit ${member.name}`} onClick={() => onEdit(member)}><Settings size={15} /></button></>}</div>) : <EmptyState title={search ? 'No members found' : 'Your directory is empty'} text={search ? 'Try another name, role, or interest.' : 'Add your first member to get started.'} />}</div></section></>
}

function AnnouncementsView({ announcements, isAdmin, onCreate, onDelete, onLike }: { announcements: Announcement[]; isAdmin: boolean; onCreate: () => void; onDelete: (item: Announcement) => void; onLike: (id: string) => void }) {
  return <><PageHeading eyebrow="A NOTE TO THE CLUB" title="Announcements" description="The latest from your club, all in one place." action={isAdmin && <button className="button button-primary" onClick={onCreate}><Plus size={16} />Share an update</button>} /><div className="announcement-feed">{announcements.length ? announcements.map((announcement) => <article className="panel feed-card" key={announcement.id}><div className="announcement-head"><Avatar initials={announcement.initials} color={announcement.color} small /><span><strong>{announcement.author}</strong><small>{announcement.date}</small></span>{isAdmin && <button className="icon-button announcement-more danger-action" aria-label={`Delete ${announcement.title}`} onClick={() => onDelete(announcement)}><Trash2 size={15} /></button>}</div><h2>{announcement.title}</h2><p>{announcement.body}</p>{isAdmin && <button className={`reaction-button${announcement.liked ? ' reacted' : ''}`} aria-pressed={Boolean(announcement.liked)} onClick={() => onLike(announcement.id)}><Heart size={14} fill={announcement.liked ? 'currentColor' : 'none'} /> Appreciate · {announcement.likes}</button>}</article>) : <EmptyState title="No announcements yet" text="Your club admin can share the first update." />}{isAdmin && <button className="compose-button feed-compose" onClick={onCreate}><span className="compose-avatar">MC</span><span>Share something with your club...</span><Image size={16} /></button>}</div></>
}

function SettingsView({ data, user, workspace, onCopyInvite, onSave, onSaveRoles, onAssignPosition, onChangePassword, onExport, onImport, onReset, onSignOut, canInstall, onInstall }: { data: ClubData; user: User; workspace: Workspace; onCopyInvite: () => void; onSave: (clubName: string, adminName: string) => void; onSaveRoles: (roles: ClubRole[]) => Promise<void>; onAssignPosition: (userId: string, roleId: string) => Promise<void>; onChangePassword: (currentPassword: string, nextPassword: string) => Promise<void>; onExport: () => void; onImport: (file: File | undefined) => void; onReset: () => void; onSignOut: () => void; canInstall: boolean; onInstall: () => void }) {
  const [passwordError, setPasswordError] = useState('')
  const [passwordChanged, setPasswordChanged] = useState(false)
  const [passwordBusy, setPasswordBusy] = useState(false)
  const canRestoreData = workspace.permissions.events && workspace.permissions.announcements
    && workspace.permissions.members && workspace.permissions.settings

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const form = new FormData(event.currentTarget)
    const club = String(form.get('clubName')).trim()
    const admin = String(form.get('adminName')).trim()
    if (club && admin) onSave(club, admin)
  }
  async function submitPassword(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    const formElement = event.currentTarget
    setPasswordError('')
    setPasswordChanged(false)
    const form = new FormData(formElement)
    const currentPassword = String(form.get('currentPassword') ?? '')
    const nextPassword = String(form.get('newPassword') ?? '')
    const confirmPassword = String(form.get('confirmPassword') ?? '')
    if (nextPassword.length < 8) {
      setPasswordError('Your new password must be at least 8 characters.')
      return
    }
    if (nextPassword !== confirmPassword) {
      setPasswordError('The new passwords do not match.')
      return
    }
    if (currentPassword === nextPassword) {
      setPasswordError('Choose a new password that differs from your current password.')
      return
    }
    setPasswordBusy(true)
    try {
      await onChangePassword(currentPassword, nextPassword)
      formElement.reset()
      setPasswordChanged(true)
    } catch (error) {
      setPasswordError(error instanceof Error ? error.message : 'Unable to change your password.')
    } finally {
      setPasswordBusy(false)
    }
  }
  return <>
    <PageHeading eyebrow="MAKE IT YOURS" title="Settings" description="Manage your shared club and account." />
    {user.email?.trim().toLowerCase() === superadminEmail && <SuperadminAccountsPanel currentUserId={user.id} workspaceId={workspace.id} roles={workspace.roles} onAssignPosition={onAssignPosition} />}
    {workspace.permissions.manageRoles && <RoleManagementPanel roles={workspace.roles} onSave={onSaveRoles} />}
    <div className="settings-grid">
      {workspace.permissions.settings && <section className="panel settings-panel"><div className="settings-panel-heading"><span className="settings-icon"><Settings size={18} /></span><div><h2>Club profile</h2><p>Updates sync for everyone in your club.</p></div></div><form className="modal-form" key={`${data.clubName}-${data.adminName}`} onSubmit={submit}><label>Club name<input name="clubName" required maxLength={60} defaultValue={data.clubName} /></label><label>Administrator name<input name="adminName" required maxLength={60} defaultValue={data.adminName} /></label><button className="button button-primary" type="submit">Save details</button></form></section>}
      <section className="panel settings-panel"><div className="settings-panel-heading"><span className="settings-icon stat-lilac"><Users size={18} /></span><div><h2>Account</h2><p>Signed in as {user.user_metadata.display_name ?? user.email} · {user.email}</p></div></div><p className="install-help">Secure account access is available on any device with an internet connection.</p><form className="modal-form password-change-form" onSubmit={submitPassword}><h3>Change password</h3><label>Current password<input name="currentPassword" type="password" autoComplete="current-password" required maxLength={128} /></label><label>New password<input name="newPassword" type="password" autoComplete="new-password" required minLength={8} maxLength={128} /></label><label>Confirm new password<input name="confirmPassword" type="password" autoComplete="new-password" required minLength={8} maxLength={128} /></label>{passwordError && <p className="auth-error" role="alert">{passwordError}</p>}{passwordChanged && <p className="password-success" role="status">Password changed. Use your new password next time you sign in.</p>}<button className="button button-primary" type="submit" disabled={passwordBusy}>{passwordBusy ? 'Updating password…' : 'Update password'}</button></form><button className="button button-danger account-signout" onClick={onSignOut}><LogOut size={15} />Sign out</button></section>
      <section className="panel settings-panel"><div className="settings-panel-heading"><span className="settings-icon stat-blue"><Users size={18} /></span><div><h2>Invite your members</h2><p>Share this code with people you trust. Anyone with it can join your club.</p></div></div><div className="invite-code-row"><code>{workspace.invite_code}</code><button className="button button-secondary" onClick={onCopyInvite}>Copy invite code</button></div></section>
      <section className="panel settings-panel"><div className="settings-panel-heading"><span className="settings-icon stat-mint"><Download size={18} /></span><div><h2>Your data</h2><p>Shared club data is stored securely in your Supabase project.</p></div></div><div className="settings-actions"><button className="button button-secondary" onClick={onExport}><Download size={15} />Download a backup</button>{canRestoreData && <label className="button button-secondary import-button"><Download size={15} />Restore from backup<input type="file" accept="application/json,.json" onChange={(event) => { onImport(event.currentTarget.files?.[0]); event.currentTarget.value = '' }} /></label>}{canRestoreData && <button className="button button-danger" onClick={onReset}><Trash2 size={15} />Clear shared workspace</button>}</div></section>
      <section className="panel settings-panel"><div className="settings-panel-heading"><span className="settings-icon stat-peach"><Sparkles size={18} /></span><div><h2>Mobile app</h2><p>Open the hosted club on any device, or install it for an app-like experience.</p></div></div>{canInstall ? <button className="button button-primary" onClick={onInstall}>Install app</button> : <p className="install-help">On mobile, use your browser’s Share or menu button, then choose “Add to Home Screen”.</p>}</section>
    </div>
  </>
}

function RoleManagementPanel({ roles, onSave }: { roles: ClubRole[]; onSave: (roles: ClubRole[]) => Promise<void> }) {
  const [draft, setDraft] = useState(roles)
  const [error, setError] = useState('')
  const [saving, setSaving] = useState(false)
  useEffect(() => setDraft(roles), [roles])

  function updateRole(roleId: string, update: (role: ClubRole) => ClubRole) {
    setDraft((current) => current.map((role) => role.id === roleId ? update(role) : role))
  }

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setError('')
    const normalizedNames = draft.map((role) => role.name.trim().toLocaleLowerCase())
    if (draft.some((role) => !role.name.trim() || role.name.trim().length > 50)) {
      setError('Each role needs a name between 1 and 50 characters.')
      return
    }
    if (new Set(normalizedNames).size !== normalizedNames.length) {
      setError('Role names must be unique.')
      return
    }
    setSaving(true)
    try {
      await onSave(draft.map((role) => ({ ...role, name: role.name.trim() })))
    } catch (saveError) {
      console.error('Unable to save club roles:', saveError)
      setError(errorMessage(saveError, 'Unable to save club roles.'))
    } finally {
      setSaving(false)
    }
  }

  return <section className="panel settings-panel role-management-panel">
    <div className="settings-panel-heading"><span className="settings-icon stat-peach"><Users size={18} /></span><div><h2>Club roles & permissions</h2><p>Create position labels and choose what each position can manage. Club admins always retain full access.</p></div></div>
    {error && <p className="auth-error" role="alert">{error}</p>}
    <form className="role-management-form" onSubmit={submit}>
      {draft.map((role) => <fieldset className="club-role-editor" key={role.id}>
        <div className="club-role-editor-heading"><label>Role name<input value={role.name} maxLength={50} onChange={(event) => updateRole(role.id, (current) => ({ ...current, name: event.target.value }))} /></label><button className="button button-danger" type="button" onClick={() => setDraft((current) => current.filter((entry) => entry.id !== role.id))}>Remove</button></div>
        <div className="role-permission-list">{permissionKeys.map((permission) => <label key={permission}><input type="checkbox" checked={role.permissions[permission]} onChange={(event) => updateRole(role.id, (current) => ({ ...current, permissions: { ...current.permissions, [permission]: event.target.checked } }))} /><span>{permissionLabels[permission]}</span></label>)}</div>
      </fieldset>)}
      <p className="install-help">Members can view and request finance entries. The Financials permission grants access to approvals, budgets, and dues management.</p>
      <div className="role-management-actions"><button className="button button-secondary" type="button" onClick={() => setDraft((current) => [...current, { id: crypto.randomUUID(), name: '', permissions: { ...noPermissions } }])}><Plus size={15} />Add role</button><button className="button button-primary" type="submit" disabled={saving}>{saving ? 'Saving roles…' : 'Save roles'}</button></div>
    </form>
  </section>
}

function SuperadminAccountsPanel({ currentUserId, workspaceId, roles, onAssignPosition }: { currentUserId: string; workspaceId: string; roles: ClubRole[]; onAssignPosition: (userId: string, roleId: string) => Promise<void> }) {
  const [accounts, setAccounts] = useState<ManagedAccount[]>([])
  const [search, setSearch] = useState('')
  const [loading, setLoading] = useState(true)
  const [busyId, setBusyId] = useState('')
  const [error, setError] = useState('')
  const [message, setMessage] = useState('')

  async function loadAccounts() {
    setLoading(true)
    setError('')
    try {
      const response = await invokeAdminAccounts('list')
      if (!supabase) throw new Error('The account-management service is not configured.')
      const { data: positions, error: positionsError } = await supabase
        .from('club_members')
        .select('user_id,position_role_id')
        .eq('workspace_id', workspaceId)
      if (positionsError) throw positionsError
      const positionByUserId = new Map((positions ?? []).map((membership) => [membership.user_id, membership.position_role_id]))
      setAccounts((response.accounts ?? []).map((account) => ({
        ...account,
        positionRoleId: positionByUserId.get(account.id) ?? null,
      })))
    } catch (loadError) {
      console.error('Unable to load superadmin account list:', loadError)
      setError(loadError instanceof Error ? loadError.message : 'Unable to load club accounts.')
    } finally {
      setLoading(false)
      setBusyId('')
    }
  }

  useEffect(() => {
    void loadAccounts()
  }, [workspaceId])

  async function runAction(userId: string, action: string, details: Record<string, unknown> = {}) {
    setBusyId(userId)
    setError('')
    setMessage('')
    try {
      const response = await invokeAdminAccounts(action, { userId, ...details })
      setMessage(response.message ?? 'Account updated.')
      if (action !== 'send-reset' && action !== 'set-position-role') await loadAccounts()
      else setBusyId('')
    } catch (actionError) {
      console.error(`Superadmin account action failed (${action}):`, actionError)
      setError(actionError instanceof Error ? actionError.message : 'Unable to update this account.')
      setBusyId('')
    }
  }

  async function saveAccountPosition(userId: string, roleId: string) {
    setBusyId(userId)
    setError('')
    setMessage('')
    try {
      await onAssignPosition(userId, roleId)
      setMessage('Club position updated.')
      await loadAccounts()
    } catch (actionError) {
      console.error('Unable to save club position:', actionError)
      setError(actionError instanceof Error ? actionError.message : 'Unable to update this account position.')
      setBusyId('')
    }
  }

  const filteredAccounts = accounts.filter((account) =>
    `${account.name} ${account.email}`.toLowerCase().includes(search.trim().toLowerCase()))

  return <section className="panel superadmin-panel">
    <div className="settings-panel-heading">
      <span className="settings-icon stat-peach"><Users size={18} /></span>
      <div><h2>Superadmin · account management</h2><p>Manage club roles, membership status, and account access for Manukau Digital Tech Collective. Pending or inactive members cannot access the club. Confirm email only after verifying that the person controls the address. Passwords are never visible; reset links are sent by email.</p></div>
    </div>
    {error && <p className="auth-error" role="alert">{error}</p>}
    {message && <p className="password-success" role="status">{message}</p>}
    <div className="superadmin-toolbar">
      <label>Search club accounts<input type="search" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Name or email" /></label>
      <button className="button button-secondary" type="button" onClick={() => void loadAccounts()} disabled={loading}>{loading ? 'Loading…' : 'Refresh accounts'}</button>
    </div>
    {loading ? <p className="install-help">Loading club accounts…</p> : filteredAccounts.length === 0
      ? <p className="install-help">{accounts.length ? 'No accounts match your search.' : 'No accounts are linked to this club yet.'}</p>
      : <div className="superadmin-account-list">{filteredAccounts.map((account) => {
        const isSelf = account.id === currentUserId
        const isBusy = busyId === account.id
        return <article className="superadmin-account" key={account.id}>
          <div className="superadmin-account-heading">
            <div><strong>{account.name}</strong><span>{account.email}</span><small>{account.emailConfirmed ? 'Email confirmed' : 'Email not confirmed'} · {account.membershipStatus} membership · Joined {new Date(account.createdAt).toLocaleDateString()}</small></div>
            <span className={`role-pill${account.banned ? ' account-suspended' : ''}`}>{account.banned ? 'Suspended' : account.role === 'owner' ? 'Club admin' : 'Member'}</span>
          </div>
          <form className="superadmin-profile-form" key={`${account.id}-${account.email}-${account.name}`} onSubmit={(event) => {
            event.preventDefault()
            const form = new FormData(event.currentTarget)
            void runAction(account.id, 'update-profile', {
              name: String(form.get('displayName') ?? ''),
              email: String(form.get('email') ?? ''),
            })
          }}>
            <label>Display name<input name="displayName" required maxLength={80} defaultValue={account.name} disabled={isSelf || isBusy} /></label>
            <label>Email address<input name="email" type="email" required maxLength={254} defaultValue={account.email} disabled={isSelf || isBusy} /></label>
            <button className="button button-secondary" type="submit" disabled={isSelf || isBusy}>{isBusy ? 'Saving…' : 'Save details'}</button>
          </form>
          <form className="superadmin-role-form" onSubmit={(event) => {
            event.preventDefault()
            const form = new FormData(event.currentTarget)
            void runAction(account.id, 'set-role', { role: String(form.get('role')) })
          }}>
            <label>Club role<select name="role" defaultValue={account.role} disabled={isSelf || isBusy}><option value="member">Member</option><option value="owner">Club admin</option></select></label>
            <button className="button button-secondary" type="submit" disabled={isSelf || isBusy}>Save role</button>
          </form>
          <div className="superadmin-role-form">
            <label>Club position<select name="roleId" value={account.positionRoleId ?? ''} disabled={isBusy} onChange={(event) => void saveAccountPosition(account.id, event.target.value)}><option value="">No position</option>{roles.map((role) => <option key={role.id} value={role.id}>{role.name}</option>)}</select></label>
            {isBusy && <small role="status">Saving position…</small>}
          </div>
          <form className="superadmin-role-form" onSubmit={(event) => {
            event.preventDefault()
            const form = new FormData(event.currentTarget)
            void runAction(account.id, 'set-membership-status', { status: String(form.get('status')) })
          }}>
            <label>Membership status<select name="status" defaultValue={account.membershipStatus} disabled={isSelf || isBusy}><option value="pending">Pending approval</option><option value="active">Active</option><option value="inactive">Inactive</option></select></label>
            <button className="button button-secondary" type="submit" disabled={isSelf || isBusy}>Save status</button>
          </form>
          <div className="superadmin-actions">
            {!account.emailConfirmed && <button className="button button-secondary" type="button" disabled={isSelf || isBusy} onClick={() => {
              if (window.confirm(`Confirm ${account.email} only if you have independently verified that this person controls that email address.`)) {
                void runAction(account.id, 'confirm-email')
              }
            }}>Confirm email</button>}
            <button className="button button-secondary" type="button" disabled={isSelf || isBusy} onClick={() => void runAction(account.id, 'send-reset')}>Send password reset</button>
            <button className="button button-secondary" type="button" disabled={isSelf || isBusy} onClick={() => {
              if (window.confirm(`${account.banned ? 'Reactivate' : 'Suspend'} ${account.email}?`)) {
                void runAction(account.id, 'set-ban', { banned: !account.banned })
              }
            }}>{account.banned ? 'Reactivate account' : 'Suspend account'}</button>
            <button className="button button-danger" type="button" disabled={isSelf || isBusy} onClick={() => {
              if (window.confirm(`Permanently delete ${account.email}? This cannot be undone.`)) {
                void runAction(account.id, 'delete')
              }
            }}>Delete account</button>
          </div>
        </article>
      })}</div>}
  </section>
}

function EmptyState({ title, text }: { title: string; text: string }) {
  return <div className="empty-state"><span><CalendarDays size={22} /></span><strong>{title}</strong><p>{text}</p></div>
}

function Modal({ title, subtitle, onClose, children }: { title: string; subtitle: string; onClose: () => void; children: ReactNode }) {
  return <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose() }}><section className="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title"><button className="modal-close icon-button" onClick={onClose} aria-label="Close"><X size={18} /></button><span className="modal-mark"><Sparkles size={18} /></span><h2 id="modal-title">{title}</h2><p className="modal-subtitle">{subtitle}</p>{children}</section></div>
}

export default App
