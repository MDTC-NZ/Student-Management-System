import { useCallback, useEffect, useMemo, useState, type FormEvent } from 'react'
import {
  ArrowDownLeft, ArrowUpRight, Check, Download, Plus, ReceiptText, Trash2,
} from 'lucide-react'
import { supabase } from './lib/supabase'

type FinanceTab = 'overview' | 'transactions' | 'budgets' | 'dues'
type TransactionType = 'income' | 'expense'
type TransactionStatus = 'pending' | 'approved' | 'rejected'
type FinanceTransaction = {
  id: string
  workspace_id: string
  submitted_by: string | null
  submitter_name: string
  type: TransactionType
  category: string
  description: string
  amount_cents: number
  transaction_date: string
  status: TransactionStatus
  receipt_path: string | null
  created_at: string
}
type FinanceBudget = {
  id: string
  workspace_id: string
  category: string
  period: string
  amount_cents: number
}
type MemberDues = {
  id: string
  workspace_id: string
  member_user_id: string | null
  member_name: string
  period: string
  amount_cents: number
  status: 'due' | 'payment_reported' | 'paid'
}
type FinanceMember = { userId?: string; name: string }

const categories = [
  { value: 'membership-dues', label: 'Membership dues' },
  { value: 'fundraising', label: 'Fundraising' },
  { value: 'event-costs', label: 'Event costs' },
  { value: 'equipment', label: 'Equipment' },
  { value: 'food-and-drink', label: 'Food and drink' },
  { value: 'transport', label: 'Transport' },
  { value: 'other', label: 'Other' },
]

const tabs: { id: FinanceTab; label: string }[] = [
  { id: 'overview', label: 'Overview' },
  { id: 'transactions', label: 'Transactions' },
  { id: 'budgets', label: 'Budgets' },
  { id: 'dues', label: 'Member dues' },
]

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null
}

function isFinanceTransaction(value: unknown): value is FinanceTransaction {
  return isRecord(value)
    && typeof value.id === 'string'
    && typeof value.workspace_id === 'string'
    && (typeof value.submitted_by === 'string' || value.submitted_by === null)
    && typeof value.submitter_name === 'string'
    && (value.type === 'income' || value.type === 'expense')
    && typeof value.category === 'string'
    && typeof value.description === 'string'
    && typeof value.amount_cents === 'number'
    && Number.isSafeInteger(value.amount_cents)
    && typeof value.transaction_date === 'string'
    && (value.status === 'pending' || value.status === 'approved' || value.status === 'rejected')
    && (typeof value.receipt_path === 'string' || value.receipt_path === null)
    && typeof value.created_at === 'string'
}

function isFinanceBudget(value: unknown): value is FinanceBudget {
  return isRecord(value)
    && typeof value.id === 'string'
    && typeof value.workspace_id === 'string'
    && typeof value.category === 'string'
    && typeof value.period === 'string'
    && typeof value.amount_cents === 'number'
    && Number.isSafeInteger(value.amount_cents)
}

function isMemberDues(value: unknown): value is MemberDues {
  return isRecord(value)
    && typeof value.id === 'string'
    && typeof value.workspace_id === 'string'
    && (typeof value.member_user_id === 'string' || value.member_user_id === null)
    && typeof value.member_name === 'string'
    && typeof value.period === 'string'
    && typeof value.amount_cents === 'number'
    && Number.isSafeInteger(value.amount_cents)
    && (value.status === 'due' || value.status === 'payment_reported' || value.status === 'paid')
}

function centsFromForm(value: FormDataEntryValue | null) {
  const amount = Number(String(value ?? '').trim())
  if (!Number.isFinite(amount) || amount <= 0 || amount > 1000000000) return null
  const cents = Math.round(amount * 100)
  return Number.isSafeInteger(cents) && cents > 0 ? cents : null
}

function money(cents: number) {
  return new Intl.NumberFormat('en-NZ', { style: 'currency', currency: 'NZD' }).format(cents / 100)
}

function currentMonth() {
  const today = new Date()
  return `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}`
}

function currentDate() {
  const today = new Date()
  return `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`
}

function monthStart(month: string) {
  return /^\d{4}-(0[1-9]|1[0-2])$/.test(month) ? `${month}-01` : ''
}

function csvCell(value: string) {
  return `"${value.replace(/"/g, '""')}"`
}

function downloadCsv(rows: FinanceTransaction[]) {
  const headings = ['Date', 'Type', 'Category', 'Description', 'Amount (NZD)', 'Status', 'Submitted by', 'Receipt']
  const lines = rows.map((row) => [
    row.transaction_date,
    row.type,
    categories.find((entry) => entry.value === row.category)?.label ?? row.category,
    row.description,
    (row.amount_cents / 100).toFixed(2),
    row.status,
    row.submitter_name,
    row.receipt_path ? 'Attached' : '',
  ].map(csvCell).join(','))
  const blob = new Blob([[headings.map(csvCell).join(','), ...lines].join('\r\n')], { type: 'text/csv;charset=utf-8' })
  const url = URL.createObjectURL(blob)
  const link = document.createElement('a')
  link.href = url
  link.download = 'club-finances.csv'
  link.click()
  URL.revokeObjectURL(url)
}

export function FinanceView({ workspaceId, userId, isFinanceManager, members }: {
  workspaceId: string
  userId: string
  isFinanceManager: boolean
  members: FinanceMember[]
}) {
  const [tab, setTab] = useState<FinanceTab>('overview')
  const [transactions, setTransactions] = useState<FinanceTransaction[]>([])
  const [budgets, setBudgets] = useState<FinanceBudget[]>([])
  const [dues, setDues] = useState<MemberDues[]>([])
  const [month, setMonth] = useState(currentMonth)
  const [loading, setLoading] = useState(true)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const [transactionEditor, setTransactionEditor] = useState<FinanceTransaction | null | undefined>(undefined)
  const [showBudgetForm, setShowBudgetForm] = useState(false)
  const [showDuesForm, setShowDuesForm] = useState(false)

  const refresh = useCallback(async () => {
    if (!supabase) {
      setError('The finance service is not configured.')
      setLoading(false)
      return
    }
    setError('')
    try {
      const [transactionResult, budgetResult, duesResult] = await Promise.all([
        supabase.from('club_finance_transactions')
          .select('id,workspace_id,submitted_by,submitter_name,type,category,description,amount_cents,transaction_date,status,receipt_path,created_at')
          .eq('workspace_id', workspaceId)
          .order('transaction_date', { ascending: false })
          .order('created_at', { ascending: false }),
        supabase.from('club_finance_budgets')
          .select('id,workspace_id,category,period,amount_cents')
          .eq('workspace_id', workspaceId)
          .order('period', { ascending: false }),
        supabase.from('club_member_dues')
          .select('id,workspace_id,member_user_id,member_name,period,amount_cents,status')
          .eq('workspace_id', workspaceId)
          .order('period', { ascending: false })
          .order('member_name', { ascending: true }),
      ])
      const failed = transactionResult.error ?? budgetResult.error ?? duesResult.error
      if (failed) {
        console.error('Unable to load club finances:', failed)
        setError(failed.message)
      } else {
        setTransactions((transactionResult.data ?? []).filter(isFinanceTransaction))
        setBudgets((budgetResult.data ?? []).filter(isFinanceBudget))
        setDues((duesResult.data ?? []).filter(isMemberDues))
      }
    } catch (loadError: unknown) {
      console.error('Unable to load club finances:', loadError)
      setError(loadError instanceof Error ? loadError.message : 'Unable to load club finance records.')
    } finally {
      setLoading(false)
    }
  }, [workspaceId])

  useEffect(() => {
    void refresh()
    if (!supabase) return
    const client = supabase
    const realtime = client.channel(`club-finances-${workspaceId}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'club_finance_transactions', filter: `workspace_id=eq.${workspaceId}` }, () => { void refresh() })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'club_finance_budgets', filter: `workspace_id=eq.${workspaceId}` }, () => { void refresh() })
      .on('postgres_changes', { event: '*', schema: 'public', table: 'club_member_dues', filter: `workspace_id=eq.${workspaceId}` }, () => { void refresh() })
      .subscribe((status) => {
        if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') {
          console.error('Realtime finance updates failed:', status)
          setError('Live finance updates are unavailable. Refresh the page to see the latest changes.')
        }
      })
    return () => { void client.removeChannel(realtime) }
  }, [workspaceId, refresh])

  const postedTransactions = useMemo(() => transactions.filter((entry) => entry.status === 'approved'), [transactions])
  const balance = postedTransactions.reduce((sum, entry) => sum + (entry.type === 'income' ? entry.amount_cents : -entry.amount_cents), 0)
  const currentDues = dues.filter((entry) => entry.period.slice(0, 7) === month)
  const transactionMonth = postedTransactions.filter((entry) => entry.transaction_date.slice(0, 7) === month)
  const incomeThisMonth = transactionMonth.filter((entry) => entry.type === 'income').reduce((sum, entry) => sum + entry.amount_cents, 0)
  const expensesThisMonth = transactionMonth.filter((entry) => entry.type === 'expense').reduce((sum, entry) => sum + entry.amount_cents, 0)
  const currentBudgets = budgets.filter((entry) => entry.period.slice(0, 7) === month)
  const pendingCount = transactions.filter((entry) => entry.status === 'pending').length
  const activeMemberIds = useMemo(() => members.flatMap((member) => member.userId ? [member.userId] : []), [members])

  function toast(message: string) {
    setNotice(message)
    window.setTimeout(() => setNotice(''), 3500)
  }

  async function submitTransaction(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!supabase || busy) return
    const form = event.currentTarget
    const fields = new FormData(form)
    const amountCents = centsFromForm(fields.get('amount'))
    const description = String(fields.get('description') ?? '').trim()
    const date = String(fields.get('transaction_date') ?? '')
    const category = String(fields.get('category') ?? '')
    const type = fields.get('type') === 'income' ? 'income' : 'expense'
    const selectedReceipt = fields.get('receipt')
    const receipt = selectedReceipt instanceof File ? selectedReceipt : null
    if (!amountCents || !description || description.length > 160 || !/^\d{4}-\d{2}-\d{2}$/.test(date)
      || !categories.some((entry) => entry.value === category)) {
      setError('Check the transaction details and amount, then try again.')
      return
    }
    if (receipt && (receipt.size > 10 * 1024 * 1024 || (receipt.size > 0 && !['application/pdf', 'image/jpeg', 'image/png'].includes(receipt.type)))) {
      setError('Receipts must be a PDF, JPG, or PNG no larger than 10 MB.')
      return
    }
    setBusy(true)
    setError('')
    try {
      const editing = transactionEditor && transactionEditor !== null
      let saved: FinanceTransaction
      if (editing) {
        const { data, error: updateError } = await supabase.from('club_finance_transactions')
          .update({ type, category, description, amount_cents: amountCents, transaction_date: date })
          .eq('workspace_id', workspaceId)
          .eq('id', transactionEditor.id)
          .select('id,workspace_id,submitted_by,submitter_name,type,category,description,amount_cents,transaction_date,status,receipt_path,created_at')
          .single()
        if (updateError) throw updateError
        if (!isFinanceTransaction(data)) throw new Error('The finance service returned an invalid transaction.')
        saved = data
      } else {
        const status = isFinanceManager && fields.get('status') === 'approved' ? 'approved' : 'pending'
        const { data, error: insertError } = await supabase.from('club_finance_transactions')
          .insert({ workspace_id: workspaceId, type, category, description, amount_cents: amountCents, transaction_date: date, status })
          .select('id,workspace_id,submitted_by,submitter_name,type,category,description,amount_cents,transaction_date,status,receipt_path,created_at')
          .single()
        if (insertError) throw insertError
        if (!isFinanceTransaction(data)) throw new Error('The finance service returned an invalid transaction.')
        saved = data
      }
      if (receipt && receipt.size > 0) {
        const extension = receipt.type === 'application/pdf' ? 'pdf' : receipt.type === 'image/jpeg' ? 'jpg' : 'png'
        const path = `${workspaceId}/${saved.id}.${extension}`
        const { error: uploadError } = await supabase.storage.from('club-finance-receipts').upload(path, receipt, { contentType: receipt.type, upsert: false })
        if (uploadError) throw new Error(`The transaction was saved, but its receipt could not be uploaded: ${uploadError.message}`)
        const { error: receiptError } = await supabase.from('club_finance_transactions')
          .update({ receipt_path: path })
          .eq('workspace_id', workspaceId)
          .eq('id', saved.id)
        if (receiptError) throw new Error(`The receipt was uploaded, but could not be linked to the transaction: ${receiptError.message}`)
      }
      setTransactionEditor(undefined)
      await refresh()
      toast(editing ? 'Transaction updated.' : isFinanceManager ? 'Transaction recorded.' : 'Finance request submitted for approval.')
    } catch (submitError) {
      console.error('Unable to save club finance transaction:', submitError)
      const message = submitError instanceof Error ? submitError.message : 'Unable to save this transaction.'
      await refresh()
      setError(message)
    } finally {
      setBusy(false)
    }
  }

  async function updateStatus(transaction: FinanceTransaction, status: 'approved' | 'rejected') {
    if (!supabase || !isFinanceManager || busy) return
    setBusy(true)
    setError('')
    const { error: updateError } = await supabase.from('club_finance_transactions')
      .update({ status })
      .eq('workspace_id', workspaceId)
      .eq('id', transaction.id)
    if (updateError) {
      console.error('Unable to review club finance request:', updateError)
      setError(updateError.message)
    } else {
      await refresh()
      toast(status === 'approved' ? 'Request approved and added to the balance.' : 'Request declined.')
    }
    setBusy(false)
  }

  async function deleteTransaction(transaction: FinanceTransaction) {
    if (!supabase || !isFinanceManager || busy) return
    if (!window.confirm(`Delete “${transaction.description}”? This cannot be undone.`)) return
    setBusy(true)
    setError('')
    try {
      if (transaction.receipt_path) {
        const { error: receiptError } = await supabase.storage.from('club-finance-receipts').remove([transaction.receipt_path])
        if (receiptError) throw receiptError
      }
      const { error: deleteError } = await supabase.from('club_finance_transactions')
        .delete().eq('workspace_id', workspaceId).eq('id', transaction.id)
      if (deleteError) throw deleteError
      await refresh()
      toast('Transaction deleted.')
    } catch (deleteError) {
      console.error('Unable to delete club finance transaction:', deleteError)
      setError(deleteError instanceof Error ? deleteError.message : 'Unable to delete this transaction.')
    } finally {
      setBusy(false)
    }
  }

  async function viewReceipt(transaction: FinanceTransaction) {
    if (!supabase || !transaction.receipt_path) return
    const openedWindow = window.open('about:blank', '_blank')
    if (openedWindow) openedWindow.opener = null
    const { data, error: receiptError } = await supabase.storage.from('club-finance-receipts')
      .createSignedUrl(transaction.receipt_path, 60)
    if (receiptError) {
      openedWindow?.close()
      console.error('Unable to open club finance receipt:', receiptError)
      setError(receiptError.message)
      return
    }
    if (openedWindow) openedWindow.location.href = data.signedUrl
    else {
      setError('Allow pop-ups to open the private receipt in a new tab.')
    }
  }

  async function submitBudget(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!supabase || !isFinanceManager || busy) return
    const fields = new FormData(event.currentTarget)
    const category = String(fields.get('category') ?? '')
    const period = monthStart(String(fields.get('period') ?? ''))
    const amountCents = centsFromForm(fields.get('amount'))
    if (!categories.some((entry) => entry.value === category) || !period || !amountCents) {
      setError('Enter a category, month, and valid budget amount.')
      return
    }
    setBusy(true)
    setError('')
    const { error: saveError } = await supabase.from('club_finance_budgets')
      .upsert({ workspace_id: workspaceId, category, period, amount_cents: amountCents }, { onConflict: 'workspace_id,category,period' })
    if (saveError) {
      console.error('Unable to save club finance budget:', saveError)
      setError(saveError.message)
    } else {
      setShowBudgetForm(false)
      await refresh()
      toast('Budget saved.')
    }
    setBusy(false)
  }

  async function deleteBudget(budget: FinanceBudget) {
    if (!supabase || !isFinanceManager || busy || !window.confirm('Delete this budget?')) return
    setBusy(true)
    const { error: deleteError } = await supabase.from('club_finance_budgets')
      .delete().eq('workspace_id', workspaceId).eq('id', budget.id)
    if (deleteError) {
      console.error('Unable to delete club finance budget:', deleteError)
      setError(deleteError.message)
    } else {
      await refresh()
      toast('Budget deleted.')
    }
    setBusy(false)
  }

  async function generateDues(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!supabase || !isFinanceManager || busy) return
    const form = new FormData(event.currentTarget)
    const duesMonth = monthStart(String(form.get('period') ?? ''))
    const amountCents = centsFromForm(form.get('amount'))
    if (!duesMonth || !amountCents) {
      setError('Enter a valid month and dues amount.')
      return
    }
    setBusy(true)
    setError('')
    const { data, error: generateError } = await supabase.rpc('generate_club_monthly_dues', {
      p_workspace_id: workspaceId,
      p_period: duesMonth,
      p_amount_cents: amountCents,
    })
    if (generateError) {
      console.error('Unable to generate monthly club dues:', generateError)
      setError(generateError.message)
    } else {
      setShowDuesForm(false)
      setMonth(duesMonth.slice(0, 7))
      await refresh()
      toast(`Monthly dues prepared for ${Number(data) || 0} active member accounts.`)
    }
    setBusy(false)
  }

  async function reportDuesPayment(item: MemberDues) {
    if (!supabase || busy) return
    setBusy(true)
    setError('')
    const { error: reportError } = await supabase.rpc('report_club_dues_payment', {
      p_dues_id: item.id,
    })
    if (reportError) {
      console.error('Unable to report club dues payment:', reportError)
      setError(reportError.message)
    } else {
      await refresh()
      toast('Payment reported to the club Treasurer.')
    }
    setBusy(false)
  }

  async function reviewDuesPayment(item: MemberDues, approve: boolean) {
    if (!supabase || !isFinanceManager || busy) return
    setBusy(true)
    setError('')
    const { error: reviewError } = await supabase.rpc('review_club_dues_payment', {
      p_dues_id: item.id,
      p_approve: approve,
    })
    if (reviewError) {
      console.error('Unable to review club dues payment:', reviewError)
      setError(reviewError.message)
    } else {
      await refresh()
      toast(approve ? 'Dues payment approved and added to income.' : 'Payment report returned to unpaid.')
    }
    setBusy(false)
  }

  const transactionForm = transactionEditor !== undefined && <form className="panel finance-form-card modal-form" onSubmit={(event) => void submitTransaction(event)}>
    <div className="finance-section-heading"><div><span className="section-kicker">{transactionEditor ? 'EDIT ENTRY' : isFinanceManager ? 'NEW LEDGER ENTRY' : 'REQUEST'}</span><h2>{transactionEditor ? 'Edit transaction' : isFinanceManager ? 'Record a transaction' : 'Request a transaction'}</h2></div><button type="button" className="button button-secondary" onClick={() => setTransactionEditor(undefined)}>Cancel</button></div>
    <div className="form-row"><label>Type<select name="type" defaultValue={transactionEditor?.type ?? 'expense'}><option value="expense">Expense</option><option value="income">Income</option></select></label><label>Category<select name="category" defaultValue={transactionEditor?.category ?? 'event-costs'}>{categories.map((entry) => <option key={entry.value} value={entry.value}>{entry.label}</option>)}</select></label></div>
    <label>Description<input name="description" required maxLength={160} defaultValue={transactionEditor?.description} placeholder="What was this for?" /></label>
    <div className="form-row"><label>Amount (NZD)<input name="amount" type="number" min="0.01" max="1000000000" step="0.01" required defaultValue={transactionEditor ? (transactionEditor.amount_cents / 100).toFixed(2) : ''} /></label><label>Date<input name="transaction_date" type="date" required defaultValue={transactionEditor?.transaction_date ?? currentDate()} /></label></div>
    {!transactionEditor && isFinanceManager && <label>Approval status<select name="status" defaultValue="approved"><option value="approved">Approved — include in balance</option><option value="pending">Pending approval</option></select></label>}
    {(!transactionEditor || !transactionEditor.receipt_path) && <label>Receipt (optional)<input name="receipt" type="file" accept=".pdf,.jpg,.jpeg,.png,application/pdf,image/jpeg,image/png" /><small>PDF, JPG, or PNG · up to 10 MB</small></label>}
    {transactionEditor?.receipt_path && <p className="finance-hint">This entry already has a receipt attached.</p>}
    <button className="button button-primary" type="submit" disabled={busy}>{busy ? 'Saving…' : transactionEditor ? 'Save transaction' : isFinanceManager ? 'Record transaction' : 'Submit for approval'}</button>
  </form>

  const budgetForm = showBudgetForm && <form className="panel finance-form-card modal-form" onSubmit={(event) => void submitBudget(event)}>
    <div className="finance-section-heading"><div><span className="section-kicker">SPENDING PLAN</span><h2>Set a monthly budget</h2></div><button type="button" className="button button-secondary" onClick={() => setShowBudgetForm(false)}>Cancel</button></div>
    <div className="form-row"><label>Category<select name="category" defaultValue="event-costs">{categories.map((entry) => <option key={entry.value} value={entry.value}>{entry.label}</option>)}</select></label><label>Month<input name="period" type="month" required defaultValue={month} /></label></div>
    <label>Budget (NZD)<input name="amount" type="number" min="0.01" max="1000000000" step="0.01" required /></label>
    <button className="button button-primary" type="submit" disabled={busy}>{busy ? 'Saving…' : 'Save budget'}</button>
  </form>

  const duesForm = showDuesForm && <form className="panel finance-form-card modal-form" onSubmit={(event) => void generateDues(event)}>
    <div className="finance-section-heading"><div><span className="section-kicker">MEMBERSHIP DUES</span><h2>Prepare monthly dues</h2></div><button type="button" className="button button-secondary" onClick={() => setShowDuesForm(false)}>Cancel</button></div>
    <p className="finance-hint">Creates or updates this month’s unpaid dues for {activeMemberIds.length} active member accounts. Already-paid records are left unchanged.</p>
    <div className="form-row"><label>Month<input name="period" type="month" required defaultValue={month} /></label><label>Dues per member (NZD)<input name="amount" type="number" min="0.01" max="1000000000" step="0.01" required /></label></div>
    <button className="button button-primary" type="submit" disabled={busy}>{busy ? 'Preparing…' : 'Prepare monthly dues'}</button>
  </form>

  return <>
    <div className="page-heading"><div><span className="eyebrow">CLUB MONEY</span><h1>Finances</h1><p>Shared income, spending, budgets, and member dues.</p></div><button className="button button-secondary finance-export" type="button" onClick={() => downloadCsv(postedTransactions)}><Download size={15} />Export approved entries</button></div>
    {error && <p className="auth-error finance-alert" role="alert">{error}</p>}
    {notice && <p className="password-success finance-alert" role="status">{notice}</p>}
    <nav className="finance-tabs" aria-label="Finance sections">{tabs.map((item) => <button key={item.id} type="button" className={tab === item.id ? 'active' : ''} aria-current={tab === item.id ? 'page' : undefined} onClick={() => { setTab(item.id); setError('') }}>{item.label}{item.id === 'transactions' && isFinanceManager && pendingCount > 0 && <span className="finance-tab-count">{pendingCount}</span>}</button>)}</nav>
    <div className="finance-toolbar"><label>Selected month<input type="month" value={month} onChange={(event) => setMonth(event.target.value || currentMonth())} /></label>{loading && <span>Loading finance records…</span>}</div>
    {transactionForm}
    {budgetForm}
    {duesForm}
    {tab === 'overview' && <>
      <section className="finance-stats">
        <article className="panel finance-stat-card"><span>Current balance</span><strong>{money(balance)}</strong><small>Approved entries only</small></article>
        <article className="panel finance-stat-card"><span>Income this month</span><strong className="finance-income">{money(incomeThisMonth)}</strong><small>{month}</small></article>
        <article className="panel finance-stat-card"><span>Expenses this month</span><strong className="finance-expense">{money(expensesThisMonth)}</strong><small>{month}</small></article>
        <article className="panel finance-stat-card"><span>Awaiting approval</span><strong>{pendingCount}</strong><small>Requests from club members</small></article>
      </section>
      <section className="panel finance-panel">
        <div className="finance-section-heading"><div><span className="section-kicker">RECENT ACTIVITY</span><h2>Latest transactions</h2></div><button type="button" className="text-button" onClick={() => setTab('transactions')}>View all</button></div>
        <TransactionList transactions={transactions.slice(0, 6)} userId={userId} isFinanceManager={isFinanceManager} busy={busy} onEdit={(entry) => setTransactionEditor(entry)} onReview={(entry, status) => void updateStatus(entry, status)} onDelete={(entry) => void deleteTransaction(entry)} onReceipt={(entry) => void viewReceipt(entry)} />
        {!loading && transactions.length === 0 && <p className="finance-empty">No finance activity yet. Add a transaction or prepare member dues to get started.</p>}
      </section>
      <section className="panel finance-panel">
        <div className="finance-section-heading"><div><span className="section-kicker">SPENDING PLAN</span><h2>Budgets for {month}</h2></div><button type="button" className="text-button" onClick={() => setTab('budgets')}>Manage budgets</button></div>
        <BudgetList budgets={currentBudgets} transactions={postedTransactions} month={month} isFinanceManager={isFinanceManager} onDelete={(entry) => void deleteBudget(entry)} />
      </section>
    </>}
    {tab === 'transactions' && <section className="panel finance-panel">
      <div className="finance-section-heading"><div><span className="section-kicker">LEDGER</span><h2>Transactions and requests</h2><p>Only approved entries change the balance.</p></div><button className="button button-primary" type="button" onClick={() => setTransactionEditor(null)}><Plus size={15} />{isFinanceManager ? 'Record entry' : 'Request entry'}</button></div>
      <TransactionList transactions={transactions} userId={userId} isFinanceManager={isFinanceManager} busy={busy} onEdit={(entry) => setTransactionEditor(entry)} onReview={(entry, status) => void updateStatus(entry, status)} onDelete={(entry) => void deleteTransaction(entry)} onReceipt={(entry) => void viewReceipt(entry)} />
      {!loading && transactions.length === 0 && <p className="finance-empty">There are no transactions yet.</p>}
    </section>}
    {tab === 'budgets' && <section className="panel finance-panel">
      <div className="finance-section-heading"><div><span className="section-kicker">BUDGETS</span><h2>Budget vs actual for {month}</h2><p>Actual totals include approved expenses only.</p></div>{isFinanceManager && <button className="button button-primary" type="button" onClick={() => setShowBudgetForm(true)}><Plus size={15} />Set budget</button>}</div>
      <BudgetList budgets={currentBudgets} transactions={postedTransactions} month={month} isFinanceManager={isFinanceManager} onDelete={(entry) => void deleteBudget(entry)} />
    </section>}
    {tab === 'dues' && <section className="panel finance-panel">
      <div className="finance-section-heading"><div><span className="section-kicker">MEMBERSHIP DUES · {month}</span><h2>Member dues</h2><p>Members can report payments; approved payments are posted as income.</p></div>{isFinanceManager && <button className="button button-primary" type="button" onClick={() => setShowDuesForm(true)}><Plus size={15} />Prepare dues</button>}</div>
      {currentDues.length === 0 ? <p className="finance-empty">{isFinanceManager ? 'No dues have been prepared for this month.' : 'No dues have been set for this month.'}</p> : <div className="finance-dues-list">{currentDues.map((item) => <article className="finance-dues-row" key={item.id}><div><strong>{item.member_name}</strong><span>{money(item.amount_cents)} · {item.period.slice(0, 7)}</span></div><span className={`finance-status finance-status-${item.status}`}>{item.status.replace('_', ' ')}</span><div className="finance-row-actions">{item.status === 'due' && item.member_user_id === userId && <button className="button button-secondary" type="button" disabled={busy} onClick={() => void reportDuesPayment(item)}>I’ve paid</button>}{item.status === 'payment_reported' && isFinanceManager && <><button className="button button-primary" type="button" disabled={busy} onClick={() => void reviewDuesPayment(item, true)}><Check size={14} />Approve payment</button><button className="button button-secondary" type="button" disabled={busy} onClick={() => void reviewDuesPayment(item, false)}>Return</button></>}{item.status === 'due' && isFinanceManager && <button className="button button-secondary" type="button" disabled={busy} onClick={() => void reviewDuesPayment(item, true)}>Mark paid</button>}</div></article>)}</div>}
      {isFinanceManager && <p className="finance-hint">Current active member accounts: {activeMemberIds.length}. Preparing dues again updates unpaid amounts and keeps paid records unchanged.</p>}
    </section>}
    {tab === 'overview' && currentDues.length > 0 && <section className="panel finance-panel"><div className="finance-section-heading"><div><span className="section-kicker">MEMBERSHIP DUES</span><h2>This month’s dues</h2></div><button type="button" className="text-button" onClick={() => setTab('dues')}>Review dues</button></div><div className="finance-dues-summary"><span>{currentDues.filter((item) => item.status === 'paid').length} paid</span><span>{currentDues.filter((item) => item.status === 'payment_reported').length} reported</span><span>{currentDues.filter((item) => item.status === 'due').length} due</span></div></section>}
  </>
}

function TransactionList({ transactions, userId, isFinanceManager, busy, onEdit, onReview, onDelete, onReceipt }: {
  transactions: FinanceTransaction[]
  userId: string
  isFinanceManager: boolean
  busy: boolean
  onEdit: (entry: FinanceTransaction) => void
  onReview: (entry: FinanceTransaction, status: 'approved' | 'rejected') => void
  onDelete: (entry: FinanceTransaction) => void
  onReceipt: (entry: FinanceTransaction) => void
}) {
  return <div className="finance-transactions">{transactions.map((entry) => <article className="finance-transaction-row" key={entry.id}>
    <span className={`finance-transaction-icon ${entry.type}`} aria-hidden="true">{entry.type === 'income' ? <ArrowDownLeft size={16} /> : <ArrowUpRight size={16} />}</span>
    <div className="finance-transaction-details"><strong>{entry.description}</strong><span>{categories.find((item) => item.value === entry.category)?.label ?? entry.category} · {entry.transaction_date} · {entry.submitter_name}</span></div>
    <strong className={`finance-transaction-amount ${entry.type}`}>{entry.type === 'income' ? '+' : '−'}{money(entry.amount_cents)}</strong>
    <span className={`finance-status finance-status-${entry.status}`}>{entry.status}</span>
    <div className="finance-row-actions">
      {entry.receipt_path && <button className="button button-secondary" type="button" onClick={() => onReceipt(entry)}><ReceiptText size={14} />Receipt</button>}
      {entry.status === 'pending' && isFinanceManager && <><button className="button button-primary" type="button" disabled={busy} onClick={() => onReview(entry, 'approved')}><Check size={14} />Approve</button><button className="button button-secondary" type="button" disabled={busy} onClick={() => onReview(entry, 'rejected')}>Decline</button></>}
      {(isFinanceManager || (entry.submitted_by === userId && entry.status === 'pending')) && <button className="button button-secondary" type="button" disabled={busy} onClick={() => onEdit(entry)}>Edit</button>}
      {isFinanceManager && <button className="icon-button danger-action" type="button" aria-label={`Delete ${entry.description}`} disabled={busy} onClick={() => onDelete(entry)}><Trash2 size={15} /></button>}
    </div>
  </article>)}</div>
}

function BudgetList({ budgets, transactions, month, isFinanceManager, onDelete }: {
  budgets: FinanceBudget[]
  transactions: FinanceTransaction[]
  month: string
  isFinanceManager: boolean
  onDelete: (entry: FinanceBudget) => void
}) {
  if (!budgets.length) return <p className="finance-empty">{isFinanceManager ? 'No budgets are set for this month.' : 'No budgets have been published for this month.'}</p>
  return <div className="finance-budgets">{budgets.map((budget) => {
    const spent = transactions.filter((entry) => entry.status === 'approved' && entry.type === 'expense' && entry.category === budget.category && entry.transaction_date.slice(0, 7) === month)
      .reduce((sum, entry) => sum + entry.amount_cents, 0)
    const percent = Math.min(100, Math.round(spent / budget.amount_cents * 100))
    return <article className="finance-budget-row" key={budget.id}>
      <div className="finance-budget-heading"><div><strong>{categories.find((entry) => entry.value === budget.category)?.label ?? budget.category}</strong><span>{money(spent)} spent of {money(budget.amount_cents)}</span></div><strong>{Math.round(spent / budget.amount_cents * 100)}%</strong>{isFinanceManager && <button className="icon-button danger-action" type="button" aria-label="Delete budget" onClick={() => onDelete(budget)}><Trash2 size={14} /></button>}</div>
      <div className="finance-budget-track"><span className={percent >= 100 ? 'over-budget' : ''} style={{ width: `${percent}%` }} /></div>
    </article>
  })}
  </div>
}
