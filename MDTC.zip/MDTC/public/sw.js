const CACHE_NAME = 'mdtc-clubhouse-v2'
const APP_SHELL = ['/', '/index.html', '/manifest.webmanifest', '/app-icon.svg']

self.addEventListener('install', (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME)
    const page = await fetch('/')
    await cache.put('/index.html', page.clone())
    const html = await page.text()
    const assets = [...html.matchAll(/(?:src|href)="([^"]+\.(?:js|css)(?:\?[^"]*)?)"/g)].map((match) => match[1])
    await cache.addAll([...APP_SHELL, ...assets])
  })())
  self.skipWaiting()
})

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((names) => Promise.all(
      names.filter((name) => name !== CACHE_NAME).map((name) => caches.delete(name)),
    )),
  )
  self.clients.claim()
})

self.addEventListener('fetch', (event) => {
  const request = event.request
  if (request.method !== 'GET' || new URL(request.url).origin !== self.location.origin) return

  if (request.mode === 'navigate') {
    event.respondWith(fetch(request).then(async (response) => {
      const cache = await caches.open(CACHE_NAME)
      await cache.put('/index.html', response.clone())
      return response
    }).catch(() => caches.match('/index.html')))
    return
  }

  event.respondWith(caches.match(request).then((cached) => {
    if (cached) return cached
    return fetch(request).then(async (response) => {
      if (response.ok) {
        const cache = await caches.open(CACHE_NAME)
        await cache.put(request, response.clone())
      }
      return response
    })
  }))
})
